<?php

header("Content-Type:text/html;charset=utf-8");
session_start();
//定义个常量，用来授权调用includes里面的文件
define('IN_TG',true);
//定义个常量，用来指定本页的内容
define('SCRIPT','backup');
//ob_start();
//引入公共文件
require dirname(__FILE__).'/includes/common.inc.php';
_manage_login();
require_once 'includes/dbconf.php';
ob_start();
$iniUrlCon=$_SERVER["QUERY_STRING"];
$DbHost='127.0.0.1';
if ($_GET['action']=='backup'){
   /* $backup=ROOT_PATH.'backup';
    if (!is_dir($backup)){
        mkdir($backup);
    }*/
  if ($_POST['backupMethod']=='全部备份'){
     $fileName =$DbName . '_PgSQL_data_whole_backup_' . date('Y-m-d-H-i-s').'.sql';
    $filePath = 'backup/'.$DbName . '_PgSQL_data_whole_backup_' . date('Y-m-d-H-i-s').'.sql';
      //$fileName=$DbName . '_PgSQL_data_backup_' . date('Y-m-d-H-i-s').'.sql';时，在system里面组合文件路径，未得到正确结果==>用双引号分隔也报错了的，提示应该用）==》执行程序或其他语言时，尽量少拼接，多用变量
    system("pg_dump -h $DbHost -U $DbUser $DbName > $filePath",$result);
    //echo $result;
    if($_POST['backupLocation']=='备份至本系统的远程服务器'){
      if ($result==0){//成功则返回0，错误则返回1；


        //写入日志
        $userInfoSql = <<<EOF
SELECT lasttime,lastip FROM djhuser WHERE username='{$_COOKIE['username']}'
EOF;
        $infos = pg_fetch_assoc(pg_query($userInfoSql));
        $upLogSql = <<<EOF
INSERT INTO log (username,tablename,operation,operatetime,content,ip,logintime) VALUES('{$_COOKIE['username']}','{$DbName}数据库','完全备份',NOW(),'全部备份至本系统的远程服务器','{$infos['lastip']}','{$infos['lasttime']}')
EOF;
        /*echo $upLogSql;
        exit();*/
        pg_query($upLogSql);
        _alert_info('备份成功');
        _location('','backup.php');
      }else{//成功则返回0，错误则返回1；
        _alert_back('备份失败');
      }
    }elseif ($_POST['backupLocation']=='备份到本地'){
     // _alert_info('备份成功');
      if ($result==0) {
        //仔细想想这里也不需要提示，成功则会下载，失败则会提示也是正确的的
       // _alert_info('备份成功');
        /*header("Content-Disposition: attachment; filename=" . $fileName);
        header("Content-type: application/octet-stream");
        header("Pragma:no-cache");
        header("Expires:0");*/
       // download($fileName, $filePath);
        //下载文件法2，也有点问题
       // _location('',$filePath);
        //下载文件法3，也有点问题
        /*echo "<script type='text/javascript'>window.open('$filePath');</script>";
        exit();*/

        //写入日志
        $userInfoSql = <<<EOF
SELECT lasttime,lastip FROM djhuser WHERE username='{$_COOKIE['username']}'
EOF;
        $infos = pg_fetch_assoc(pg_query($userInfoSql));
        $upLogSql = <<<EOF
INSERT INTO log (username,tablename,operation,operatetime,content,ip,logintime) VALUES('{$_COOKIE['username']}','{$DbName}'.'数据库','完全备份',NOW(),'完全备份到本地','{$infos['lastip']}','{$infos['lasttime']}')
EOF;
        pg_query($upLogSql);
        download($fileName, $filePath);
        //删除文件
        unlink($filePath);
        exit();
        _location('','backup.php');
      }else{
        _alert_back('备份失败');
      }
    }

  }elseif ($_POST['backupMethod']=='差异备份'){
    //根据日志备份
    //查找最近一次完全备份
    //从日志库中提取信息
    $logSql=<<<eof
SELECT operatetime FROM log WHERE username='{$_COOKIE['username']}' AND operation='完全备份' ORDER BY operatetime DESC;
eof;
    /*echo $logSql;
    exit();*/
    //只提取最近的一条就行
    $logRows=pg_fetch_assoc(pg_query($logSql));
    /*var_dump($logRows);
    exit();*/
    if ($logRows==NULL){
      _alert_back('你还未进行过一次完全备份，不能进行差异备份');
    }else{
      //根据时间获取差异和操作
     /*$needBackupOperations=array('添加','删除','修改','导入');
     // $needBackupOperationsStr=implode(',',$needBackupOperations);
      $needBackupSql=<<<eof
SELECT content From log WHERE operatetime>='{$logRows['operatetime']}' AND operation in ('{$needBackupOperationsStr}') ;
eof;
     // SELECT content From log WHERE operatetime>='2016-11-15 17:16:02.143915' AND operation in ('添加,删除,修改,导入') ;
      echo $needBackupSql;
      exit();*/
      $needBackupSql=<<<eof
SELECT content From log WHERE operatetime>='{$logRows['operatetime']}' AND operation in ('添加','删除','修改','导入') ;
eof;
      $needBackupResult=pg_query($needBackupSql);
        /*ECHO $needBackupSql;
        EXIT();*/
    /*if($logRows['operatetime']==NULL){
        _alert_back('你上一次备份后该数据库没有被改变，不需进行差异备份');
    }*/
     // $needBackupRows=array();
      $fileName = $DbName . '_PgSQL_data_difference_backup_' . date('Y-m-d-H-i-s').'.sql';
      $filePath = 'backup/'.$DbName . '_PgSQL_data_difference_backup_' . date('Y-m-d-H-i-s').'.sql';
      $needBackupFile=fopen($filePath,'a+')or die("Unable to open file!");
        $needBackup=array();
        while($needBackupRows=pg_fetch_assoc($importLogResult)){
            $needBackup[]=$needBackupRows['content'];
        }
        /*var_dump($importFilesRows);
        exit();*/
        if (empty($needBackup)){
            /* _alert_info('该数据库最近没有导入新的数据');
             exit();*/
            _location('你上一次备份后该数据库没有被改变，不需进行差异备份','backup.php');
        }
      //while ($needBackupRows=pg_fetch_assoc($needBackupResult)){
      foreach ($needBackup as $value){
        fwrite($needBackupFile, $value);
        fwrite($needBackupFile, "\r\n");
        //''写入文件换行用单引号不行
        //fwrite($needBackupFile, '\r\n');
      }
      fclose($filePath);
      if($_POST['backupLocation']=='备份至本系统的远程服务器'){
        _alert_info('差异备份成功');
      }elseif($_POST['backupLocation']=='备份到本地'){
        //download 之后用exit（）网页上仍旧有正确显示;似乎exit没起作用，但是若不用exit则会下载的文件会包含之后的网页内容
        download($fileName, $filePath);
        ob_end_flush();
        exit();
        //链接之后用exit()，则下载后网页为空白，即exit起作用被截断了
          /*echo "<script type='text/javascript'>location.href='$filePath';</script>";
        _location('','backup.php');*/
          /*echo "<script type='text/javascript'>location.href='backup.php';</script>";
          exit();*/
      }
    }


  }
}
if ($_GET['action']=='restore'){

  //目前只用还原完全备份
  //echo 1;
    if($_GET['dbRestoreMethod']=='whole'){
        //完全还原前要删除数据库，这时必须所有关闭数据库链接，这里先确保关闭了自己的数据库链接
        global $_conn;
        if(pg_close($_conn)){
            //_alert_info('关闭成功');
        }

        $wholeRestoreDir=upload('wholeRestore','restore',$_COOKIE['username']);
        // echo $wholeRestoreDir;

        system("dropdb -h $DbHost -U $DbUser $DbName",$resultRestoreDrop);
        if($resultRestoreDrop==1){
            _alert_info('还原失败，可能有其他用户还在使用当前数据库系统，请最好在夜间进行还原');
        }else{
            /*echo $resultRestore;
        exit();*/
            system("createdb -h $DbHost -U $DbUser $DbName");
            system("psql -h $DbHost -U $DbUser $DbName < $filePath",$resultRestoreCopy);
            if($resultRestoreCopy==1){
                _alert_info('还原失败，还原失败，可能有其他用户还在使用当前数据库系统，请最好在夜间进行还原');
            }
        }

    }elseif ($_GET['dbRestoreMethod']=='difference'){
        //差异备份前最近一次的完全备份+差异备份
        /*$wholeRestoreDir=upload('wholeRestore','restore',$_COOKIE['username']);
        //$wholeRestoreDir=upload('wholeRestore','restore',$_COOKIE['username']);
        // echo $wholeRestoreDir;
        system("dropdb -h $DbHost -U $DbUser $DbName");
        system("createdb -h $DbHost -U $DbUser $DbName");
        system("psql -h $DbHost -U $DbUser $DbName < $filePath");*/
        //提取差异备份中的内容
        $differenceRestoreDir=upload('differenceRestore','restore',$_COOKIE['username']);
        $handle = @fopen($differenceRestoreDir, "r");
        if ($handle) {
            pg_query('BEGIN');
            while (!feof($handle)) {
                $buffer = fgets($handle);
                pg_query($buffer);
                //echo $buffer;
            }
            pg_query('COMMIT');
            fclose($handle);
        }

    }

}
if ($_GET['action']=='move'){
    $destinationIP=$_POST['destinationIP'];
    $destinationDBName=$_POST['destinationDBName'];
    $destinationDBUser=$_POST['destinationDBUser'];
    //$destinationDBPassword=$_POST['destinationDBPassword'];
    if($_POST['destinationDBType']=='postgres'){
        $fileName =$DbName . '_move_' . date('Y-m-d-H-i-s').'.sql';
        $filePath = 'backup/'.$DbName . '_move_' . date('Y-m-d-H-i-s').'.sql';
        system("pg_dump -h $DbHost -U $DbUser $sourceDBName > $filePath",$result);
        system("createdb -h $destinationIP -U $destinationDBUser -w $destinationDBName");
        /*echo 'psql -h '.$destinationIP.' -U '.$DbUser.' -w '.$destinationDBName.' < '.$filePath;
        exit();*/
        system("psql -h $destinationIP -U $destinationDBUser -w $destinationDBName < $filePath",$resultMove);
        if ($resultMove==0){
            _location('迁移成功','backup.php');
        }else{
            _alert_back('迁移失败');
        }

    }

    /* $sourceDBName=$_POST['sourceDBName'];
     $destinationDBName=$_POST['destinationDBName'];

     if($_POST['destinationDBType']=='postgres' && $_POST['sourceDBType']=='postgres'){
         $fileName =$DbName . '_PgSQL_data_whole_backup_' . date('Y-m-d-H-i-s').'.sql';
         $filePath = 'backup/'.$DbName . '_PgSQL_data_whole_backup_' . date('Y-m-d-H-i-s').'.sql';
         system("pg_dump -h $DbHost -U $DbUser $sourceDBName > $filePath",$result);
         system("createdb -h $DbHost -U $DbUser $destinationDBName");
         system("psql -h $DbHost -U $DbUser $destinationDBName < $filePath",$resultMove);
         if ($resultMove==0){
             _location('迁移成功','backup.php');
         }else{
             _alert_back('迁移失败');
         }

     }elseif($_POST['destinationDBType']=='mysql' && $_POST['sourceDBType']=='postgres'){
         $fileName =$DbName . '_PgSQL_data_whole_backup_' . date('Y-m-d-H-i-s').'.sql';
         $filePath = 'backup/'.$DbName . '_PgSQL_data_whole_backup_' . date('Y-m-d-H-i-s').'.sql';
         system("pg_dump -h $DbHost -U $DbUser $sourceDBName > $filePath",$result);
         //创建mysql数据库
         //连接mysql
         $con = mysql_connect("localhost","root","root")or die('Could not connect: ' . mysql_error());
         $sqlMysqlDB=<<<eof
 create database $destinationDBName
 eof;
         mysql_query($sqlMysqlDB);
         //mysql -uroot -p dp_db_bak < ~/dumpout.sql
         //system("psql -h $DbHost -U $DbUser $destinationDBName < $filePath",$resultMove);
         system("mysql -h $DbHost -uroot -p $destinationDBName < $filePath",$resultMove);
         if ($resultMove==0){
             _location('迁移成功','backup.php');
         }else{
             _alert_back('迁移失败');
         }

     }*/


}


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title><?php echo '湖南省郴州东江湖水资源管理'?></title>
  <link rel="shortcut icon" href="dongjianghu.ico" />
  <script type="text/javascript" src="js/jquery-3.1.0.min.js"></script>
  <link rel="stylesheet" type="text/css" href="js/jQuery-jcDate-master/src/jcDate.css" media="all" />
  <script type="text/javascript" src="js/jQuery-jcDate-master/src/jQuery-jcDate.js" charset="utf-8"></script>
  <script type="text/javascript" src="js/baseManage.inc1.js"></script>
<link rel="stylesheet" type="text/css" href="templateCss.css"/>
<style type="text/css">
#bakbody{
  min-height: 600px;
}
div.mainUp{
  width: 98%;
  height: auto;
  z-index: 1;
  margin-top: 15px;
  margin-right: 10px;
  margin-bottom: 10px;
  margin-left: 15px;
  background-color: #FFF;
  border-radius: 8px;
  font-size: 18px;
}
div.mainUp h2#operateTitle{
  clear: both;
  text-align:center;
}
div.mainUp h2#operateTitle strong{
  clear: inherit;
}
div.mainUp form ul {
	list-style-type: none;
	min-height:80px;
	width:95%;
	overflow:auto;
}
div.mainUp form ul li{

	display:inline-block;
	width:40%;
	min-height:35px;
}
div.mainUp form ul li span.searchInfo{
	display:inline-block;
	/*border:red solid 1px;*/
	width:350px;
}
div.mainUp form ul li span.searchInput{
	width:180px;
}
div.mainUp form ul input.searchInput{
	width:60px;
	}

div.mainUp form ul.displaySelect{

	height:110px;
	overflow-y:auto;
	overflow-x:hidden;
}
div.mainUp form ul li.displaySelect{

	display:inline-block;
	width:170px;
	min-height:35px;
}
div.mainUp form ul li.displayBatch{

	display:block;
	text-align:center;
	min-height:35px;
}
div.mainUp form ul.submit{
	text-align:center;
	height:35px;
}
div.mainUp form ul.methodSelect{
    min-height:35px;
	}
div.mainUp form ul li.methodSelect{
	display:inline-block;
	width:320px;
    min-height:35px;
}
div.mainUp form table{
    text-align: center;
}
div.mainUp form table input{
    width:150px;
}
div.mainUp form table select{
    width:150px;
}
#apDiv1 {
	position: absolute;
	left: 1074px;
	top: 381px;
	width: 157px;
	height: 42px;
	z-index: 3;
}
</style>

</head>

<body bgcolor="#cfd4ff">
<?php
require_once("includes/header.inc.php");
?>
<div class="bodyContent">
<div id="bakbody">

  <div id="selectDB">
    <h2><p>选择对数据库进行何种操作</p></h2>
      <span class="explan">(进行备份，还原时目标数据库不能有活动的连接，进行迁移时，源数据库，目标数据库都不能有活动的连接，所以上述操作最好在夜间进行)</span>
    <ul>
      <?php
      $dbOperate=array('backup'=>'备份','restore'=>'还原','move'=>'迁移');
      foreach($dbOperate as $key=>$value){
        if (1){
          $imgPath='images/department3/'.$key.'.jpg';

          /*echo '<li><span class="department" style='.'background: url("<?php echo $images;?>") no-repeat left;'.' >'.departmentCH($key).':</span>';*/
          echo '<li>';
          ?>

          <p class="department" style="background: url('<?php echo $imgPath;?>') no-repeat top;background-size:contain;">
            <a href="?dbOperateMethod=<?php echo $key;?>"><?php echo $dbOperate[$key];?></a>
          </p>
          <?php


          echo '</li>';
        }
      }?>
    </ul>
  </div>
  <?php
  if ($_GET['dbOperateMethod']=='backup'){
?>
    <div class="mainUp">
      <h2 id="operateTitle"><?php echo $_SESSION['tableCh']?>数据库<?php echo $dbOperate[$_GET['dbOperateMethod']]?>操作</h2>

      <form enctype="multipart/form-data" method="post" action="?<?php echo $iniUrlCon;?>&action=backup">



        <span  class="title2">数据库备份方式选择:</span>
        <ul class="methodSelect">

          <li class="methodSelect"><input class="methodSelect" type="radio" name="backupMethod"  checked="checked" id="backupMethod1" value="全部备份"  />
            <label for="backupMethod1">全部备份</label></li>
          <li class="methodSelect"><input class="methodSelect" type="radio" name="backupMethod"   id="backupMethod2" value="差异备份" />
            <label for="backupMethod2">差异备份</label></li>
          <!--<li class="methodSelect"><input class="methodSelect" type="radio" name="exportMethod"
                                          disabled="disabled"             id="exportMethod" value="修改导出"/>
            <label for="exportMethod3">修改导出</label></li>-->
        </ul>
        <span  class="title2">数据库备份位置选择:</span>
        <ul class="methodSelect">

          <li class="methodSelect"><input class="methodSelect" type="radio" name="backupLocation"  checked="checked" id="backupLocation1" value="备份至本系统的远程服务器"  />
            <label for="backupLocation1">备份至本系统的远程服务器</label></li>
          <li class="methodSelect"><input class="methodSelect" type="radio" name="backupLocation"  id="backupLocation2" value="备份到本地" />
            <label for="backupLocation2">备份到本地</label></li>
          <!--<li class="methodSelect"><input class="methodSelect" type="radio" name="exportMethod"
                                          disabled="disabled"             id="exportMethod" value="修改导出"/>
            <label for="exportMethod3">修改导出</label></li>-->
        </ul>
        <ul class="submit">
          <li>
            <input type="submit" value="开始备份">
          </li>
        </ul>
      </form>

    </div>

    <?php


  }
  ?>

  <?php
  if ($_GET['dbOperateMethod']=='restore'){
    ?>
    <div class="mainUp">
      <h2 id="operateTitle"><?php echo $_SESSION['tableCh']?>数据库<?php echo $dbOperate[$_GET['dbOperateMethod']]?>操作</h2>

      <form enctype="multipart/form-data" method="post" action="?<?php echo $iniUrlCon;?>&action=restore">



        <span  class="title2">数据库还原方式选择:</span>
        <ul class="methodSelect">

          <!--<li class="methodSelect"><input class="methodSelect" type="radio" name="backupMethod"  checked="checked" id="backupMethod1" value="还原完全备份"  />
            <label for="backupMethod1">还原全部备份</label></li>-->
            <li><a href="backup.php?dbOperateMethod=restore&dbRestoreMethod=whole">还原完全备份</a></li>
            <li><a href="backup.php?dbOperateMethod=restore&dbRestoreMethod=difference">还原差异备份</a></li>
          <!--<li class="methodSelect"><input class="methodSelect" type="radio" name="backupMethod"   id="backupMethod2" value="还原差异备份" />
            <label for="backupMethod2">还原差异备份</label></li>-->
          <!--<li class="methodSelect"><input class="methodSelect" type="radio" name="exportMethod"
                                          disabled="disabled"             id="exportMethod" value="修改导出"/>
            <label for="exportMethod3">修改导出</label></li>-->
        </ul>
          <?php if ($_GET['dbRestoreMethod']=='whole'){?>
        <span  class="title2">请选择还原完全备份所用文件:</span>
        <ul class="methodSelect">
          <style type="text/css">
            .a-upload {
              padding: 4px 10px;
              height: 20px;
              line-height: 20px;
              position: relative;
              cursor: pointer;
              color: #888;
              background: #dfc1fa;
              border: 1px solid #ddd;
              border-radius: 4px;
              overflow: hidden;
              display: inline-block;
              *display: inline;
              *zoom: 1
            }

            .a-upload  input {
              position: absolute;
              font-size: 100px;
              right: 0;
              top: 0;
              opacity: 0;
              filter: alpha(opacity=0);
              cursor: pointer
            }

            .a-upload:hover {
              color: #444;
              background: #eee;
              border-color: #ccc;
              text-decoration: none
            }
            .showFileName {
              display:inline-block;
              padding: 4px 10px;
              height: 20px;
              line-height: 20px
            }
          </style>

          <a href="javascript:;" class="a-upload" id="aUpload">
            <input type="file" name="wholeRestore" id="userfile">点击这里上传文件

          </a>
          <span class="showFileName" id="upFileName"></span><span class="fileerrorTip"></span>
          <script type="text/javascript">
            $(".a-upload").on("change","input[type='file']",function(){
              // alert(1);
              var filePath=$(this).val();
              // alert(filePath);
              //  $(".fileerrorTip").html("您未上传文件，或者您上传文件类型有误！");
              $(".fileerrorTip").html("").hide();
              var arr=filePath.split('\\');
              var fileName=arr[arr.length-1];
              $(".showFileName").html(fileName);
              /*  if(filePath.indexOf("jpg")!=-1 || filePath.indexOf("png")!=-1){
               $(".fileerrorTip").html("").hide();
               var arr=filePath.split('\\');
               var fileName=arr[arr.length-1];
               $(".showFileName").html(fileName);
               }else{
               $(".showFileName").html("");
               $(".fileerrorTip").html("您未上传文件，或者您上传文件类型有误！").show();
               return false
               }*/
            })

          </script>
          <!--<li class="methodSelect"><input class="methodSelect" type="radio" name="exportMethod"
                                          disabled="disabled"             id="exportMethod" value="修改导出"/>
            <label for="exportMethod3">修改导出</label></li>-->
        </ul>
          <?php }elseif($_GET['dbRestoreMethod']=='difference'){?>
              <span  class="title2">请选择还原差异备份所用文件:</span>
              <ul class="methodSelect">
                  <style type="text/css">
                      .a-upload {
                          padding: 4px 10px;
                          height: 20px;
                          line-height: 20px;
                          position: relative;
                          cursor: pointer;
                          color: #888;
                          background: #dfc1fa;
                          border: 1px solid #ddd;
                          border-radius: 4px;
                          overflow: hidden;
                          display: inline-block;
                          *display: inline;
                          *zoom: 1
                      }

                      .a-upload  input {
                          position: absolute;
                          font-size: 100px;
                          right: 0;
                          top: 0;
                          opacity: 0;
                          filter: alpha(opacity=0);
                          cursor: pointer
                      }

                      .a-upload:hover {
                          color: #444;
                          background: #eee;
                          border-color: #ccc;
                          text-decoration: none
                      }
                      .showFileName {
                          display:inline-block;
                          padding: 4px 10px;
                          height: 20px;
                          line-height: 20px
                      }
                  </style>

                  <a href="javascript:;" class="a-upload" id="aUpload">
                      <input type="file" name="differenceRestore" id="userfile">点击这里上传差异备份文件

                  </a>
                  <span class="showFileName" id="upFileName"></span><span class="fileerrorTip"></span>
                  <script type="text/javascript">
                      $(".a-upload").on("change","input[type='file']",function(){
                          // alert(1);
                          var filePath=$(this).val();
                          // alert(filePath);
                          //  $(".fileerrorTip").html("您未上传文件，或者您上传文件类型有误！");
                          $(".fileerrorTip").html("").hide();
                          var arr=filePath.split('\\');
                          var fileName=arr[arr.length-1];
                          $(".showFileName").html(fileName);
                          /*  if(filePath.indexOf("jpg")!=-1 || filePath.indexOf("png")!=-1){
                           $(".fileerrorTip").html("").hide();
                           var arr=filePath.split('\\');
                           var fileName=arr[arr.length-1];
                           $(".showFileName").html(fileName);
                           }else{
                           $(".showFileName").html("");
                           $(".fileerrorTip").html("您未上传文件，或者您上传文件类型有误！").show();
                           return false
                           }*/
                      })

                  </script>
                  <!--<li class="methodSelect"><input class="methodSelect" type="radio" name="exportMethod"
                                                  disabled="disabled"             id="exportMethod" value="修改导出"/>
                    <label for="exportMethod3">修改导出</label></li>-->
              </ul>

          <?php }?>
          <?php if(isset($_GET['dbRestoreMethod'])){?>
        <ul class="submit">
          <li>
            <input type="submit" value="开始还原">
          </li>
        </ul>
          <?php }?>
      </form>

    </div>

    <?php
  }
  ?>
  <?php
  if ($_GET['dbOperateMethod']=='move'){
    ?>
    <div class="mainUp">
      <h2 id="operateTitle"><?php echo $_SESSION['tableCh']?>数据库<?php echo $dbOperate[$_GET['dbOperateMethod']]?>操作</h2>

      <form enctype="multipart/form-data" method="post" action="?<?php echo $iniUrlCon;?>&action=move">



        <span  class="title2">数据库迁移可选操作:</span>
          <ul class="methodSelect">
<!--<div class="displayClass">-->
          <table width="100%" border="1">
            <tr>
              <th>
                /
              </th>
            <!--<th>
              源数据库
            </th>-->
              <th>
                目标数据库
              </th>
            </tr>
           <!-- <tr>
              <th>ip</th>
              <td><input name="sourceIp" value="localhost"/></td>
              <td><input name="destinationIp" value="localhost"/></td>

            </tr>-->
              <tr>
                  <th style="width:40% "><dd>ip地址<span class="explan">（目标主机必须可以与本系统的远程服务器连接，且其数据库允许服务器对其进行访问）</span></dd></th>
                  <!--<td><input name="sourceDBName" value="postgres" readonly="readonly"/></td>-->
                  <td><input name="destinationIP"/>(eg:10.128.71.143)</td>
              </tr>
<tr>
  <th>数据库类型</th>
  <!--<td><input name="sourceDBType" value="postgres" readonly="readonly"/></td>-->
  <td>
      <!--<input name="destinationDBType" value="postgres"/>-->
  <select name="destinationDBType">
      <option value="postgres">postgresql</option>
      <!--<option value="mysql">mysql</option>-->
  </select>
  </td>

</tr>
              <tr>
                  <th>目标数据库用户名<span class="explan">(用户必须存在，且最好是管理员)</span></th>
                  <!--<td><input name="sourceDBName" value="postgres" readonly="readonly"/></td>-->
                  <td><input name="destinationDBUser"/></td>
              </tr>

            <tr>
              <th>目标数据库命名<span class="explan">(目表主机上不存在此数据库，或者该数据库没有与源数据库相同的数据表)</span></th>
              <!--<td><input name="sourceDBName" value="postgres" readonly="readonly"/></td>-->
              <td><input name="destinationDBName" value="test"/></td>
            </tr>

          </table>
<!--</div>-->


        <ul class="submit">
          <li style="margin-top: 15px;">
            <input type="submit" value="开始迁移">
          </li>
        </ul>
              </ul>
      </form>

    </div>

    <?php
  }
  ?>
</div>
</div>
<?php require_once('includes/footer.inc.php');?>

<script type="text/javascript" src="js/<?php echo SCRIPT?>.js"></script>
</body>
</html>
