<?php
/**
 * Created by PhpStorm.
 * User: hetong
 * Date: 2016/9/16
 * Time: 8:09
 */
?>




<script type="text/css">
    .placeholder {
        font-size: 0;
        height: 0;
    }

    .portlets {
        padding: 3px;
    }

    .portlet {
        /*margin: 8px 2px 10px 10px;*/
        /*_background: url( ../images/bl-gray.png ) no-repeat left bottom;*/
        padding-left: 8px;
        padding-right: 8px;
        padding-top: 8px;
        padding-bottom: 0px;
    }

    .portletFrame {
        _background: url( ../images/br-gray.png ) no-repeat right bottom;
        _background:white ;
        padding-bottom: 1px;
        border:1px solid  #CBC9C9;
        background: #fff;
        border-radius:5px;
    }

    .portletHeader {
        background: url( ../images/tl-gray.png ) ;
        border-radius:5px;
    }

    .portletHeaderFrame {
        _background: url( ../images/tr-gray.png ) no-repeat right top;
        border-radius:5px;
    }

    .portletContent {
        padding: 1px 1px 1px 1px;
        overflow: hidden;
    }

    .portletHeaderFrame .title {
        cursor: text;
        float: left;
        font-size:13px;
        font-weight: bold;
        color: #0d92d7;
        line-height: 40px;
        padding-left: 30px;
    }

    .portletHeaderFrame .toolButton {
        float: right;
        padding-top: 10px;
        padding-right: 10px;
    }

    .toolButton a {
        display: block;
        float: left;
        width: 15px;
        height: 15px;
        cursor: pointer;
    }

    .toolButton .more {
        background: url( ../images/tools.gif ) no-repeat -38px -158px;
    }

    .toolButton .more:hover {
        background-position: 2px -158px;
    }

    .toolButton .minimize {
        background: url( ../images/tools.gif ) no-repeat -35px -70px;
    }

    .toolButton .minimize:hover {
        background-position: 5px -70px;
    }

    .toolButton .maximize {
        background: url( ../images/tools.gif ) no-repeat -36px -37px;
    }

    .toolButton .maximize:hover {
        background-position: 4px -37px;
    }

    .toolButton .restore {
        background: url( ../images/tools.gif ) no-repeat -36px -117px;
    }

    .toolButton .restore:hover {
        background-position: 4px -117px;
    }

    .toolButton .close {
        background: url( ../images/tools.gif ) no-repeat -37px 3px;
    }

    .toolButton .close:hover {
        background-position: 3px 3px;
    }


    .toolButton .borderHide {
        background: url( ../images/tools.gif ) no-repeat -37px -211px;
    }

    .toolButton .borderHide:hover {
        background-position: 3px -211px;
    }

    .toolButton .editName {
        background: url( ../images/tools.gif ) no-repeat -37px -193px;
    }

    .toolButton .editName:hover {
        background-position: 3px -193px;
    }

    .toolButton .borderShow {
        background: url( ../images/tools.gif ) no-repeat -37px -176px;
    }

    .toolButton .borderShow:hover {
        background-position: 3px -176px;
    }


</script>


<div class="placeholder">&nbsp;</div>





















<div class="portlet" id="pf253"  isFixed="ture">
    <div class="portletFrame">
        <div class="portletHeader clearFix">
            <div class="portletHeaderFrame clearFix">
                <div class="title">
                    <a name="anchorf253"></a>
                    <span>个人信息</span>&nbsp;
                </div>
                <div class="toolButton"  id="tbf253" urls="{view:'',edit:'',config:'',authset:'',help:''}">
                    <a href="#" class="more" onclick="return showPortletMenu(this,event);"></a>

                    <a href='?.p=Znxjb20ud2lzY29tLnBvcnRhbC5zaXRlLnYyLmltcGwuRnJhZ21lbnRXaW5kb3d8ZjI1M3x2aWV3fG1pbmltaXplZHw_&.nctp=true' title="最小化" class="minimize"></a>
                    <a href='?.p=Znxjb20ud2lzY29tLnBvcnRhbC5zaXRlLnYyLmltcGwuRnJhZ21lbnRXaW5kb3d8ZjI1M3x2aWV3fG1heGltaXplZHw_&.nctp=true' title="最大化" class="maximize"></a>


                </div>
            </div>
        </div>
        <div class="portletContent">














            <script type="text/javascript">
                $import('/core/style/personalInfo.css');
            </script>

            <table class="composer_header">
                <tr>
                    <td>
                        <div class="ar_r_t">
                            <div class="ar_l_t">
                                <div class="ar_r_b">
                                    <div class="ar_l_b">
                                        <img src="attachmentDownload.portal?notUseCache=true&attachmentId=defaultValue" alt="" width="100px" heigth="130px;">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="composer">
                            <ul>


                                <li>工号：15108010916</li>


                                <li>身份：





                                    <span>研究生</span>

                                </li>



                                <li>上次登录时间：</li>
                                <li>2016-09-16 03:11:14</li>


                            </ul>
                        </div>
                    </td>
                </tr>
            </table>

        </div>
    </div>
</div>

