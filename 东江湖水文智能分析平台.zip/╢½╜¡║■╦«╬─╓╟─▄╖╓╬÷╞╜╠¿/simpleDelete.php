<?php
/**
 * TestGuest Version1.0
 * ================================================
 * Copy 2010-2012 yc60
 * Web: http://www.yc60.com
 * ================================================
 * Author: Lee
 * Date: 2010-9-2
 */
header("Content-Type:text/html;charset=utf-8");
header("Cache-Control: no-cache");
session_start();
/*function Log($username,$datebase,$operation,$id){
    //连接数据库
    pg_connect("host=localhost port=5432 dbname=postgres user=postgres password=123456");
    $sql=<<<EOF
            INSERT INTO log (username,tablename,operation,content) VALUES ('{$username}','{$datebase}','{$operation}','{$id}')
EOF;
    pg_query($sql);
    pg_close();
}*/


require_once("http://localhost:8080/JavaBridgeTemplate611/java/Java.inc");
//$baseType=$_GET['baseType'];
$id=intval($_POST['id']);
if($_SESSION['authority']==1 ||$_SESSION['authority']==2){
    if($_SESSION['baseType']=="水文"){
        $simpleDelete=new Java("HYDelete");

        $simpleDelete->IDDelete($id);


    }elseif($_SESSION['baseType']=="气象"){
        $simpleDelete=new Java("ATDelete");
        $simpleDelete->IDDelete($id);
    }elseif($_SESSION['baseType']=="环保"){
        $simpleDelete=new Java("WQMDelete");
        $simpleDelete->IDDelete($id);
    }elseif($_SESSION['baseType']=="统计"){
        $simpleDelete=new Java("ZXCDelete");
        $simpleDelete->IDDelete($id);
    }elseif($_SESSION['baseType']=="农调"){
        $simpleDelete=new Java("RPCIDelete");
        $simpleDelete->IDDelete($id);
    }
    //log($_COOKIE['username'],$_SESSION['baseType'],'根据id删除',$id);
}


