<?php
/**
* TestGuest Version1.0
* ================================================
* Copy 2010-2012 yc60
* Web: http://www.yc60.com
* ================================================
* Author: Lee
* Date: 2010-8-10
*/
header("Content-Type:text/html;charset=utf-8");
session_start();
//定义个常量，用来授权调用includes里面的文件
define('IN_TG',true);
//定义个常量，用来指定本页的内容
define('SCRIPT','index');
//引入公共文件
require dirname(__FILE__).'/includes/common.inc.php'; //转换成硬路径，速度更快
global $_system;
//echo 2;
//开始处理登录状态
if ($_GET['action'] == 'login') {
	if (!empty($_system['code'])) {
		//为了防止恶意注册，跨站攻击
		_check_code($_POST['code'], $_SESSION['code']);
	}
//引入验证文件
	include ROOT_PATH . 'includes/login.func.php';
//接受数据
	$_clean = array();
	$_clean['username'] = _check_username($_POST['username'], 2, 20);
	$_clean['password'] = _check_password($_POST['password'], 4);
	echo $_clean['username'];
//$_clean['time'] = _check_time($_POST['time']);
//到数据库去验证,php的变量写到sql语句中时，如果不是数字，则需要加上引号,sql语句中引用变量必须要加花括号
	global $_conn;
	$sql = <<<EOF
			SELECT username,authority,department,loginstate,active From djhuser WHERE username='{$_clean['username']}' AND password='{$_clean['password']}';
EOF;
	//echo $sql;
	$result = pg_query($sql);
//$rows=pg_fetch_array($result,PGSQL_ASSOC);
	$rows = pg_fetch_assoc($result);
//echo $rows['username'];
	/*$sql=<<<EOF
            SELECT username,authority,department,loginstate From djhuser WHERE id=1;
    EOF;
    echo $sql;
    $result=pg_query($sql);
    $rows=pg_fetch_row($result);
    echo $rows[0];*/
	/*$result=pg_query("SELECT * From djhuser WHERE username='{$_clean['username']}' AND password='{$_clean['password']}'");*/
	/*$_conn = pg_connect("host=localhost port=5432 dbname=postgres user=postgres password=123456");
    $result0=pg_query($_conn,"SELECT * From hydraulictable WHERE id=15");
    $rows0=pg_fetch_array($result0,PGSQL_ASSOC);
    echo $rows0['datetime'];
    $result=pg_query($_conn,"SELECT * From djhuser WHERE username=contract");

    $rows=pg_fetch_array($result,PGSQL_ASSOC);
    echo $rows['username'];
    echo 2;*/
	/*if(!!$rows=_fetch_array("SELECT username,authority,department,loginstate From djhuser WHERE username='{$_clean['username']}' AND password='{$_clean['password']}'")){*/
echo !!$rows;
	if (!!$rows) {
		//echo $rows['username'];
		//不允许用户异地登录
		/*if($rows['loginstate']==true){
            _alert_back('你的账号已经在其他地方登陆');
        }*/
		if ($rows['active'] == false) {
			_alert_back('你的账号未激活');
		}
		//登陆成功后，更改登录信息
		$updateSql = <<<EOF
				UPDATE djhuser SET 
									loginState=true,
									lastTime=NOW(),
									lastIp='{$_SERVER['REMOTE_ADDR']}',
									loginCount=loginCount+1
							  WHERE
									username='{$rows['username']}';
EOF;

		pg_query($updateSql);
		//_setcookies($_clean['username']);
		setcookie('username',$_clean['username']);
		setcookie('loginTime', date("Y-m-d H:i:s",time()));
		echo $_COOKIE['username'];
		if ($rows['authority'] == 1) {
			$_SESSION['authority'] = 1;
			$_SESSION['superUser'] = $_clean['username'];
		} elseif ($rows['authority'] == 2) {
			$_SESSION['authority'] = 2;
			$_SESSION['admin'] = $_clean['username'];
		}
		//记录用户所属部门

		$_SESSION['department'] = $rows['department'];
		pg_close();
		//pg_errormessage($_conn);
		//设置了cookie，重新刷新，解决cookie 慢半拍的问题
		_location(null, 'index.php');
	} else {
		_close();
		//echo "failed";
		_session_destroy();
		_location('用户名密码不正确或者该账户未被激活！', 'index.php?fres=new');
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title><?php echo '湖南省郴州东江湖水资源管理'?></title>

	<link rel="shortcut icon" href="dongjianghu.ico" />
	<link rel="stylesheet" type="text/css" href="styles/<?php echo 1?>/<?php echo SCRIPT;?>.css" />
	<script type="text/javascript" src="js/jquery-3.1.0.min.js"></script>
	<link rel="stylesheet" type="text/css" href="js/jQuery-jcDate-master/src/jcDate.css" media="all" />
	<script type="text/javascript" src="js/jQuery-jcDate-master/src/jQuery-jcDate.js" charset="utf-8"></script>
	<script type="text/javascript" src="js/baseManage.inc1.js"></script>
	<script type="text/javascript" src="js/<?php echo SCRIPT?>.js"></script>





</head>
<body class="index">

<div id="header" >
	<p class="title">东江湖流域数据管理与综合分析智能中心</p>
	<ul>

		<li><a href="index.php">首页</a></li>
		<li>你好!</li>
		<li class="headerUser">用户名</li>
		<li><a href="index.php">个人设置</a></li>
		<li  id="configure"><a href="manage.php">系统管理</a>
			<div id="conf">
				<table width="119" height="208" border="0">
					<tr>
						<td><a href="#" target="_self">用户管理</a></td>
					</tr>
					<tr>
						<td><a href="#" target="_self">数据库管理</a></td>
					</tr>
					<tr>
						<td><a href="javascritp:window.print() " target="_self">打印机管理</a></td>
					</tr>
					<tr>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td>&nbsp;</td>
					</tr>
				</table>
			</div>
		</li>
		<li id="conflog"></li>
		<li  id="help" ><a href="help.php">帮助</a></li>

		<li class="logout"><a href="logout.php">退出登录</a></li>

	</ul>
</div>

<div id="img"><img src="images/dianti.jpg" alt="东江湖"/> </div>
<div class="module" id="userInfo">
	<?php
		if(isset($_COOKIE['username'])){
			echo '你好，'.$_COOKIE['username'];
			echo '<br/>';
			echo '你于'.$_COOKIE["loginTime"].'开始登录';
			echo '已经登录'.date("Y-m-d H-i-s");
		}else{
			echo '你好，欢迎来到东江湖流域数据综合管理与智能分析系统';
		}

	?>
</div>

<div class="module" id="manage" >
	<!--<p>综合数据管理</p>-->
	<dl id="dataManage">
		<dt>数据资源类别介绍</dt>
		<dd>&nbsp;</dd>
		<dd>
		  <table width="471" height="847" border="0">
		    <tr>
		      <th width="122" height="63" valign="middle" scope="row"><p><img src="images/shuwen1.jpg" width="76" height="53" alt="水文" /> 水文</p></th>
		      <td width="101"><p><img src="images/database1.jpg" width="64" height="45" alt="数据库" /></p>
	          <p>水文</p></td>
		      <td width="113"><p><img src="images/database1.jpg" width="64" height="45" alt="数据库" /></p>
              <p>待定</p></td>
		      <td width="117"><p><img src="images/database1.jpg" width="64" height="45" alt="数据库" /></p>
              <p>待定</p></td>
	        </tr>
		    <tr>
		      <th height="50" scope="row"><img src="huanbao.png" width="76" height="49" alt="环保" />环保</th>
		      <td><p><img src="images/database1.jpg" width="64" height="45" alt="数据库" /></p>
		        <p>环保</p></td>
		      <td>&nbsp;</td>
		      <td>&nbsp;</td>
	        </tr>
		    <tr>
		      <th height="50" scope="row"><img src="images/shuiwei.jpg" width="76" height="48" alt="水位" />水位</th>
		      <td><p><img src="images/database1.jpg" width="64" height="45" alt="数据库" /></p>
		        <p> 水位</p></td>
		      <td>&nbsp;</td>
		      <td>&nbsp;</td>
	        </tr>
		    <tr>
		      <th height="69" scope="row"><img src="qixiang1.jpg" width="76" height="43" alt="气象" />气象</th>
		      <td><p><img src="images/database1.jpg" width="64" height="45" alt="数据库" /></p>
		        <p> 气象</p></td>
		      <td>&nbsp;</td>
		      <td>&nbsp;</td>
	        </tr>
		    <tr>
		      <th height="47" scope="row"><img src="images/xumu.jpg" width="76" height="56" alt="畜牧" />畜牧</th>
		      <td><p><img src="images/database1.jpg" width="64" height="45" alt="数据库" /></p>
		        <p> 畜牧</p></td>
		      <td>&nbsp;</td>
		      <td>&nbsp;</td>
	        </tr>
		    <tr>
		      <th height="48" scope="row"><img src="images/nongye.jpg" width="76" height="52" alt="农业" />农业</th>
		      <td><p><img src="images/database1.jpg" width="64" height="45" alt="数据库" /></p>
		        <p>农调</p></td>
		      <td>&nbsp;</td>
		      <td>&nbsp;</td>
	        </tr>
		    <tr>
		      <th scope="row"><img src="images/renli.jpg" width="76" height="50" alt="财政" />人力</th>
		      <td><p><img src="images/database1.jpg" width="64" height="45" alt="数据库" /></p>
		        <p> 统计</p></td>
		      <td>&nbsp;</td>
		      <td>&nbsp;</td>
	        </tr>
		    <tr>
		      <th height="70" scope="row"><img src="images/yiming.jpg" width="76" height="50" alt="移民" />移民</th>
		      <td><p><img src="images/database1.jpg" width="64" height="45" alt="数据库" /></p>
		        <p> 移民</p></td>
		      <td>&nbsp;</td>
		      <td>&nbsp;</td>
	        </tr>
		    <tr>
		      <th scope="row"><img src="caizheng1.jpg" width="76" height="43" alt="财政" />财政</th>
		      <td><p><img src="images/database1.jpg" width="64" height="45" alt="数据库" /></p>
		        <p> 财政</p></td>
		      <td>&nbsp;</td>
		      <td>&nbsp;</td>
	        </tr>
		    <tr>
		      <th height="21" scope="row">&nbsp;</th>
		      <td colspan="3">&nbsp;</td>
	        </tr>
		    <tr>
		      <th height="21" scope="row">&nbsp;</th>
		      <td colspan="3">&nbsp;</td>
	        </tr>
	      </table>
	  </dd>

	</dl>

</div>
<div class="module" id="analyze">
	<!--<p>综合数据分析</p>-->
	<dl class="operator" id="dataAnalyze">
		<dt>数据资源操作和分析</dt>
		<dd>&nbsp;</dd>
		<dd>
		  <table width="576" height="839">
		    <tr>
		      <th width="124" class="operate" scope="row"><p><a href="search.php"><img src="images/cha.jpg" width="40" height="40" alt="查询" /></a></p>
	          <p><a href="search.php">查询</a></p></th>
		      <td width="440" style="font-style: italic">通过客户端向系统提交约束条件，获取指定的内容。</td>
	        </tr>
		    <tr>
		      <th  class="operate" scope="row" onmouseover="MM_effectHighlight(this, 1000, '#ffffff', '#ff0000', '#ffffff', false)"><p><img src="images/shan.jpg" width="29" height="32" alt="查询" /></p>
              <p>删除</p></th>
		      <td style="font-style: italic">通过客户端向系统提交约束条件，删除指定的内容。</td>
	        </tr>
		    <tr>
		      <th class="operate" scope="row"><p><img src="images/gai.png" width="40" height="40" alt="查询" /></p>
              <p>修改</p></th>
		      <td style="font-style: italic">通过客户端向系统提交约束条件，对指定的内容进行修改。</td>
	        </tr>
		    <tr>
		      <th class="operate" scope="row"><p><img src="images/jia.jpg" width="40" height="40" alt="查询" /></p>
              <p>录入</p></th>
		      <td style="font-style: italic">在客户端键入一条或多条数据，将数据录入数据库服务器</td>
	        </tr>
		    <tr>
		      <th class="operate" scope="row"><p><img src="images/import.png" width="40" height="40" alt="查询" /></p>
              <p>导入</p></th>
		      <td style="font-style: italic">在客户端上传数据库对应的excel文件，sql文件，将数据批量导入数据库服务器。</td>
	        </tr>
		    <tr>
		      <th class="operate" scope="row"><p><img src="images/export.png" width="40" height="40" alt="查询" /></p>
              <p>导出</p></th>
		      <td style="font-style: italic">通过客户端向系统提交约束条件，从数据库服务器导出数据到客户端。</td>
	        </tr>
		    <tr>
		      <th class="operate" scope="row"><p><img src="images/tongjifenxi.jpg" width="54" height="59" alt="查询" /></p>
              <p>统计分析</p></th>
		      <td>通过对数据进行简单的统计分析得到较为直观的统计数据</td>
	        </tr>
		    <tr>
		      <th height="105" class="operate" scope="row" onmouseover="MM_effectHighlight(this, 1000, '#ffffff', '#0033FF', '#0033FF', true)" onmouseout="MM_effectHighlight(this, 1000, '#0033FF', '#FFFFFF', '#ffffff', true)"><p><img src="images/zhinengfenxi.png" width="40" height="40" alt="查询" /></p>
              <p>智能分析</p></th>
		      <td style="font-style: italic">通过聚类，分类，神经网络等技术，对数据进行智能分析，获得较为准确的预测数据</td>
	        </tr>
		    <tr>
		      <th class="operate" scope="row"><p>&nbsp;</p></th>
		      <td>&nbsp;</td>
	        </tr>
		    <tr>
		      <th height="33" class="operate" scope="row"><p>&nbsp;</p></th>
		      <td>&nbsp;</td>
	        </tr>
		    <tr>
		      <th height="83" class="operate" scope="row"><p>&nbsp;</p></th>
		      <td>&nbsp;</td>
	        </tr>
	      </table>
	  </dd>
	</dl>
</div>



<?php 
	require ROOT_PATH.'includes/footer.inc.php';
?>
<script type="text/javascript" src="js/index.js"></script>
</body>
</html>
<!--<p class="depart"> <span class="department">水文：</span>
  <label for="shuiwenxinxi">水文信息</label>
    <input type="radio" name="dbName" id="shuiwenxinxi" value="水文信息" />
    </p>
    <p> <span class="department">环保：</span>
  <label for="shuiwenxinxi">环保信息</label>
    <input type="radio" name="dbName" id="shuiwenxinxi" value="水文信息" />
    </p>
    <p> <span class="department">农业：</span>
  <label for="shuiwenxinxi">农调信息</label>
    <input type="radio" name="dbName" id="shuiwenxinxi" value="水文信息" />
    </p>
    <p> <span class="department">气象：</span>
  <label for="shuiwenxinxi">气象信息</label>
    <input type="radio" name="dbName" id="shuiwenxinxi" value="水文信息" />
    </p>
    <p> <span class="department">人力：</span>
  <label for="shuiwenxinxi">统计信息</label>
    <input type="radio" name="dbName" id="shuiwenxinxi" value="水文信息" />
    </p>
    <p> <span class="department">财政：</span>
  <label for="shuiwenxinxi">财政信息</label>
    <input type="radio" name="dbName" id="shuiwenxinxi" value="水文信息" />
    </p>
     <p> <span class="department">畜牧：</span>
  <label for="shuiwenxinxi">畜牧信息</label>
    <input type="radio" name="dbName" id="shuiwenxinxi" value="水文信息" />
    </p>
     <p> <span class="department">移民：</span>
  <label for="shuiwenxinxi">移民信息</label>
    <input type="radio" name="dbName" id="shuiwenxinxi" value="水文信息" />
    </p>-->
    