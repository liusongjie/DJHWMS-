<?php
/**
* TestGuest Version1.0
* ================================================
* Copy 2010-2012 yc60
* Web: http://www.yc60.com
* ================================================
* Author: Lee
* Date: 2010-8-22
*/
session_start();
define('IN_TG',true);
require dirname(__FILE__).'/includes/common.inc.php';
//登陆成功后，更改登录信息
$updateSql = <<<EOF
				UPDATE djhuser SET 
									loginstate=false
							  WHERE
									username='{$_COOKIE['username']}';
EOF;

pg_query($updateSql);

session_destroy();
_unsetcookies();

?>