
<?php
/**
* TestGuest Version1.0
* ================================================
* Copy 2010-2012 yc60
* Web: http://www.yc60.com
* ================================================
* Author: Lee
* Date: 2010-9-2
*/
//使用pdo连接数据库获取数据
/*$dbms='pgsql';
$host='localhost';
$dbName='postgres';
$user='postgres';
$pass='123456';
$dsn="$dbms:host=$host; dbname=$dbName";
$pdo=new PDO($dsn, $user, $pass);
if ($pdo){
	echo 'success';
}
$sql=<<<EOF
			SELECT username,department,userimg,userfile,email,mobile From djhuser WHERE active=:active;
EOF;
$stmt=$pdo->prepare($query);
$stmt->execute(array(':active'=>false));
$stmt->bindColumn(3, $lobImg, PDO::PARAM_LOB);
$stmt->bindColumn(4, $lobFile, PDO::PARAM_LOB);
$stmt->fetch(PDO::FETCH_BOUND);
//var_dump($rows);
header("Content-Type:image/jpeg");
fpassthru($lobImg);

//var_dump($rows);
header("Content-Type:text/html;charset=utf-8");
fpassthru($lobFile);*/

header("Content-Type:text/html;charset=utf-8");
header("Cache-Control: no-cache");
session_start();
//定义个常量，用来授权调用includes里面的文件
define('IN_TG',true);
//定义个常量，用来指定本页的内容
define('SCRIPT','manage');
//引入公共文件
require dirname(__FILE__).'/includes/common.inc.php';
//必须是管理员才能登录
_manage_login();
global $_conn;
//激活模块
if ($_GET['action']=='active'){
	$pass=rand(1000,9999);
	$upSql1=<<<EOF
			UPDATE djhuser SET password='{$pass}' WHERE username='{$_GET['username']}';
EOF;
	$upResult1=pg_query($upSql1);
	if (pg_affected_rows($upResult1) != 1) {
		_alert_back('激活失败');
	}

	$upSql=<<<EOF
			UPDATE djhuser SET active=true WHERE username='{$_GET['username']}';
EOF;
	$upResult=pg_query($upSql);
	if (pg_affected_rows($upResult) == 1) {
		//收件人邮箱
		$sql=<<<EOF
		SELECT email FROM djhuser where username='{$_GET['username']}';
EOF;
		$res=pg_query($sql);
		$acData=pg_fetch_assoc($res);
		//var_dump($acData);
		require_once "smtp.php";
//使用163邮箱服务器
		$smtpserver = "smtp.163.com";
//163邮箱服务器端口
		$smtpserverport = 25;
//你的163服务器邮箱账号
		$smtpusermail = "13699441014@163.com";
//收件人邮箱

		$smtpemailto = $acData['email'];
//你的邮箱账号(去掉@163.com)
		$smtpuser = "13699441014";//SMTP服务器的用户帐号
//你的邮箱密码
		$smtppass = "428851HE"; //SMTP服务器的用户密码
//邮件主题
		$mailsubject = "激活邮件";
//邮件内容
	/*	$pass=radom(1000,9999);
		$upSql1=<<<EOF
			UPDATE djhuser SET password='{$radom}' username='{$_GET['username']}';
EOF;
		$upResult1=pg_query($upSql1);
		if (pg_affected_rows($upResult1) != 1) {
			_alert_back('激活失败');
		}*/
		$mailbody = "您的账号已被激活，初始密码是".$pass;
//邮件格式（HTML/TXT）,TXT为文本邮件
		$mailtype = "TXT";
//这里面的一个true是表示使用身份验证,否则不使用身份验证.
		$smtp = new smtp($smtpserver,$smtpserverport,true,$smtpuser,$smtppass);
//是否显示发送的调试信息
		$smtp->debug = FALSE;
//发送邮件
		$smtp->sendmail($smtpemailto, $smtpusermail, $mailsubject, $mailbody, $mailtype);
	}
}


$sql=<<<EOF
			SELECT username,department,email,mobile From djhuser WHERE active=false ORDER BY registertime;
EOF;

$result=pg_query($sql);
/*$data=pg_fetch_assoc($result);
var_dump($data);*/
//echo ROOT_PATH;

/*require_once "smtp.php";
//使用163邮箱服务器
$smtpserver = "smtp.163.com";
//163邮箱服务器端口
$smtpserverport = 25;
//你的163服务器邮箱账号
$smtpusermail = "13699441014@163.com";
//收件人邮箱
$smtpemailto = "1024980567@qq.com";
//你的邮箱账号(去掉@163.com)
$smtpuser = "13699441014";//SMTP服务器的用户帐号
//你的邮箱密码
$smtppass = "428851HE"; //SMTP服务器的用户密码
//邮件主题
$mailsubject = "测试邮件发送";
//邮件内容
$mailbody = "PHP+MySQL";
//邮件格式（HTML/TXT）,TXT为文本邮件
$mailtype = "TXT";
//这里面的一个true是表示使用身份验证,否则不使用身份验证.
$smtp = new smtp($smtpserver,$smtpserverport,true,$smtpuser,$smtppass);
//是否显示发送的调试信息
$smtp->debug = TRUE;
//发送邮件
$smtp->sendmail($smtpemailto, $smtpusermail, $mailsubject, $mailbody, $mailtype);*/

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

	<title><?php echo '湖南省郴州东江湖水资源管理'?></title>
	<link rel="shortcut icon" href="dongjianghu.ico" />
	<link rel="stylesheet" type="text/css" href="styles/<?php echo 1?>/basic.css" />
	<script type="text/javascript" src="js/jquery-3.1.0.min.js"></script>
	<link rel="stylesheet" type="text/css" href="js/jQuery-jcDate-master/src/jcDate.css" media="all" />
	<script type="text/javascript" src="js/jQuery-jcDate-master/src/jQuery-jcDate.js" charset="utf-8"></script>


</head>
<body>
<?php 
	require ROOT_PATH.'includes/header.inc.php';
?>

<div id="manage">
<?php 
	require ROOT_PATH.'includes/manage.inc.php';
?>
	<div id="manageMain">
		<h2>会员注册管理</h2>
		<table cellspacing="1">
			<tr><th>用户名</th><th>申请部门</th><th>邮箱</th><th>手机号</th><th>验证图片</th><th>管理</th></tr>
		<?php while(!!$data=pg_fetch_assoc($result)){

		?>
		<tr>
				<?php foreach ($data as $value){
					echo '<td>'.$value.'</td>';
					$url='userdata/'.$data['username'].'.jpg';
					//echo $url;
				} ?>
			<!--<td><img src="thumb.php?filename=<?php /*echo $url*/?>&percent=0.3?>" />thumb.php</td>-->
			<td><img src=<?php echo $url?> /></td>
			<form method="post" action="?action=active&username=<?php echo $data['username']?>">
				<td><input type="submit" value="允许注册" /></td>
			</form>

		</tr>

		<?php
			}
		?>
		</table>
</div>


<?php 
	require ROOT_PATH.'includes/footer.inc.php';
?>
<script type="text/javascript" src="js/manage.js"  ></script>

</body>
</html>
