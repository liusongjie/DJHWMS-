<?php
header("Content-Type:text/html;charset=utf-8");
header("Cache-Control: no-cache");
session_start();
//定义个常量，用来授权调用includes里面的文件
define('IN_TG',true);
//定义个常量，用来指定本页的内容
define('SCRIPT','manageUser');
//引入公共文件
require dirname(__FILE__).'/includes/common.inc.php';
//必须是管理员才能登录
_manage_login();

$logToCh=array('username'=>'用户名','tablename'=>'操作数据库','logintime'=>'上次登录时间','operatetime'=>'操作时间','content'=>'操作内容','ip'=>'IP地址','operation'=>'操作方式',);

//fetch data from log
$logSql=<<<EOF
SELECT * FROM log
EOF;
$logResult=pg_query($logSql);

$fieldsSql=<<<EOF
SELECT a.attname, a.attnotnull as notnull FROM pg_class as c,pg_attribute as a  where c.relname = 'log' and a.attrelid = c.oid and a.attnum>1
EOF;

$fieldsResult=pg_query($fieldsSql);

if($_GET['action']=='logSearch'){
    $logSql=<<<EOF
SELECT * FROM log WHERE {$_POST['category']} like '%{$_POST['searchContent']}%'
EOF;
    $logResult=pg_query($logSql);
}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title><?php echo '湖南省郴州东江湖水资源管理'?></title>
	<link rel="shortcut icon" href="dongjianghu.ico" />
<link rel="stylesheet" type="text/css" href="css/admin_style.css" />
<script src="js/jquery-1.4.4.min.js"></script>
	<!--<link rel="stylesheet" type="text/css" href="templateCss.css"/>-->
<script src="js/iframe.js"></script>
	<style type="text/css">
		* {
			padding:0;
			margin:0;
		}
		body {

			width:1350px;
			margin:0 auto;
			background-color: #cfd4ff;
			position:relative;
		}

div.top_subnav{
	font-size: 20px;
}
		div.body{
			margin-left: -150px;
			width:98%;
			max-height: 900px;
			overflow: auto;
		}
		div.tablelist{
			margin:auto;
			width:94%;
		}
	</style>

</head>
<body class="right_body">
	<div class="body">
		<div class="top_subnav">东江湖流域综合数据管理与智能分析日志管理中心＞ <a href="index.php">首页</a></div>
		<div class="title_h2">
			搜索
		</div>
		<p class="line" style="margin-top:0;">
		</p>
		<form method="post" action="?action=logSearch" >
        <div class="filed fl">
            <span>栏目:</span>
            <select name="category" id="category">
                <?php while($field=pg_fetch_assoc($fieldsResult)){?>
                    <option value="<?php echo $field['attname'];?>"><?php echo $logToCh[$field['attname']];?></option>
                <?php }?>
            </select>
        </div>
		<div class="filed fl">
            <span>关键字:</span>
			<input type="text" class="text" name="searchContent" size="20">
		</div>

		<div class="filed fl">
			<button class="button"></button>
		</div>
		</form>
        
        <div class="tablelist">
		<table class="table">
			<!--<tr>
			<th colspan="8" class="top_th"><a href="#" class="add"><em>添加</em><span></span></a><a href="#" class="edit"><em>编辑</em><span></span></a><a href="#" class="tongji"><em>统计</em><span></span></a><a href="#" class="sort"><em>排序</em><span></span></a></th>
			</tr>-->
			<tr>
				<th>编号</th><th>用户名</th><th>操作数据库</th><th>操作方式</th><th>操作内容</th><th>IP地址</th><th>上次登录时间</th><th>操作时间</th>
			</tr>

<?php while($logRows=pg_fetch_assoc($logResult)){?>
            <tr>
                <?php foreach ($logRows as $logRow){?>
                    <td>
                        <?php echo $logRow; ?>
                    </td>
                <?php }?>


            </tr>

            <?php }?>

		</table>
        </div>
	<!--	<div class="page">
			<ul>
			<li><a href="#" class="pg_index">首页</a></li>
			<li><a href="#" class="pg_selected">1</a></li>
			<li><a href="#">1</a></li>
			<li><a href="#">1</a></li>
			<li><a href="#">1</a></li>
			<li><a href="#">1</a></li>
			<li><a href="#">1</a></li>
			<li><a href="#">1</a></li>
			<li><a href="#">1</a></li>
			<li><a href="#" class="pg_next">下一页</a></li>
			<li><a href="#" class="pg_last">尾页</a></li>
		</ul>
			<p>共有 265 条数据，当前第 1 页</p>

		</div>-->
	</div>
</body>
</html>
