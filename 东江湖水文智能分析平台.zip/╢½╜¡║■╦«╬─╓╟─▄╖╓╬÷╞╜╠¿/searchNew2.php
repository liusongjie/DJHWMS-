<?php
header("Content-Type:text/html;charset=utf-8");
session_start();
//定义个常量，用来授权调用includes里面的文件
define('IN_TG',true);
//定义个常量，用来指定本页的内容
define('SCRIPT','searchNew2');
//引入公共文件
require dirname(__FILE__).'/includes/common.inc.php';

if($_GET['dataBase']=='shuiwenxinxi'){
  // 得到所有字段名
  /*$sql=<<<EOF
      SHOW FULL COLUMNS FROM HYDRAULICTABLE;
      EOF;*/
  //setcookie('tableName','hydraulictable');
  $_SESSION['tableName']='hydraulictable';


  /*$ziduanDis=pg_fetch_assoc($result);
  print_r($ziduanDis);*/
}elseif($_GET['dataBase']=='qixiangxinxi'){
  $_SESSION['tableName']='attable';
}elseif($_GET['dataBase']=='tongjixinxi'){
    $_SESSION['tableName']='zxctable';
}
$sql=<<<EOF
SELECT a.attname, a.attnotnull as notnull FROM pg_class as c,pg_attribute as a  where c.relname = '{$_SESSION['tableName']}' and a.attrelid = c.oid and a.attnum>1
EOF;
//echo $sql;
$result=pg_query($sql);
while($row=pg_fetch_assoc($result)){
  $fields[]=$row;
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

  <title><?php echo '湖南省郴州东江湖水资源管理'?></title>
  <link rel="shortcut icon" href="dongjianghu.ico" />
  <script type="text/javascript" src="js/jquery-3.1.0.min.js"></script>
  <link rel="stylesheet" type="text/css" href="js/jQuery-jcDate-master/src/jcDate.css" media="all" />
  <script type="text/javascript" src="js/jQuery-jcDate-master/src/jQuery-jcDate.js" charset="utf-8"></script>
  <script type="text/javascript" src="js/baseManage.inc1.js"></script>
<script type="text/javascript" src="js/<?php echo SCRIPT?>.js"></script>
<style type="text/css">
/*#header {
	height: 80px;
	z-index: 1;
	background-image: url(images/top1.png);
	background-repeat: repeat;
	line-height: 80px;
	vertical-align: middle;
	visibility: visible;
}*/
body {
  width:1420px;
  margin:0 auto;
  background-color: #cfd4ff;
  font-size:20px;
}
#header {
  width:100%;
  background:url(images/top.png);
  height:72px;
}
img.titile{
    display:inline;
}
#header p.title{
	height: 80px;
	font-size: 32px;
	margin: 0px 0px;
	text-decoration: none;
	text-indent: 0px;
	line-height: 80px;
	font-family: 黑体,"Reenie Beanie",arial,sans-serif,微软雅黑;
	font-weight: 300;
	color: white;
	background-image: url(images/djh-logo.png);
	background-repeat: no-repeat;
	background-position: left;
	padding-left: 50px;
	
	float:left;
}
#header ul {
	text-align: right;
	vertical-align: middle;
	line-height: 80px;
	font-size: 16px;
	font-family: 黑体;
	margin-right: 30px;
	color: white;
	float:right;
}

#header ul li {
	display:inline;
    height:40px;
	line-height: 40px;
}
#header ul li a{
	color:white;
	}
	#header ul li a:hover{
	color:yellow;
	}
#header ul #configure{
    background:url(images/configure.png) no-repeat left;
    width: 20px;
    height: 110px;
    padding-left:20px;
}
#header ul li.headerUser{
    color:yellow;
}
#header ul #conflog{
    margin-left: -5px;
    background:url(images/donwarrow.png) no-repeat left;
    width: 20px;
    height: 100px;
    padding-left:20px;
}
#header ul #help{
    background:url(images/help.png) no-repeat left;
    width: 20px;
    height: 20px;
    padding-left:20px;
}
#header ul li.logout{
    background:url(images/logout.png) no-repeat left;
    width: 20px;
    height: 20px;
    padding-left:20px;
}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	background-image: url(images/database1.jpg);
	background-position: top;
	padding-top: 60px;
}
a:hover {
	text-decoration: underline;
	color: #0F0;
	padding-top: 40px;
}
a:active {
	text-decoration: none;
}
#conf {
	position: absolute;
	border: 2px solid #669;
	left: 1135px;
	top: 62px;
	width: 121px;
	height: 152px;
	z-index: 2;
	font-size: 16px;
	background-color: #36C;
	display:none;
}
#header ul #configure #conf table {
	text-align: center;
}
#selectDB {
	width: 98%;
	height: auto;
	z-index: 2;
	font-size: 18px;
	background-color: #FFFFFF;
	border-radius: 8px;
	margin-top: 5px;
	margin-right: 10px;
	margin-bottom: 5px;
	margin-left: 15px;
	vertical-align: center;
	padding: 0px;
}
#selectDB h2{
	margin:auto;
	text-align: center;
}
#selectDB p{
	background-image: url(images/database1.jpg);
	background-repeat: no-repeat;
	background-position: top;
	padding-top: 29px;
	text-align: center;
	font-size:16px;
}
#selectDB form .department {
	font-weight: bold;
	margin-left: 20px;
	line-height: 30px;
	padding-top: 0px;
	padding-right: 0px;
	padding-bottom: 10px;
	padding-left: 10px;
}

#mainUp {
	width: 98%;
	height: auto;
	z-index: 1;
	margin-top: -15px;
	margin-right: 10px;
	margin-bottom: 10px;
	margin-left: 15px;
	background-color: #FFF;
	border-radius: 8px;
	font-size: 18px;
}
#selectDB h2 strong {
	font-weight: bold;
	color: #36C;
}
#mainUp #operateTitle {
	height: 30px;
	border-bottom-width: 2px;
	border-bottom-style: none;
	border-bottom-color: #399;
	vertical-align: middle;
	text-align: center;
}
h2 {
	color: #39C;
	font-weight: bold;
}
h2 {
	color: #36C;
}
.title2 {
	font-size: 18px;
}
.title2 {
	font-weight: bold;
}
#selectDB form table tr {
	height: 20px;
}
#mainUp form ul {
	list-style-type: none;
}
#mainUp form ul input.searchInput{
	width:60px;
	}
</style>

</head>

<body bgcolor="#cfd4ff">
<div id="header" >
  <p class="title">东江湖流域数据管理与综合分析智能中心</p>
  <ul>
		
		<li><a href="index.php">首页</a></li>
	<li>你好!</li>
        <li class="headerUser">用户名</li>
	<li><a href="index.php">个人设置</a></li>
		<li  id="configure"><a href="manage.php">系统管理</a>
        <div id="conf">
          <table width="119" height="208" border="0">
            <tr>
              <td><a href="#" target="_self">用户管理</a></td>
            </tr>
            <tr>
              <td>日志管理</td>
            </tr>
            <tr>
              <td><a href="#" target="_self">数据库管理</a></td>
            </tr>
            <tr>
              <td><a href="javascritp:window.print() " target="_self">打印机管理</a></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
            </tr>

          </table>
        </div>
</li>
		<li id="conflog"></li>
		<li  id="help" ><a href="help.php">帮助</a></li>

	<li class="logout"><a href="logout.php">退出登录</a></li>
		
  </ul>
</div>

<div id="selectDB">
  <h2><strong>请选择数据库</strong>
  </h2>
  <form method="get" action="">
    <table width="100%" height="180" border="0">
      <tr>
        <td width="8%" height="55"><span class="department">水文：</span></td>
        <td width="12%"><p><a href="./?baseType=shuiwenxinxi">水文信息</a></p></td>
        <td width="11%"><p><a href="./?baseType=nongdiaoxinxi">待定</a></p></td>
        <td width="10%"><p><a href="./?baseType=nongdiaoxinxi">待定</a></p></td>
        <td width="9%">
        <span class="department">农业：</span>
       </td>
        <td width="12%"><p><a href="./?baseType=nongdiaoxinxi">农调信息</a> </p>
        </td>
        <td width="8%"><span class="department">气象：</span></td>
        <td width="12%"><p><a href="./?baseType=nongdiaoxinxi">农调信息</a></p></td>
        <td width="8%"><span class="department">人力：</span></td>
        <td width="10%"><p><a href="./?baseType=renlixinxi">农调信息</a></p></td>
      </tr>
      <tr>
        <td height="64"><span class="department">水文：</span></td>
        <td><p><a href="./?baseType=nongdiaoxinxi">农调信息</a></p></td>
        <td><p><a href="./?baseType=nongdiaoxinxi">农调信息</a></p></td>
        <td><p><a href="./?baseType=nongdiaoxinxi">农调信息</a></p></td>
        <td><span class="department">农业：</span></td>
        <td><p><a href="./?baseType=nongdiaoxinxi">农调信息</a></p></td>
        <td><span class="department">气象：</span></td>
        <td><p><a href="./?baseType=nongdiaoxinxi">农调信息</a></p></td>
        <td><span class="department">人力：</span></td>
        <td><p><a href="./?baseType=nongdiaoxinxi">农调信息</a></p></td>
      </tr>
      <tr>
        <td height="53"><span class="department">水文：</span></td>
        <td><p><a href="./?baseType=nongdiaoxinxi">农调信息</a></p></td>
        <td><p><a href="./?baseType=nongdiaoxinxi">农调信息</a></p></td>
        <td><p><a href="./?baseType=nongdiaoxinxi">农调信息</a></p></td>
        <td><span class="department">农业：</span></td>
        <td><p><a href="./?baseType=nongdiaoxinxi">农调信息</a></p></td>
        <td><span class="department">气象：</span></td>
        <td><p><a href="./?baseType=nongdiaoxinxi">农调信息</a></p></td>
        <td><span class="department">人力：</span></td>
        <td><p><a href="./?baseType=nongdiaoxinxi">农调信息</a></p></td>
      </tr>
    </table>
  </form
>
</div>

<div id="mainUp">
  <h2 id="operateTitle"><strong>水文数据库查询操作</strong></h2>

  <form method="post" action="./?action=search">
  <!--<div class="ziduanzhiyue" id="ziduanzhiyue">--><span class="title2">数据约束条件选择: </span>


    <ul>
      <?php
      $i=0;
      echo $sql;
      echo $_SESSION['tableName'];
      foreach ($fields as $field){
       /*   $strSql1=<<<EOF
SELECT {$field['attname']} FROM {$_SESSION['tableName']} WHERE {$field['attname']}=max('{$field['attname']}')
EOF;*/
          $strSql1=<<<EOF
SELECT {$field['attname']} FROM {$_SESSION['tableName']} WHERE {$field['attname']}=(select min({$field['attname']}) 
                from {$_SESSION['tableName']}) 
EOF;
           echo $strSql1;
          $minResult=pg_query($strSql1);
          $mins=pg_fetch_assoc($minResult);
          $min=$mins[$field['attname']];
          //echo $min;
          $strSql2=<<<EOF
SELECT {$field['attname']} FROM {$_SESSION['tableName']} WHERE {$field['attname']}=(select max({$field['attname']}) 
                from {$_SESSION['tableName']}) 
EOF;
         // echo $strSql2;
          $maxResult=pg_query($strSql2);
          $maxs=pg_fetch_assoc($maxResult);
          $max=$maxs[$field['attname']];
          //echo $max;



          ?>
      <li><?php echo winDisplay($field['attname'])?>(最小:<?php echo $min;?>;最大:<?php echo $max;?>)
      从<input type="text" class="searchInput" name="<?php echo 'first'.$field['attname']?>" />到<input class="searchInput" type="text" name="<?php echo 'second'.$field['attname']?>" />
      </li>
      <?php
        if(++$i%5==0){
          echo '<br/>';
        }
      }?>
    </ul>


  <!--<div class="xianshiziduan" id="xianshiziduan">--><span  class="title2">数据显示字段选择:</span>

        <?php foreach ($fields as $field){?>
          <input type="checkbox" name="displays[]" id="<?php echo $field['attname']?>" value="<?php echo winDisplay($field['attname'])?>" />
        <label for="<?php echo $field['attname']?>"><?php echo winDisplay($field['attname'])?></label>
          <input type="hidden" name="<?php echo $field['attname']?>" value="<?php echo winDisplay($field['attname'])?>" />
          <!--<td><input type="checkbox" name="displays[]" id="date" value="日期" />
        <label for="date">日期</label></td>
          <td><input type="checkbox" name="displays[]" id="precipitation" value="降雨量" />
        <label for="precipitation">降雨量</label></td>
          <td><input type="checkbox" name="displays[]" id="flow" value="平局流量" />
        <label for="flow">平均流量</label></td>-->
        <?php } ?>
        <input type="submit" value="开始查询">
  </form>
</div>


  <?php if($_GET['action']=='search' && isset($_POST["displays"])) {
    //根据制约条件取出数据
   /* $sql=<<<EOF
  SELECT * FORM {$_SESSION['tableName']} WHERE precipitation<1.5;
EOF;*/

    $sqlSearch=<<<EOF
  SELECT * FROM {$_SESSION['tableName']} WHERE precipitation>25;
EOF;
  $resSearch=pg_query($sqlSearch);
    //$rows=pg_fetch_assoc($res);
    //echo $_SESSION['tableName'];
    //print_r($rows);
    ?>
<div id="display">
    <table width="100%" border="1">
  <tr>
    <td>序号</td>
      <?php foreach ($_POST['displays'] as $value){?>
      <td><?php echo $value; ?></td>
      <?php }?>
      <td>是否选择</td>

  </tr>
      <!--有多少条-->
      <?php while($rowsSearch=pg_fetch_assoc($resSearch)){?>
  <tr>
    <td>
      <?php echo $rowsSearch['id']?>
    </td>
    <?php
    //错误理解：外层foreach用的临时变量$value遍历和里层foreach用的临时变量会冲突，解决方法:1去不同名字2将外层变量付给新的变量
    //实际上是函数没写正确，没用返回值;注意没用返回值光输出时$rowsSearch[iniField($value)],没取出结果
    foreach ($_POST['displays'] as $displayValue){?>
      <td>
        <?php
        //print_r($rowsSearch);
        //echo $_SESSION['tableName'];
        //小心函数用echo内部输出和返回值的区别
        /*$key=iniField($value);
        echo $key;*/
        /*//foreach 外部$key变量名作为键值取不出数据
        echo $rowsSearch[$key];*/
        //foreach 时$key变量名作为键值取出了数据
         /*foreach ($rowsSearch as $key=>$value){
          echo $rowsSearch[$key];
        }*/
        $key=iniField($displayValue);
        echo $rowsSearch[$key];
        /*foreach ($rowsSearch as $key=>$fieValue){
          if($key==iniField($disValue)){
            echo $rowsSearch[$key];
          }
        }*/
        ?>
      </td>
    <?php }?>
    <td><input type="checkbox" name="ids[]" value="<?php echo $rowsSearch['id']?>" /></td>
  </tr>
      <?php }?>
</table>


  </div>
<?php }?>

</body>
</html>
