<?php
/**
* TestGuest Version1.0
* ================================================
* Copy 2010-2012 yc60
* Web: http://www.yc60.com
* ================================================
* Author: Lee
* Date: 2010-9-2
*/
header("Content-Type:text/html;charset=utf-8");
session_start();
//定义个常量，用来授权调用includes里面的文件
define('IN_TG',true);
//定义个常量，用来指定本页的内容
define('SCRIPT','shuiwenSuperSearch');
//引入公共文件
require dirname(__FILE__).'/includes/common.inc.php';
/*if($_SESSION['department']!="水文" && $_SESSION['authority']!=2){
    _alert_back('你不是'.$_SESSION['department'].'部门的人');
}*/


/*if(!empty($_GET['area'])){
	header('Location: manage_project.php?area='.$_GET['area']);
}*/
require_once("http://localhost:8080/JavaBridgeTemplate611/java/Java.inc");
/*$search=new Java("AFSearch");
$result=java_values($search->GTSearch());*/
//必须是管理员才能登录
//_manage_login();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php
	//echo ROOT_PATH.'includes/title.inc.php';
	require ROOT_PATH.'includes/title.inc.php';
?>
    <!--<link rel="stylesheet" type="text/css" href="js/jQuery-jcDate-master/src/jcDate.css" media="all" />

    <script type="text/javascript" src="js/jquery-3.1.0.min.js"></script>
    <script type="text/javascript" src="js/jQuery-jcDate-master/src/jQuery-jcDate.js" charset="utf-8"></script>
    <script type="text/javascript" src="js/baseManage.inc1.js"></script>
    <script type="text/javascript" src="js/shuiwenSuperSearch.js"></script>-->
</head>
<body>
<?php
	require ROOT_PATH.'includes/header.inc.php';
?>



<div id="baseManage" >
<?php
	require ROOT_PATH.'includes/baseManage.inc.php';
?>
    <div id="baseManageMain">
        <h2><?php echo $_GET['baseType'].'介绍'?></h2>
            <form id="superSeach" method="get" action="shuiwenSuperSearchResult.php?action=search">
            <dl>
                <dd>
                    <input class="macro" type="checkbox" name="dateSelect"/>是否选择选择查询日期:<br/>
                    <input name="date0" class="jcDate"/>--<input name="date1" class="jcDate"/>
                </dd>
                <dd>
                    <input class="macro" type="checkbox" name="preSelect"/>选择降雨量查询范围(mm):<br/>

                    <label for="GT0"><?php echo "降雨量大于:"?>
                        <input  type="text"   class="getPre" name="GTPre" id="GTPrecipitation" />
                    </label>
                        <input type="radio"  name="precipitation" id="GT0"  checked="checked" value="0"/>
                    <br/>
                    <label for="LT0"><?php echo "降雨量小于:"?>
                        <input type="text" class="getPre"  disabled="disabled" name="LTPre" id="LTPrecipitation"/>
                    </label>
                    <input type="radio" name="precipitation" id="LT0" value="1"/>
                    <br/>

                    <label for="mid0"><?php echo "降雨量大于x且小于y(x<=y):"?>
                        <input type="text" class="getPre"  disabled="disabled" name="midPre0" id="midPrecipitation"/>(底值x)

                        <input type="text" class="getPre"  disabled="disabled" name="midPre1" id="midPrecipitation"/>(顶值y)
                    </label>
                    <input type="radio" name="precipitation" id="mid0" value="2"/>
                    <br/>
                    <!--<label for="side0"><?php /*echo "降雨量小于x或大于y（x<=y）:"*/?>

                        <input type="text" class="getPre"  disabled="disabled" name="midPre0" id="midPrecipitation"/>

                        <input type="text" class="getPre"  disabled="disabled" name="midPre1" id="midPrecipitation"/>
                    </label>
                    <input type="radio" name="precipitation" id="side0" value="3"/>
                    <br/>-->

                  <!--  <label for="min0"><?php /*echo "降雨量极小值:"*/?>
                    </label>
                    <input type="radio" name="precipitation" id="min0" value="4"/>
                    <br/>

                    <label for="max0"><?php /*echo "降雨量极大值:"*/?>
                    </label>
                    <input type="radio" name="precipitation" id="max0" value="5"/>
                    <br/>-->

                </dd>
                <dd>
                    <input class="macro" type="checkbox" name="avgSelect"/>选择平均水流量范围(m3/s):<br/>
                    <label for="GT1"><?php echo "平均流量大于:"?>
                        <input  type="text"   class="getFlow" name="GTFlow" id="GTAvgFlow" />
                    </label>
                    <input type="radio"  name="avgFlow" id="GT1"  checked="checked" value="0"/>
                    <br/>
                    <label for="LT0"><?php echo "平均流量小于:"?>
                        <input type="text" class="getFlow"  disabled="disabled" name="LTFlow" id="LTAvgFlow"/>
                    </label>
                    <input type="radio" name="avgFlow" id="LT1" value="1"/>
                    <br/>

                    <label for="mid1"><?php echo "平均流量大于x且小于y(x<=y):"?>
                        <input type="text" class="getFlow"  disabled="disabled" name="midFlow0" id="midAvgFlow"/>(底值x)

                        <input type="text" class="getFlow"  disabled="disabled" name="midFlow1" id="midAvgFlow"/>(顶值y)
                    </label>
                    <input type="radio" name="avgFlow" id="mid1" value="2"/>
                    <br/>
                    <!--<label for="side1"><?php /*echo "平均流量小于x或大于y（x<=y）:"*/?>

                        <input type="text" class="getFlow"  disabled="disabled" name="sideFlow0" id="midAvgFlow"/>

                        <input type="text" class="getFlow"  disabled="disabled" name="sideFlow1" id="midAvgFlow"/>
                    </label>
                    <input type="radio" name="avgFlow" id="side1" value="3"/>
                    <br/>-->

                  <!--  <label for="min1"><?php /*echo "平均流量极小值:"*/?>
                    </label>
                    <input type="radio" name="avgFlow" id="min1" value="4"/>
                    <br/>

                    <label for="max1"><?php /*echo "平均流量极大值:"*/?>
                    </label>
                    <input type="radio" name="avgFlow" id="max1" value="5"/>
                    <br/>-->

                </dd>
                <input type="hidden" name="baseType" value="<?php echo $_SESSION['department']?>" />
                <input type ="submit" value ="Submit"/>
            </dl>
            </form>

    </div>
</div>


<?php
	require ROOT_PATH.'includes/footer.inc.php';
?>

</body>
</html>
