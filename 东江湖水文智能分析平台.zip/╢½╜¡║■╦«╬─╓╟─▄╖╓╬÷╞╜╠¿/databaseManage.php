
<?php

header("Content-Type:text/html;charset=utf-8");
header("Cache-Control: no-cache");
session_start();
//定义个常量，用来授权调用includes里面的文件
define('IN_TG',true);
//定义个常量，用来指定本页的内容
define('SCRIPT','databaseManage');
//引入公共文件
require dirname(__FILE__).'/includes/common.inc.php';
//必须是管理员才能登录
_manage_login();
global $_conn;

$dbChEn=array('id'=>'序号','ip'=>'ip地址','country'=>'国家','province'=>'省份','city'=>'城市','location'=>'地点','url'=>'url','user'=>'用户','password'=>'密码','createtime'=>'创建时间','usable'=>'操作');
//字段
$dbInfo=<<<EOF
SELECT a.attname, a.attnotnull as notnull FROM pg_class as c,pg_attribute as a  where c.relname = 'dbmanage' and a.attrelid = c.oid and a.attnum>0
EOF;

//启用禁用模块
if(!empty($_POST['usable'])){
	//echo $_POST['usable'];
	//echo $_POST['id'];
	$clean['id']=_pg_string($_POST['id']);
	$clean['usable']=_pg_string($_POST['usable']);
	$upSql1=<<<EOF
			UPDATE dbmanage SET usable='{$clean['usable']}' WHERE id='{$clean['id']}';
EOF;
//	echo $upSql1;
	//echo $upSql1;
	$upResult1=pg_query($upSql1);
	if (pg_affected_rows($upResult1) != 1) {
		_alert_back('操作失败');
	}
}

$dbReusult=pg_query($dbInfo);
/*$fields=pg_fetch_assoc(pg_query($dbInfo));
var_dump($fields);*/
$fields=array();
while($rows=pg_fetch_assoc($dbReusult)){
	$fields[]=$rows['attname'];
}
//var_dump($fields);
//var_dump($fields);
//查询表中数据
$dbContent=<<<EOF
SELECT * FROM dbmanage ORDER BY id;
EOF;
$dbContentResult=pg_query($dbContent);





?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

	<title><?php echo '湖南省郴州东江湖水资源管理'?></title>
	<link rel="shortcut icon" href="dongjianghu.ico" />
	<script type="text/javascript" src="js/jquery-3.1.0.min.js"></script>
	<style type="text/css">
		#manageUser {
			width: 96%;
			min-height: 600px;
			height:auto;
			z-index: 1;
			margin-top: 15px;
			margin-right: 15px;
			margin-bottom: 10px;
			margin-left: 15px;
			background-color: #FFF;
			border-radius: 8px;
			font-size: 18px;
			text-algin: center;
			padding: 10px;
			overflow: auto;
		}
		#selectDB h2 strong {
			font-weight: bold;
			color: #36C;
		}

		#manageUser #operateTitle {
			height: 30px;
			border-bottom-width: 2px;
			border-bottom-style: none;
			border-bottom-color: #399;
			vertical-align: middle;
			text-align: center;
		}
		h2 {
			color: #39C;
			font-weight: bold;
			text-align:center;
		}
		h2 {
			color: #36C;
			font-size: 24px;
		}
		.title2 {
			font-size: 18px;
		}
		.title2 {
			font-weight: bold;
			font-size: 22px;
			color: #000;
		}
		#selectDB form table tr {
			height: 20px;
		}
		#manageUser form ul {
			list-style-type: none;
			height:120px;
			width:95%;
			overflow:auto;
		}
		#manageUser form ul li{

			display:inline-block;
			width:620px;
			height:35px;
		}
		#manageUser form ul li span.searchInfo{
			display:inline-block;
			/*border:red solid 1px;*/
			width:350px;
		}
		#manageUser form ul li span.searchInput{
			width:180px;
		}
		#manageUser form ul input.searchInput{
			width:80px;
		}

		#manageUser form ul.displaySelect{

			height:auto;
			max-height:110px;
			width:95%;
			overflow:auto;
		}
		#manageUser form ul li.displaySelect{

			display:inline-block;
			width:180px;
			height:35px;
		}
		#manageUser form ul li.displayBatch{

			display:block;
			text-align:center;
			width:90%;
			height:35px;
		}
		#manageUser form ul.submit{
			text-align:center;
			width:95%;
			height:75px;
		}
		p .title2 {
			font-size: 20px;
		}
		#manageUser #manageMain p {
			text-align: center;

		}
		#manageMain{
			width: 99%;
			height:100%;
			overflow: auto;
		}
		#manageMain table{
			 width: 99%;
			 overflow: auto;
		 }
		#manageMain table td{
			text-align:center;
		}
		#manageMain span.tdAudit{
			display:inline-block;
			width:150px;
			text-align:center;
		}
		#manageMain span#email{
			display:inline-block;
			width:200px;
		}
		#manageMain span.tdBottom {
			text-align:center;
			display:inline-block;
			width:100px;
		}
	</style>

	<link rel="stylesheet" type="text/css" href="js/jQuery-jcDate-master/src/jcDate.css" media="all" />
	<script type="text/javascript" src="js/jQuery-jcDate-master/src/jQuery-jcDate.js" charset="utf-8"></script>
	<script type="text/javascript" src="js/baseManage.inc1.js"></script>
	<link rel="stylesheet" type="text/css" href="templateCss.css" />


</head>
<body>

<?php
	require ROOT_PATH.'includes/header.inc.php';
?>
<div class="bodyContent">

<div id="manageUser">


	<div id="manageMain" >
		<h2>数据集管理</h2>
			<table border="1" cellspacing="1" >
				<tr>
					<?php
						foreach($fields as $field){
							echo '<th>'.$dbChEn[$field].'</th>';
						}
					?>
					<th></th>
					<!--<th></th>-->
				</tr>
				<?php while(!!$data=pg_fetch_assoc($dbContentResult)) {
					echo '<form method="post" action="">';
					echo '<tr>';
					//var_dump($data);
					//不能用id，每次循环都会获得名为id的框，post传过去之后得到的总是最后一个值，得改用名字唯一的，注意是名字，不是值
					//感觉不科学，采用另一种解决方案，对每个按钮分别采用form
					echo '<input type="hidden" name="id" value="'.$data['id'].'" />';
					foreach ($fields as $field) {

						if ($field=='usable'){

							if ($data[$field]=='t'){
								echo '<td>' .'<input type="submit" name="operation" value="禁用" />'.
									'</td>';
								echo '<input type="hidden" name="usable" value="f" />';
							}else{
								echo '<td>' .'<input type="submit" name="operation" value="启用" />'. '</td>';
								echo '<input type="hidden" name="usable" value="t" />';
							}

							continue;
						}
						//echo $field;
						//echo '<br/>';
						echo '<td>' . $data[$field] . '</td>';

					}
					echo '<td></td>';
					echo '</tr>';
					echo '</form>';
				}
				?>
			</table>
	</div>
</div>
</div>
<?php 
	require ROOT_PATH.'includes/footer.inc.php';
?>
<script type="text/javascript" src="js/<?PHP echo SCRIPT?>.js"  ></script>

</body>
</html>
