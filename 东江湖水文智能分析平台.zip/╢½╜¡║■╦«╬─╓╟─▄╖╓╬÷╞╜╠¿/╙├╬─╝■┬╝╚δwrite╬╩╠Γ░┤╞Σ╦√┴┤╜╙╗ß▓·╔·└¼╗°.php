<?php
header("Content-Type:text/html;charset=utf-8");
session_start();
//定义个常量，用来授权调用includes里面的文件
define('IN_TG',true);
//定义个常量，用来指定本页的内容
define('SCRIPT','write');
//引入公共文件
require dirname(__FILE__).'/includes/common.inc.php';
$maxWriteLength=15;
if(!empty($_SESSION['tableName'])) {
    $sql = <<<EOF
SELECT a.attname, a.attnotnull as notnull FROM pg_class as c,pg_attribute as a  where c.relname = '{$_SESSION['tableName']}' and a.attrelid = c.oid and a.attnum>1
EOF;
//echo $sql;
    $result = pg_query($sql);
    $fields=array();
    while ($row = pg_fetch_assoc($result)) {
        $fields[] = $row;
    }
    //var_dump($fields);
    $fileName = $_COOKIE['username'] . '_' . $_SESSION['tableName'] . '_' . SCRIPT .'.json';
    if ($_GET['firstAction'] == 'preWrite') {
        //$filDir=$_COOKIE['username'];
        //$fileName=$_COOKIE['username'].'_'.$_SESSION['tableName'].'_'.SCRIPT.'.json';
// 显示出来看看
        //var_dump($data1);


        $flag = 1;
        $data=array();
        foreach ($fields as $field5) {

            $data[$field5['attname']] = trim($_GET[$field5['attname']]);
            //echo $field5['attname'];
            //echo $_GET[$field5['attname']];
            if ($data[$field5['attname']] === '') {
                /*echo $field5['attname'];
                echo $_GET[$field5['attname']];
                echo '<br/>';*/
                $flag = 0;
            }
        }
       // exit();
        if ($flag == 0) {
            _alert_back('录入数据字段不能为空,请填写完整');
        }
        $info = '';
//字段不为空时，判断一下是否符合要求
        /* switch($_SESSION['tableName']){
             case 'zxctable':
                 $judge = new Java("Judge");
                 $value=$judge->judgeHY( $_SESSION['tableName'],$_GET);
                 //$value=$batchImport->judgeHY();
                 $info=java_values($value);
                 //echo $info;
                 break;
             case 'rpcitable':
                 $judge = new Java("Judge");
                 $value=$judge->judgeHY( $_SESSION['tableName'],$_GET);
                 $info=java_values($value);
                 // echo $info;
                 break;
             case 'hydraulictable':
                 $judge = new Java("Judge");
                 $value=$judge->judgeHY( $_SESSION['tableName'],$_GET);
                 $info=java_values($value);
                 break;
             case 'attable':
                 $judge = new Java("Judge");
                 $value=$judge->judgeHY( $_SESSION['tableName'],$_GET);
                 $info=java_values($value);
                 break;
             case 'wqmtable':
                 $judge = new Java("Judge");
                 $value=$judge->judgeHY( $_SESSION['tableName'],$_GET);
                 $info=java_values($value);
                 break;
             case 'ftable':
                 $judge = new Java("Judge");
                 $value=$judge->judgeHY( $_SESSION['tableName'],$_GET);
                 $info=java_values($value);
                 break;
             case 'imtable':
                 $judge = new Java("Judge");
                 $value=$judge->judgeHY( $_SESSION['tableName'],$_GET);
                 $info=java_values($value);
                 break;
             case 'lstable':
                 $judge = new Java("Judge");
                 $value=$judge->judgeHY( $_SESSION['tableName'],$_GET);
                 $info=java_values($value);
                 break;
             default:
                 break;
         }*/
        /*$test=array('datetime'=>'5434');
         $judge = new Java("Judge");
         $value=$judge->judgeHY('hydraulictable',$test);
         $info=java_values($value);
         var_dump($info);*/

        /*$arr[]=$data;
        array_push($arr,$data);
        var_dump($arr);*/
//获取json文件里的字符串
        $json_string = file_get_contents($fileName);
        //echo $json_string;
        // echo '<br/>';
        //转化为数组
        if (empty($json_string)) {
            $arr[] = $data;
        } else {
            $arr = json_decode($json_string, true);
            array_push($arr, $data);
        }
        //var_dump($arr);
        //  echo '<br/>';
        //将json字符串写入文件
        $json_string1 = json_encode($arr);
        // echo $json_string1;
        //echo $fileName;
        file_put_contents($fileName, $json_string1);

    }
    if ($_GET['action'] == 'drop') {
        /*    echo "<script type='text/javascript'>isDrop();</script>";*/
//echo '<script>'
        unlink($fileName);
    }
    if ($_GET['action'] == "writeSave") {
        //获取json文件里的字符串
        $json_string = file_get_contents($fileName);
        //echo $json_string;
        // echo '<br/>';
        //转化为数组
        if (empty($json_string)) {
            _alert_back('不能提交空白数据，请先填写数据');
        } else {
            $arr1 = json_decode($json_string, true);
            $idSql = <<<EOF
SELECT id FROM {$_SESSION['tableName']} where id=(SELECT max(id) FROM {$_SESSION['tableName']})
EOF;
            $idTrueMaxs = pg_fetch_assoc(pg_query($idSql));
            $idTrueMax = $idTrueMaxs['id'] + 1;
            foreach ($arr1 as $items) {
                $insertSqlPart = '';
                foreach ($items as $item) {
                    $insertSqlPart .= ' \'' . $item . '\',';
                }
                $insertSqlPart1 = '';
                foreach ($fields as $field8) {
                    $insertSqlPart1 .= $field8['attname'] . ',';
                }
                $insertSqlPartNew = substr($insertSqlPart, 0, -1);
                $insertSqlPart1New = substr($insertSqlPart1, 0, -1);

//echo $insertSql;
                do {
                    $insertSql = <<<EOF
INSERT INTO {$_SESSION['tableName']} (id,$insertSqlPart1New) VALUES ($idTrueMax,$insertSqlPartNew)
EOF;
                    $insertResult = pg_query($insertSql);
                    $idTrueMax++;
                } while (pg_affected_rows($insertResult) != 1);

            }
            _alert_info('录入成功');
            unlink($fileName);
            //从用户库中提取信息
            $userInfoSql = <<<EOF
SELECT lasttime,lastip FROM djhuser WHERE username='{$_COOKIE['username']}'
EOF;
            $infos = pg_fetch_assoc(pg_query($userInfoSql));
            //插入数据库
            $content = count($arr1) . '条数据';
            $upLogSql = <<<EOF
INSERT INTO log (username,tablename,operation,operatetime,content,ip,logintime) VALUES('{$_COOKIE['username']}','{$_SESSION['tableName']}','{$scToCh[SCRIPT]}',NOW(),'{$content}','{$infos['lastip']}','{$infos['lasttime']}')
EOF;
            //  ECHO $upLogSql;
            pg_query($upLogSql);
        }
    }

}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

    <?php require_once('includes/title.inc.php')?>
 <script type="text/javascript" src="js/jquery-3.1.0.min.js"></script>
 <link rel="stylesheet" type="text/css" href="js/jQuery-jcDate-master/src/jcDate.css" media="all" />
 <script type="text/javascript" src="js/jQuery-jcDate-master/src/jQuery-jcDate.js" charset="utf-8"></script>
    <link href="js/jquery-easyui-1.5/themes/default/easyui.css" rel="stylesheet" type="text/css" />
    <link href="js/jquery-easyui-1.5/themes/icon.css" rel="stylesheet" type="text/css" />
    <script src="js/jquery-easyui-1.5/jquery-1.6.4.min.js" type="text/javascript"></script>
    <script src="js/jquery-easyui-1.5/jquery.easyui.min.js" type="text/javascript"></script>
    <script src="js/jquery-easyui-1.5/locale/easyui-lang-zh_CN.js" type="text/javascript"></script>
 <script type="text/javascript" src="js/baseManage.inc1.js"></script>
<link rel="stylesheet" type="text/css" href="templateCss.css"/>
<style type="text/css">
    div.displayClass {
        width: 98%;
        height: auto;
        max-height: 600px;
        z-index: 1;
        background-color: #FFF;
        border-radius: 8px;
        font-size: 18px;
        overflow: auto;
        text-align: center;
    }
    /*div.displayClass div.displayMain{
        width:100px;
    }*/
    div.displayClass table td div.displayMain{
        width:auto;
        min-width:150px;
    }
    div.displayClass table td div.displayMain input{
        width:auto;
        min-width:100px;
        height:25px;
    }
    div.displayClass table td div.displayMainSelect{
        width:100px;
    }
</style>

</head>

<body bgcolor="#cfd4ff">
<?php
require_once("includes/header.inc.php");
require_once("includes/dbSelect.inc.php");
//require_once("includes/dbFieldOperate.php");
?>







  <?php 





 /*   $sqlSearch=<<<EOF
  SELECT * FROM {$_SESSION['tableName']} WHERE ;
EOF;
  $resSearch=pg_query($sqlSearch);*/
    //$rows=pg_fetch_assoc($res);
    //echo $_SESSION['tableName'];
    //print_r($rows);
    ?>

<?php if(!empty($_SESSION['tableName'])){
  ?>



<div id="mainDown">
<h2> 写入临时空间</h2>

  <form id="preWrite" method="get" action="?action=preWrite">
    <div id="displayHeader" class="displayClass">
      <table width="100%" border="1">
        <tr>
          <!--<td><div class="displayMain"></div></td>-->
          <?php foreach ($fields as $field2){?>
            <td><div class="displayMain"><?php echo winDisplay($field2['attname']); ?></div></td>
          <?php }?>
          <!--<td><div class="displayMain">操作</div></td>-->

        </tr>
        <tr>
          <!--<td><div class="displayMain">序号</div></td>-->
          <?php foreach ($fields as $field3){?>
            <td>
                <div class="displayMain">
                    <input type="text" name="<?php echo $field3['attname']?>" />
                </div>
            </td>
          <?php }?>
          <!--<td>
              <div class="displayMain">

              </div>
          </td>-->

        </tr>
        </table>

    </div>
      <p><input type="submit" value="写入"/><input type="hidden" name="firstAction" value="preWrite"/>(未真正写进数据库，需要点击保存才能将数据真正录入数据库)</p>
    </form>
  <form id="write" method="post" action="?action=writeSave">
<div class="displayClass">
    <h2>录入结果预览</h2>
    <table width="100%" border="1">
        <tr>
            <td><div class="displayMain">序号</div></td>
            <?php foreach ($fields as $field6){?>
                <td><div class="displayMain"><?php echo winDisplay($field6['attname']); ?></div></td>
            <?php }?>
            <td></td>

        </tr>
  <!--  </table>
</div>
<div id="display" class="displayClass">

    <table width="100%" border="1">-->
      <!--有多少条-->
      <?php
      $idSql=<<<EOF
SELECT id FROM {$_SESSION['tableName']} where id=(SELECT max(id) FROM {$_SESSION['tableName']})
EOF;
      $idMaxs=pg_fetch_assoc(pg_query($idSql));
      $idMax=$idMaxs['id'];
      foreach($arr as $disAss){?>
  <tr>
      <td>
          <div class="displayMain">
              <?php
              //id

              echo ++$idMax;
              ?>
          </div>
      </td>
    <?php
    //错误理解：外层foreach用的临时变量$value遍历和里层foreach用的临时变量会冲突，解决方法:1去不同名字2将外层变量付给新的变量
    //实际上是函数没写正确，没用返回值;注意没用返回值光输出时$rowsSearch[iniField($value)],没取出结果
    foreach ($fields as $field4){?>
      <td>
        <div class="displayMain">
            <?php
            /*$key=iniField($field4['attname']);
          echo $rowsSearch[$key];*/
            echo $disAss[$field4['attname']];
            ?></div>

      </td>
    <?php }?>
  </tr>
      <?php }?>
</table>
</div>
   <!-- <input class="selectSimpleInput" type="checkbox" name="selectAll" id="selectAll"  />
    <label for="selectAll">全选</label>
    <input type="checkbox" class="selectSimpleInput" name="selectReverse" id="selectReverse"  />
    <label for="selectReverse">反选</label>
    <input id="delete" type="submit" value="删除"/>-->
      <p><input id="drop" onclick="javascript:window.location.href='?action=drop';"  type="button" value="放弃"/>  <input id="save" type="submit" value="保存"/></p>
  </form>



</div>
<?php }
if($_SESSION['mainUpFlag']!=1){
    echo '<div id="placeHolder" style="height:400px;"></div>';
}

?>

<?php require_once("includes/footer.inc.php")?>
<script type="text/javascript" src="js/<?php echo SCRIPT?>.js"></script>
</body>
</html>
