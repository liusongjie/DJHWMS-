<div class="mainUp">
    <h2 id="operateTitle"><?php echo $_SESSION['tableCh']?>数据库备份操作</h2>

    <form enctype="multipart/form-data" method="post" action="export.php?action=download">



        <span  class="title2">数据库备份方式选择:</span>
        <ul class="methodSelect">

            <li class="methodSelect"><input class="methodSelect" type="radio" name="exportMethod"  checked="checked" id="exportMethod1" value="全部备份"  />
                <label for="exportMethod1">全部备份</label></li>
            <li class="methodSelect"><input class="methodSelect" type="radio" name="exportMethod"
                                            disabled="disabled"    id="exportMethod2" value="差异备份" />
                <label for="exportMethod2">差异备份</label></li>
            <!--<li class="methodSelect"><input class="methodSelect" type="radio" name="exportMethod"
                                            disabled="disabled"             id="exportMethod" value="修改导出"/>
              <label for="exportMethod3">修改导出</label></li>-->
        </ul>
        <span  class="title2">数据库备份位置选择:</span>
        <ul class="methodSelect">

            <li class="methodSelect"><input class="methodSelect" type="radio" name="exportMethod"  checked="checked" id="exportMethod1" value="备份至远程服务器"  />
                <label for="exportMethod1">备份至远程服务器</label></li>
            <li class="methodSelect"><input class="methodSelect" type="radio" name="exportMethod"
                                            disabled="disabled"    id="exportMethod2" value="备份到本地" />
                <label for="exportMethod2">备份到本地</label></li>
            <!--<li class="methodSelect"><input class="methodSelect" type="radio" name="exportMethod"
                                            disabled="disabled"             id="exportMethod" value="修改导出"/>
              <label for="exportMethod3">修改导出</label></li>-->
        </ul>
        <ul class="submit">
            <li>
                <input type="submit" value="开始备份">
            </li>
        </ul>
    </form>

</div>

<div class="mainUp">
    <h2 id="operateTitle"><?php echo $_SESSION['tableCh']?>数据库操作</h2>

    <form enctype="multipart/form-data" method="post" action="export.php?action=download">



        <span  class="title2">数据库备份方式选择:</span>
        <ul class="methodSelect">

            <li class="methodSelect"><input class="methodSelect" type="radio" name="exportMethod"  checked="checked" id="exportMethod1" value="全部备份"  />
                <label for="exportMethod1">全部备份</label></li>
            <li class="methodSelect"><input class="methodSelect" type="radio" name="exportMethod"
                                            disabled="disabled"    id="exportMethod2" value="差异备份" />
                <label for="exportMethod2">差异备份</label></li>
            <!--<li class="methodSelect"><input class="methodSelect" type="radio" name="exportMethod"
                                            disabled="disabled"             id="exportMethod" value="修改导出"/>
              <label for="exportMethod3">修改导出</label></li>-->
        </ul>
        <span  class="title2">数据库备份位置选择:</span>
        <ul class="methodSelect">

            <li class="methodSelect"><input class="methodSelect" type="radio" name="exportMethod"  checked="checked" id="exportMethod1" value="备份至远程服务器"  />
                <label for="exportMethod1">备份至远程服务器</label></li>
            <li class="methodSelect"><input class="methodSelect" type="radio" name="exportMethod"
                                            disabled="disabled"    id="exportMethod2" value="备份到本地" />
                <label for="exportMethod2">备份到本地</label></li>
            <!--<li class="methodSelect"><input class="methodSelect" type="radio" name="exportMethod"
                                            disabled="disabled"             id="exportMethod" value="修改导出"/>
              <label for="exportMethod3">修改导出</label></li>-->
        </ul>
        <ul class="submit">
            <li>
                <input type="submit" value="开始备份">
            </li>
        </ul>
    </form>

</div>

<div class="mainUp">
    <h2 id="operateTitle"><?php echo $_SESSION['tableCh']?>数据库备份操作</h2>

    <form enctype="multipart/form-data" method="post" action="export.php?action=download">



        <span  class="title2">数据库备份方式选择:</span>
        <ul class="methodSelect">

            <li class="methodSelect"><input class="methodSelect" type="radio" name="exportMethod"  checked="checked" id="exportMethod1" value="全部备份"  />
                <label for="exportMethod1">全部备份</label></li>
            <li class="methodSelect"><input class="methodSelect" type="radio" name="exportMethod"
                                            disabled="disabled"    id="exportMethod2" value="差异备份" />
                <label for="exportMethod2">差异备份</label></li>
            <!--<li class="methodSelect"><input class="methodSelect" type="radio" name="exportMethod"
                                            disabled="disabled"             id="exportMethod" value="修改导出"/>
              <label for="exportMethod3">修改导出</label></li>-->
        </ul>
        <span  class="title2">数据库备份位置选择:</span>
        <ul class="methodSelect">

            <li class="methodSelect"><input class="methodSelect" type="radio" name="exportMethod"  checked="checked" id="exportMethod1" value="备份至远程服务器"  />
                <label for="exportMethod1">备份至远程服务器</label></li>
            <li class="methodSelect"><input class="methodSelect" type="radio" name="exportMethod"
                                            disabled="disabled"    id="exportMethod2" value="备份到本地" />
                <label for="exportMethod2">备份到本地</label></li>
            <!--<li class="methodSelect"><input class="methodSelect" type="radio" name="exportMethod"
                                            disabled="disabled"             id="exportMethod" value="修改导出"/>
              <label for="exportMethod3">修改导出</label></li>-->
        </ul>
        <ul class="submit">
            <li>
                <input type="submit" value="开始备份">
            </li>
        </ul>
    </form>

</div>