<?php
/*$file_name = 'hetong_wqmtable1475992321.xls';
//$file_name=iconv("utf-8","gb2312",$file_name);
$file_path =  'C:\\Apache24\\htdocs\\export\\hetong_wqmtable1475992321.xls';
$filePath = addslashes($file_path);
Header("Content-type: application/octet-stream");
Header("Accept-Ranges: bytes");
Header("Accept-Length:".$file_size);
//note;这里用到了$file_name
Header("Content-Disposition: attachment; filename=".$file_name);
$fp=fopen($file_path,'rb');
fread($fp);
fclose($fp);*/
echo $_GET['date'];
?>


<!DOCTYPE html>
<html>
<head>
</head>

<body >
<form method="get" action="?">
    <input type="date" name="date" value="2016-11-09">
<input type="submit">
</form>
</body>
</html>
