<?php
/**
 * TestGuest Version1.0
 * ================================================
 * Copy 2010-2012 yc60
 * Web: http://www.yc60.com
 * ================================================
 * Author: Lee
 * Date: 2010-9-2
 */
header("Content-Type:text/html;charset=utf-8");
session_start();
//定义个常量，用来授权调用includes里面的文件
define('IN_TG',true);
//定义个常量，用来指定本页的内容
define('SCRIPT','baseManage');
//引入公共文件
require dirname(__FILE__).'/includes/common.inc.php';
require_once("http://localhost:8080/JavaBridgeTemplate611/java/Java.inc");
if($_SESSION['department']=="水文"){
    $search=new Java("ConvertList");
    $result=java_values($search->convertList());
}else{
    echo '你不是'.$_SESSION['department'].'部门的人';
}


//echo $result[0]["datetime"];
/*if(!empty($_GET['area'])){
	header('Location: manage_project.php?area='.$_GET['area']);
}*/

//必须是管理员才能登录
//_manage_login();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <?php
    //echo ROOT_PATH.'includes/title.inc.php';
    require ROOT_PATH.'includes/title.inc.php';
    ?>
    <script type="text/javascript" src="js/jquery-3.1.0.min.js"></script>
    <!--  <script type="text/javascript" src="js/baseManage.header.js"></script>-->
</head>
<body>
<?php
require ROOT_PATH.'includes/header.inc.php';
?>

<script type="text/javascript">
    /*$(document).ready(function(){
        // alert(4);
        /!* $('#baseManage').on('click',function(){
         alert(2);
         $.ajax({
         type:"GET",
         url:"batchImport.php?baseType=水文",
         dataType:"text",
         success:showState
         });*!/
        /!* alert(1);
         $.ajax({
         type:"GET",
         url:"http://localhost:8082/dongjianghu2/batchImport.php?baseType=水文",
         dataType:"text",
         success:showState
         });*!/
        /!* function showState(){
         alert(2);
         }*!/

    });
    function batchImport(){
        //  alert(5);
        $.ajax({
            type:"GET",
            url:"batchImport.php?baseType=水文",
            dataType:"text",
            success:showState
        });

    }
    function showState(){
        alert(2);
    }*/

    /*function batchImport(){
     alert(1);
     $.ajax({
     type:"GET",
     url:"http://localhost:8082/dongjianghu2/batchImport.php?baseType=水文",
     dataType:"text",
     success:showState
     });
     }

     function showState(){
     alert(2);
     }*/

</script>

<div id="baseManage" >
    <?php
    require ROOT_PATH.'includes/baseManage.inc.php';
    ?>
    <div id="baseManageMain">
        <h2><?php echo $_GET['baseType'].'介绍'?></h2>
    </div>
</div>


<?php
require ROOT_PATH.'includes/footer.inc.php';
?>
<script type="text/javascript" src="js/baseManage.inc.js"></script>
</body>
</html>
