<?php
header("Content-Type:text/html;charset=utf-8");
session_start();
//定义个常量，用来授权调用includes里面的文件
define('IN_TG',true);
//定义个常量，用来指定本页的内容
define('SCRIPT','intelAnalyze');
//引入公共文件
require dirname(__FILE__).'/includes/common.inc.php';

//目前只有环保数据库能用
if(!empty($_SESSION['tableName'])){
    if($_SESSION['tableName']!='wqmtable'){
      /*  $_SESSION['tableName']='';
        $_SESSION['tableCh']='';*/
        $_SESSION['tableName']=NULL;
        $_SESSION['tableCh']=NULL;
       // _alert_back('此数据库暂未开通智能分析功能');
       // echo "<script type='text/javascript'>msgbox('提示','wenshenme','',null,0,'Warning');history.back();</script>";
echo '<div display="none"></div>';

        echo '<script language="javascript" type="text/javascript">
    function msgbox(title,content,func,cancel,focus,icon){
        icon="msgbox_"+icon+".png";
        create_mask();
        
        var temp="<div style=\'width:300px;border: 2px solid #37B6D1;background-color: #fff; font-weight: bold;font-size: 12px;\' >"
				+"<div style=\'line-height:25px; padding:0px 5px;	background-color: #37B6D1;\'>"+title+"</div>"
				+"<table  cellspacing=\'0\' border=\'0\'><tr><td style=\' padding:0px 0px 0px 20px; \'><img src=\'"+icon+"\' width=\'64\' height=\'64\'></td>"
				+"<td ><div style=\'background-color: #fff; font-weight: bold;font-size: 12px;padding:20px 0px ; text-align:left;\'>"+content
				+"</div></td></tr></table>"
				+"<div style=\'text-align:center; padding:0px 0px 20px;background-color: #fff;\'><input type=\'button\'  style=\'border:1px solid #CCC; background-color:#CCC; width:50px; height:25px;\' value=\'确定\'id=\'msgconfirmb\'   onclick=\'remove();"+func+";history.back();\'>";
		
        if(null!=cancel){temp+="&nbsp;&nbsp;&nbsp;<input type=\'button\' style=\'border:1px solid #CCC; background-color:#CCC; width:50px; height:25px;\' value=\'取消\'  id=\'msgcancelb\'   onClick=\'remove()\'>";}
        temp+="</div></div>";
        create_msgbox(400,200,temp);
        if(focus==0||focus=="0"||null==focus){document.getElementById("msgconfirmb").focus();}
        else if(focus==1||focus=="1"){document.getElementById("msgcancelb").focus();}
    }
    function get_width(){
        return (document.body.clientWidth+document.body.scrollLeft);
    }
    function get_height(){
        return (document.body.clientHeight+document.body.scrollTop);
    }
    function get_left(w){
        var bw=document.body.clientWidth;
        var bh=document.body.clientHeight;
        w=parseFloat(w);
        return (bw/2-w/2+document.body.scrollLeft);
    }
    function get_top(h){
        var bw=document.body.clientWidth;
        var bh=document.body.clientHeight;
        h=parseFloat(h);
        return (bh/2-h/2+document.body.scrollTop);
    }
    function create_mask(){//创建遮罩层的函数
        var mask=document.createElement("div");
        mask.id="mask";
        mask.style.position="absolute";
        mask.style.filter="progid:DXImageTransform.Microsoft.Alpha(style=4,opacity=25)";//IE的不透明设置
        mask.style.opacity=0.4;//Mozilla的不透明设置
        mask.style.background="black";
        mask.style.top="0px";
        mask.style.left="0px";
        mask.style.width=get_width();
        mask.style.height=get_height();
        mask.style.zIndex=1000;
        document.body.appendChild(mask);
    }
    function create_msgbox(w,h,t){//创建弹出对话框的函数
        var box=document.createElement("div")	;
        box.id="msgbox";
        box.style.position="absolute";
        box.style.width=w;
        box.style.height=h;
        box.style.overflow="visible";
        box.innerHTML=t;
        box.style.zIndex=1001;
        document.body.appendChild(box);
        re_pos();
    }
    function re_mask(){
        /*
         更改遮罩层的大小,确保在滚动以及窗口大小改变时还可以覆盖所有的内容
         */
        var mask=document.getElementById("mask")	;
        if(null==mask)return;
        mask.style.width=get_width()+"px";
        mask.style.height=get_height()+"px";
    }
    function re_pos(){
        /*
         更改弹出对话框层的位置,确保在滚动以及窗口大小改变时一直保持在网页的最中间
         */
        var box=document.getElementById("msgbox");
        if(null!=box){
            var w=box.style.width;
            var h=box.style.height;
            box.style.left=get_left(w)+"px";
            box.style.top=get_top(h)+"px";
        }
    }
    function remove(){
        /*
         清除遮罩层以及弹出的对话框
         */
        var mask=document.getElementById("mask");
        var msgbox=document.getElementById("msgbox");
        if(null==mask&&null==msgbox)return;
        document.body.removeChild(mask);
        document.body.removeChild(msgbox);
    }

    function re_show(){
        /*
         重新显示遮罩层以及弹出窗口元素
         */
        re_pos();
        re_mask();
    }
    function load_func(){
        /*
         加载函数,覆盖window的onresize和onscroll函数
         */
        window.onresize=re_show;
        window.onscroll=re_show;
    }
    if(msgbox("提示","wenshenme","",null,0,"Warning")){
        history.back();
    };
</script>';


        exit();

    }



$sql=<<<EOF
SELECT a.attname, a.attnotnull as notnull FROM pg_class as c,pg_attribute as a  where c.relname = '{$_SESSION['tableName']}' and a.attrelid = c.oid and a.attnum>1
EOF;
//echo $sql;
$result=pg_query($sql);
while($row=pg_fetch_assoc($result)){
    $fields[]=$row;
}

//设置访问界面，因为跨界面，所以用全局变量，session较熟悉,而cookie要重定位


$placeToCh=array('bailang'=>'白廊','chukou'=>'滁口','dongping'=>'东坪');
if($_GET['action']=='intelAnalyze'){

    if ($_GET['intelPlace']=='--地点--' || $_GET['intelTime']=='--时间--'){
        _alert_back('请选择时间和地点');
    }
    $imgUrl='www/'.$_GET['intelPlace'].$_GET['intelTime'].'0.jpg';
}

}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

    <title><?php echo '湖南省郴州东江湖水资源管理'?></title>
    <link rel="shortcut icon" href="dongjianghu.ico" />
    <script type="text/javascript" src="js/jquery-3.1.0.min.js"></script>
    <link rel="stylesheet" type="text/css" href="js/jQuery-jcDate-master/src/jcDate.css" media="all" />
    <script type="text/javascript" src="js/jQuery-jcDate-master/src/jQuery-jcDate.js" charset="utf-8"></script>
    <script type="text/javascript" src="js/baseManage.inc1.js"></script>
    <link rel="stylesheet" type="text/css" href="templateCss.css"/>
    <style type="text/css">

        #mainUp  ul {
            list-style-type: none;
            height:120px;
            width:1300px;
            overflow:auto;
        }
        #mainUp  ul li{

            display:inline-block;
            width:620px;
            height:35px;
        }
        #mainUp  ul li span.searchInfo{
            display:inline-block;
            /*border:red solid 1px;*/
            width:350px;
        }
        #mainUp  ul li span.searchInput{
            width:180px;
        }
        #mainUp  ul input.searchInput{
            width:60px;
        }

        #mainUp  ul.displaySelect{

            height:110px;
            width:1300px;
            overflow-y:auto;
            overflow-x:hidden;
        }
        #mainUp  ul li.displaySelect{

            display:inline-block;
            width:170px;
            height:35px;
        }
        #mainUp  ul li.displayBatch{

            display:block;
            text-align:center;
            width:1300px;
            height:35px;
        }
        #mainUp  ul.submit{
            text-align:center;
            width:1300px;
            height:35px;
        }
        #mainUp  ul.methodSelect{
            height:35px;
        }
        #mainUp  ul li.methodSelect{

            display:inline-block;
            width:320px;
            height:35px;
        }
        #apDiv1 {
            position: absolute;
            left: 1074px;
            top: 381px;
            width: 157px;
            height: 42px;
            z-index: 3;
        }
    </style>

</head>

<body bgcolor="#cfd4ff">
<?php
require_once("includes/header.inc.php");
require_once("includes/dbSelect.inc.php");
?>

<?php if($_SESSION['mainUpFlag']==1 &&$_SESSION['tableName']=='wqmtable'){?>
<div id="mainUp">
    <h2 id="operateTitle"><strong><?php echo $_SESSION['tableCh']?>数据集智能分析</strong></h2>

    <form method="get" action="?action=intelAnalyze">
        <span  class="title2">请选择地点和时间:</span>
        地点：<select id="intelPlace" name="intelPlace">
            <option >--地点--</option>
            <option value="chukou">滁口</option>
            <option value="dongping">东坪</option>
            <option value="bailang">白廊</option>
        </select>

        时间：<select id="intelTime" name="intelTime">
            <option>--时间--</option>
        </select>


        <ul class="submit">
            <li>
                <input type="submit" value="开始分析">
                <input type="hidden" name="action" value="intelAnalyze">
            </li>
        </ul>
        </form>

</div>
<?php }?>

<?php if($_GET['action']=='intelAnalyze'){?>
<div id="mainDown">
    <h2 id="operateTitle"><strong><?php echo $_SESSION['tableCh']?>分析结果</strong></h2>
    <div>
        <!--<img alt="分析结果" src="C:/www/1.jpg" />-->
        <img alt="分析结果" src="<?php  echo $imgUrl;?>" />
    </div>
</div>
<?php }
if($_SESSION['mainUpFlag']!=1){
    echo '<div id="placeHolder" style="height:400px;"></div>';
}
?>
<?php require_once('includes/footer.inc.php');?>



<script type="text/javascript" src="js/<?php echo SCRIPT?>.js"></script>
</body>
</html>
