<?php
session_start();
//定义个常量，用来授权调用includes里面的文件
define('IN_TG',true);
//定义个常量，用来指定本页的内容
define('SCRIPT','simpleImport');
//引入公共文件
require dirname(__FILE__).'/includes/common.inc.php';

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>单条导入</title>
    <?php
    require ROOT_PATH.'includes/title.inc.php';
    ?>
<!--<script type="text/javascript" src="js/baseManage.header.js"></script>-->
</head>
<body class="simpleImport">
    <div >
        <form method="get" action="?action=search">
            <dl>
           <dd> <span>请输入id:&nbsp&nbsp&nbsp&nbsp&nbsp</span><input type="text" id="id" /><br/></dd>
            <dd>   <span>请输入时间:&nbsp&nbsp&nbsp&nbsp</span><input type="text" id="datetime" /><br/></dd>
            <dd>    <span>请输入逐日降水量:&nbsp</span><input type="text" id="percipitation" /><br/></dd>
            <dd>   <span>请输入逐日平均流量:</span><input type="text" id="avgflw" /><br/></dd>
            <dd>   <input type="hidden" id="baseType" value="<?php echo $_GET['baseType'];?>"></dd>
            <dd>   <input type="submit"  value="添加" name="submit"/></dd>
            </dl>
        </form>
    </div>
    <script type="text/javascript" src="js/idSearch.js"></script>
</body>