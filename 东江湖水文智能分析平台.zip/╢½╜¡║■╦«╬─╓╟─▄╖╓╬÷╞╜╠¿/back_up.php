<?php
/**
 * Created by PhpStorm.
 * User: hetong
 * Date: 2016/9/26
 * Time: 10:57
 */$sql = <<<EOF
			SELECT username,authority,department,loginstate,active From djhuser WHERE username='{$_clean['username']}' AND password='{$_clean['password']}';
EOF;
//echo $sql;
$result = pg_query($sql);
//$rows=pg_fetch_array($result,PGSQL_ASSOC);
$rows = pg_fetch_assoc($result);

if (!!$rows) {
    //echo $rows['username'];
    //不允许用户异地登录
    /*if($rows['loginstate']==true){
        _alert_back('你的账号已经在其他地方登陆');
    }*/
    if ($rows['active'] == false) {
        _alert_back('你的账号未激活');
    }
    //登陆成功后，更改登录信息
    $updateSql = <<<EOF
				UPDATE djhuser SET 
									loginState=true,
									lastTime=NOW(),
									lastIp='{$_SERVER['REMOTE_ADDR']}',
									loginCount=loginCount+1
							  WHERE
									username='{$rows['username']}';
EOF;

    pg_query($updateSql);
    //_setcookies($_clean['username']);
    setcookie('username',$_clean['username']);
    setcookie('loginTime', time());
    //慢半拍要刷新

    echo $_COOKIE['username'];
    if ($rows['authority'] == 1) {
        $_SESSION['authority'] = 1;
        $_SESSION['superUser'] = $_clean['username'];
    } elseif ($rows['authority'] == 2) {
        $_SESSION['authority'] = 2;
        $_SESSION['admin'] = $_clean['username'];
    }
    //记录用户所属部门

    $_SESSION['department'] = $rows['department'];
    pg_close();
    //pg_errormessage($_conn);
    //设置了cookie，重新刷新，解决cookie 慢半拍的问题
    _location(null, 'index.php');
} else {
    _close();
    //echo "failed";
    _session_destroy();
    _location('用户名密码不正确或者该账户未被激活！', 'index.php?fres=new');
}