<?php
/**
 * Created by PhpStorm.
 * User: hetong
 * Date: 2016/10/24
 * Time: 16:14
 */
function checkField($fieldData,$min,$max,$fieldName){
    if ($fieldData<$min || $fieldData>$max){
        _alert_back('你填入的数据超过限制，请重新输入');
    }
}

function checkAll($fieldData,$fieldName){
    if($_SESSION['tableName']=='hydraulictable'){
        if($fieldName=='xx'){
            checkField($fieldData,$min,$max);
        }elseif($fieldName=='xx'){

        }
    }elseif($_SESSION['tableName']=='hydraulictable'){
        if($fieldName=='xx'){
            checkField($fieldData,$min,$max);
        }elseif($fieldName=='xx'){

        }
    }

}
