<?php
header("Content-Type:text/html;charset=utf-8");
session_start();
//定义个常量，用来授权调用includes里面的文件
define('IN_TG',true);
//定义个常量，用来指定本页的内容
define('SCRIPT','searchNew');
//引入公共文件
require dirname(__FILE__).'/includes/common.inc.php';

if($_GET['dataBase']=='shuiwenxinxi'){
    // 得到所有字段名
    /*$sql=<<<EOF
        SHOW FULL COLUMNS FROM HYDRAULICTABLE;
        EOF;*/
    //setcookie('tableName','hydraulictable');
    $_SESSION['tableName']='hydraulictable';


    /*$ziduanDis=pg_fetch_assoc($result);
    print_r($ziduanDis);*/
}elseif($_GET['dataBase']=='qixiangxinxi'){
    $_SESSION['tableName']='attable';
}
$sql=<<<EOF
         select attname from pg_attribute where attrelid = ( select relfilenode from pg_class where relname = '{$_SESSION['tableName']}') and attnum>0
EOF;
$result=pg_query($sql);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>

<style type="text/css">
#header {
	position: absolute;
	left: 0px;
	top: 0px;
	width: 100%;
	height: 80px;
	z-index: 1;
	background-image: url(images/top1.png);
	background-repeat: repeat;
	line-height:80px;
	 vertical-align: middle;
}
img.titile{
    display:inline;
}
#header p.title{
	height: 80px;
	font-size: 32px;
	margin: 0px 0px;
	text-decoration: none;
	text-indent: 0px;
	line-height: 80px;
	font-family: 黑体,"Reenie Beanie",arial,sans-serif,微软雅黑;
	font-weight: 300;
	color: white;
	background-image: url(images/djh-logo.png);
	background-repeat: no-repeat;
	background-position: left;
	padding-left: 50px;
	
	float:left;
}
#header ul {
	text-align: right;
	vertical-align: middle;
	line-height: 80px;
	font-size: 16px;
	font-family: 黑体;
	margin-right: 30px;
	color: white;
	float:right;
}

#header ul li {
	display:inline;
    height:40px;
	line-height: 40px;
}
#header ul li a{
	color:white;
	}
	#header ul li a:hover{
	color:yellow;
	}
#header ul #configure{
    background:url(images/configure.png) no-repeat left;
    width: 20px;
    height: 100px;
    padding-left:20px;
}
#header ul li.headerUser{
    color:yellow;
}
#header ul #conflog{
    margin-left: -5px;
    background:url(images/donwarrow.png) no-repeat left;
    width: 20px;
    height: 100px;
    padding-left:20px;
}
#header ul #help{
    background:url(images/help.png) no-repeat left;
    width: 20px;
    height: 20px;
    padding-left:20px;
}
#header ul li.logout{
    background:url(images/logout.png) no-repeat left;
    width: 20px;
    height: 20px;
    padding-left:20px;
}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: underline;
	color: #0F0;
}
a:active {
	text-decoration: none;
}
#apDiv1 {
	position: absolute;
	border: 2px solid #669;
	left: 1165px;
	top: 65px;
	width: 121px;
	height: 152px;
	z-index: 2;
	font-size: 16px;
	background: blue;
	visibility: hidden;
}
#header ul #configure #apDiv1 table {
	text-align: center;
}
#selectDB {
	position: absolute;
	left: 0px;
	top: 80px;
	width: 98%;
	height: 170px;
	z-index: 2;
	font-size: 18px;
	background-color: #FFFFFF;
	border-radius: 8px;
	margin-top: 5px;
	margin-right: 10px;
	margin-bottom: 10px;
	margin-left: 15px;
	vertical-align: center;
	padding: 0px;
}
#selectDB h2{
	margin:auto;
	text-align: center;
}
#selectDB p{
	display:inline;
}
#selectDB form .department {
	font-weight: bold;
	margin-left: 20px;
	line-height: 30px;
	padding-top: 0px;
	padding-right: 0px;
	padding-bottom: 10px;
	padding-left: 10px;
}
#main {
	position: absolute;
	left: 18px;
	top: 266px;
	width: 98%;
	height: 509px;
	z-index: 1;
	background-color: #FFF;
	border-radius: 8px;
}
#selectDB h2 strong {
	font-weight: bold;
	color: #36C;
}
#main .operateTitle {
	text-align: center;
	height: 40px;
	border-bottom-width: 2px;
	border-bottom-style: none;
	border-bottom-color: #399;
	vertical-align: middle;
}
h2 {
	color: #39C;
	font-weight: bold;
}
h2 {
	color: #36C;
}
.title2 {
	font-size: 18px;
}
.title2 {
	font-weight: bold;
}
</style>
<script type="text/javascript">
function MM_showHideLayers() { //v9.0
  var i,p,v,obj,args=MM_showHideLayers.arguments;
  for (i=0; i<(args.length-2); i+=3) 
  with (document) if (getElementById && ((obj=getElementById(args[i]))!=null)) { v=args[i+2];
    if (obj.style) { obj=obj.style; v=(v=='show')?'visible':(v=='hide')?'hidden':v; }
    obj.visibility=v; }
}
</script>
</head>

<body bgcolor="#cfd4ff">
<div id="header" >
  <p class="title">东江湖流域数据管理与综合分析智能中心</p>
  <ul>
		
		<li><a href="index.php">首页</a></li>
		<li>你好!</li>
        <li class="headerUser">用户名</li>
	<li><a href="index.php">个人设置</a></li>
		<li  id="configure" onmouseover="MM_showHideLayers('apDiv1','','show')" onmouseout="MM_showHideLayers('apDiv1','','hide')"><a href="manage.php">系统管理</a>
        <div id="apDiv1" onmouseover="MM_showHideLayers('apDiv1','','show')" onmouseout="MM_showHideLayers('apDiv1','','hide')">
          <table width="119" height="208" border="0">
            <tr>
              <td><a href="#" target="_self">用户管理</a></td>
            </tr>
            <tr>
              <td><a href="#" target="_self">数据库管理</a></td>
            </tr>
            <tr>
              <td><a href="javascritp:window.print() " target="_self">打印机管理</a></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
            </tr>
            <tr>
              <td>&nbsp;</td>
            </tr>
          </table>
        </div>
</li>
		<li id="conflog"></li>
		<li  id="help" ><a href="help.php">帮助</a></li>

	<li class="logout"><a href="logout.php">退出登录</a></li>
		
  </ul>
</div>

<div id="selectDB">
  <h2><strong>请选择数据库：</strong>
  </h2>
  <form method="get" action="">
    <table width="100%" height="139" border="0">
      <tr>
        <td width="31%" height="40"><span class="department">水文：</span>
  <label for="shuiwenxinxi">水文信息</label>
    <input type="radio" name="dbName" value="水文信息" />
    <label for="shuiwenxinxi">待定1</label>
    <input type="radio" name="dbName"  value="待定1" />
    <label for="shuiwenxinxi">待定2</label>
    <input type="radio" name="dbName" value="待定2" /></td>
        <td width="22%">
        <span class="department">农业：</span>
  <label for="shuiwenxinxi">农调信息</label>
    <input type="radio" name="dbName" id="shuiwenxinxi" value="农调信息" />

    </td>
        <td width="24%"><span class="department">气象：</span>
  <label for="shuiwenxinxi">气象信息</label>
    <input type="radio" name="dbName" id="shuiwenxinxi" value="气象信息" /></td>
        <td width="23%"><span class="department">人力：</span>
  <label for="shuiwenxinxi">统计信息</label>
    <input type="radio" name="dbName" id="shuiwenxinxi" value="统计信息" /></td>
      </tr>
      <tr>
        <td><span class="department">环保：</span>
  <label for="shuiwenxinxi">环保信息</label>
    <input type="radio" name="dbName" value="环保信息" />
    <label for="shuiwenxinxi">待定1</label>
    <input type="radio" name="dbName" value=环保信息" />
    <label for="shuiwenxinxi">待定2</label>
    <input type="radio" name="dbName" value="待定2" /></td>
        <td><span class="department">畜牧：</span>
  <label for="shuiwenxinxi">畜牧信息</label>
    <input type="radio" name="dbName" id="shuiwenxinxi" value="畜牧信息" /></td>
        <td><span class="department">财政：</span>
  <label for="shuiwenxinxi">财政信息</label>
    <input type="radio" name="dbName" id="shuiwenxinxi" value="财政信息" /></td>
        <td> <span class="department">畜牧：</span>
  <label for="shuiwenxinxi">畜牧信息</label>
    <input type="radio" name="dbName" id="shuiwenxinxi" value="畜牧信息" /></td>
      </tr>
      <tr>
        <td><span class="department">水位：</span>
  <label for="shuiwenxinxi">水位信息</label>
    <input type="radio" name="dbName"  value="水位信息" />
    <label for="shuiwenxinxi">待定1</label>
    <input type="radio" name="dbName"  value="待定1" />
    <label for="shuiwenxinxi">待定2</label>
    <input type="radio" name="dbName" value="待定2" /></td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
    </table>
  </form
>
</div>
<div id="main">
  <div class="operateTitle">
    <h2 id=""operateTitle""><strong>水文数据库查询操作</strong></h2>
  </div>
  <form method="get" action="">
  <div class="ziduanzhiyue" id="ziduanzhiyue"><span class="title2"><span class="title2">数据约束条件选择: </span></span></div>
  <div class="xianshiziduan" id="xianshiziduan"><span  class="title2">数据显示字段选择:
    <table width="100%" border="1">
      <tr>
          <?php while($row=pg_fetch_assoc($result)){?>
        <td><input type="checkbox" name="display[]" id="orderDisplay"  />
        <label for="orderDisplay">序号</label></td>
         <?php } ?>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      <!--  <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>-->
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
    </table>
  </div>
  </form>
    <?PHP
    if($_GET['dataBase']=='shuiwenxinxi'){
    // 得到所有字段名
    /*$sql=<<<EOF
        SHOW FULL COLUMNS FROM HYDRAULICTABLE;
        EOF;*/
    $sql=<<<EOF
         select attname from pg_attribute where attrelid = ( select relfilenode from pg_class where relname = 'hydraulictable') and attnum>0
EOF;
        $result=pg_query($sql);
        }
    while($row = pg_fetch_assoc($result)){
//  echo '字段名称：'.$row['Field'].'-数据类型：'.$row['Type'].'-注释：'.$row['Comment'];
//  echo '<br/><br/>';
        print_r($row);
    }
        ?>
</div>
</body>
</html>
