<?php

header("Content-Type:text/html;charset=utf-8");
session_start();

//定义个常量，用来授权调用includes里面的文件
define('IN_TG',true);
//定义个常量，用来指定本页的内容
define('SCRIPT','export');
//ob_start();
//引入公共文件
require dirname(__FILE__).'/includes/common.inc.php';

if(!empty($_SESSION['tableName'])) {
  $sql = <<<EOF
SELECT a.attname, a.attnotnull as notnull FROM pg_class as c,pg_attribute as a  where c.relname = '{$_SESSION['tableName']}' and a.attrelid = c.oid and a.attnum>1
EOF;
//echo $sql;
  $result = pg_query($sql);
  while ($row = pg_fetch_assoc($result)) {
    $fields[] = $row;
  }
  if ($_GET['action'] == 'download') {
    if (empty($_SESSION['tableName'])) {
      _alert_back('请先选择数据库');
    }
      $fileName = $_COOKIE['username'] . '_' . $_SESSION['tableName'] . time() . '.xls';
      $filePath = ROOT_PATH . 'export\\' . $_COOKIE['username'] . '_' . $_SESSION['tableName'] . time() . '.xls';

      $filePath = addslashes($filePath);
      $_SESSION['fileName']=$fileName;
      /* echo $_SESSION['fileName'];
       exit();*/
      $_SESSION['filePath']=$filePath;
      //exit();
      $dir=dirname($filePath);
      /*echo $_POST['exportMethod'];
      exit();*/
    if($_POST['exportMethod']=='增量导出') {
      //查询导出记录
      $exportLogSql=<<<eof
SELECT operatetime FROM log WHERE tablename='{$_SESSION['tableName']}' AND operation='导出' AND username='{$_COOKIE['username']}' ORDER BY operatetime DESC;
eof;
      //echo $exportLogSql;
      $exportLogResult=pg_query($exportLogSql);
      $exportLastTime=pg_fetch_assoc($exportLogResult);
        if(empty($exportLastTime)){
            //设为0，[SQL] SELECT content FROM log WHERE tablename='rpcitable' AND operation='导入' AND operatetime > '0';[Err] ERROR:  invalid input syntax for type timestamp: "0"LINE 1: ...name='rpcitable' AND operation='导入' AND operatetime > '0';
            //$exportLastTime['operatetime']=0;
            $exportLastTime['operatetime']='2000-12-25 10:45:55.084291';
        }/*else{
            echo 2;
        }*/
       // exit();
      /*echo $exportLastTime['operatetime'];
      exit();*/
      //查询最后一次导出后，是否有新文件导入
      $importLog=<<<eof
SELECT content FROM log WHERE tablename='{$_SESSION['tableName']}' AND operation='导入' AND operatetime > '{$exportLastTime['operatetime']}';
eof;
        /*echo $importLog;
        exit();*/
      $importLogResult=pg_query($importLog);
        //不能对数据集判断是否为空或者==NULL，已验证
       /* if(empty($importLogResult)){
            echo 1;
        }
        if($importLogResult==NULL){
            echo 1;
        }*/
       $importFiles=array();
        while($importFilesRows=pg_fetch_assoc($importLogResult)){
            $importFiles[]=$importFilesRows['content'];
        }
        /*var_dump($importFilesRows);
        exit();*/
        if (empty($importFiles)){
           /* _alert_info('该数据库最近没有导入新的数据');
            exit();*/
           _location('该数据库最近没有导入新的数据','export.php');
        }
        require_once 'PHPExcel_1.8.0_doc/Classes/PHPExcel.php';
        require_once('PHPExcel_1.8.0_doc/Classes//PHPExcel/IOFactory.php');//静态类
        /*echo 2;
        exit();*/
        $data = array();
        //数组初始行数
        $dataRow=0;
        $allColumn='';
      foreach ($importFiles as $importFile){
          //都不能判断为空
         /* echo '该数据库最近没有导入新的数据';
          //var_dump($importFiles);
          if(empty($importFiles)){
              echo 1;
              _alert_info('该数据库最近没有导入新的数据');
          }else{
              echo '该数据库最近没有导入新的数据';
          }
          if(empty($importFiles['content'])){
              echo 1;
              _alert_info('该数据库最近没有导入新的数据');
          }
          if($importFiles['content']==NULL){
              echo 2;
              _alert_info('该数据库最近没有导入新的数据');
          }*/
        //echo $importFiles['content'];
         // exit();
          //将表格循环读入数组
          if(empty($importFile) or !file_exists($importFile)){die('file not exists');}
          $PHPReader = new PHPExcel_Reader_Excel2007();        //建立reader对象
          if(!$PHPReader->canRead($importFile)){
              $PHPReader = new PHPExcel_Reader_Excel5();
              if(!$PHPReader->canRead($importFile)){
                  echo 'no Excel';
                  return ;
              }
          }
          $PHPExcel = $PHPReader->load($importFile);        //建立excel对象
          $currentSheet = $PHPExcel->getSheet(0);        //**读取excel文件中的指定工作表*/
          $allColumn = $currentSheet->getHighestColumn();        //**取得最大的列号*/
          $allRow = $currentSheet->getHighestRow();        //**取得一共有多少行*/
          //$data = array();
          //第一张表初始行为一，其余表从第二行开始录入
          if ($dataRow==0){
              $rowIndex=1;
          }else{
              $rowIndex=2;
          }
          for(;$rowIndex<=$allRow;$rowIndex++){        //循环读取每个单元格的内容。注意行从1开始，列从A开始
              $dataRow++;
              //echo $dataRow;
              for($colIndex='A';$colIndex<=$allColumn;$colIndex++){
                  $addr = $colIndex.$rowIndex;
                  $cell = $currentSheet->getCell($addr)->getValue();
                  if($cell instanceof PHPExcel_RichText){ //富文本转换字符串
                      $cell = $cell->__toString();
                  }

                  $data[$dataRow][$colIndex] = $cell;
                 // $allRow = $currentSheet->getHighestRow();有时得到的行数不正确多出来很多空行
                 // if($data[$dataRow+$rowIndex]==NULL){
                 // if(empty($data[$dataRow+$rowIndex])){
                  //用上面两种方法都没检测出改二维数组的一行为空的情况，所以采用下面的方法，
                 // [619]=> array(9) { ["A"]=> float(308) ["B"]=> float(2010) ["C"]=> string(9) "白廊乡" ["D"]=> float(4737) ["E"]=> float(13227) ["F"]=> float(9359) ["G"]=> float(5649) ["H"]=> float(25344.3) ["I"]=> float(8100) } [620]=> array(1) { ["A"]=> NULL } }多出一行，减去一行
                  /*if ($data[$dataRow+$rowIndex][$colIndex]===NULL){
                      //终止循环，重置最大行
                      $allRow=$rowIndex-1;
                      break;
                  }*/

                  if ($data[$dataRow][$colIndex]===NULL){
                      //终止循环，重置最大行
                      $dataRow--;
                      break;
                      break;
                  }
              }
              //也不行==null也试过了
              /*if(is_null($data[$dataRow])){
                  echo 1;
                  exit();
              }*/
          }
          //$dataRow+=$allRow;
      }
      /*var_dump($data);
      exit();*/
        $savename = date("YmjHis");
        //将数组到处到excel
        $file_type ="vnd.ms-excel";
        $file_ending = "xls";
        header("Content-Type:application/$file_type;charset=big5");
        header("Content-Disposition: attachment;filename=".$savename.".$file_ending");
//header("Pragma:no-cache");
        $sep ="\t";
        $i =1;
        for(;$i<=$dataRow;$i++){
            $schema_insert = "";
            for ($j='A';$j<=$allColumn;$j++) {
                /*if (!isset($data[$i][$j]))
                    $schema_insert .= "NULL" . $sep;
                elseif ($row[$j] != "")
                    $schema_insert .= "$data[$i][$j]" . $sep;
                else
                    $schema_insert .= "" . $sep;*/
                $schema_insert .= $data[$i][$j] . $sep;

            }
            $schema_insert = str_replace($sep . "$", "", $schema_insert);
            $schema_insert .= "\t";
            print(trim($schema_insert));
            print"\n";
        }
        //从用户库中提取信息
        $userInfoSql = <<<EOF
SELECT lasttime,lastip FROM djhuser WHERE username='{$_COOKIE['username']}'
EOF;
        $infos = pg_fetch_assoc(pg_query($userInfoSql));
        //插入数据库
        $upLogSql = <<<EOF
INSERT INTO log (username,tablename,operation,content,ip,logintime,operatetime) VALUES('{$_COOKIE['username']}','{$_SESSION['tableName']}','{$scToCh[SCRIPT]}','增量导出','{$infos['lastip']}','{$infos['lasttime']}',NOW())
EOF;
        //echo $upLogSql;
        pg_query($upLogSql);
        //  unlink($filePath);
        exit();
        }

    require_once("http://localhost:8080/JavaBridgeTemplate611/java/Java.inc");

   /* $file_name="hetong_wqmtable1475992462.xls";
//用以解决中文不能显示出来的问题
    $file_name=iconv("utf-8","gb2312",$file_name);
    $file_sub_path=$_SERVER['DOCUMENT_ROOT'];
    $file_path=$file_sub_path.'/export/'.$file_name;
    $fp=fopen($file_path,"r");
    $file_size=filesize($file_path);
//下载文件需要用到的头
    Header("Content-type: application/octet-stream");
    Header("Accept-Ranges: bytes");
    Header("Accept-Length:".$file_size);
    Header("Content-Disposition: attachment; filename=".$file_name);
    $buffer=1024;
    $file_count=0;
//向浏览器返回数据
    while(!feof($fp) && $file_count<$file_size){
      $file_con=fread($fp,$buffer);
      $file_count+=$buffer;
      echo $file_con;
    }
    fclose($fp);*/
    //exit();

      if(!is_dir($dir)){
          mkdir($dir);
      }

    //$file_path=$file_sub_path.$file_name;
    switch ($_SESSION['tableName']) {

      case 'zxctable':
        /*$batchImport = new Java("ExportDBToZXCxls");
        $value=$batchImport->exe("C:/software/httpd-2.4.23-x64/Apache/htdocs/dongjianghu7/export/hetong_zxctable1474637312.xls");
        //$value=$batchImport->exe();
        $info=java_values($value);
        echo $info;*/

        $export = new Java("ExportDBToZXCxls");
        $value = $export->exe($filePath);
        //$value=$batchImport->exe();
        $info = java_values($value);
       // echo $info;
        break;
      case 'wltable':
        $export = new Java("ExportDBToWLxls");
        $value = $export->exe($filePath);
        $info = java_values($value);
       // echo $info;
        break;
      case 'rpcitable':
        $export = new Java("ExportDBToRPCIxls");
        $value = $export->exe($filePath);
        $info = java_values($value);
        // echo $info;
        break;
      case 'hydraulictable':
        $export = new Java("ExportDBToHdxls");
        $value = $export->exe($filePath);
        $info = java_values($value);
        break;
      case 'attable':
        $export = new Java("ExportDBToATxls");
        $value = $export->exe($filePath);
        $info = java_values($value);
        break;
      case 'wqmtable':
        $export = new Java("ExportDBToWQMxls");
        $value = $export->exe($filePath);
        $info = java_values($value);
        break;
      case 'ftable':
        $export = new Java("ExportDBToFxls");
        $value = $export->exe($filePath);
        $info = java_values($value);
        break;
      case 'imtable':
        $export = new Java("ExportDBToIMxls");
        $value = $export->exe($filePath);
        $info = java_values($value);
        break;
      case 'lstable':
        $export = new Java("ExportDBToLSxls");
        $value = $export->exe($filePath);
        $info = java_values($value);
        break;
      case 'metable':
        $export = new Java("ExportDBToMExls");
        $value = $export->exe($filePath);
        $info = java_values($value);
        break;
      case 'runofftable':
        $export = new Java("ExportDBToROxls");
        $value = $export->exe($filePath);
        $info = java_values($value);
        break;
      case 'fwtable':
        $export = new Java("ExportDBToFWxls");
        $value = $export->exe($filePath);
        $info = java_values($value);
        break;
      default:
        break;
    }
//echo $file_path;
//首先要判断给定的文件存在与否
    /*if(!file_exists($file_path)){
        echo "没有该文件文件";
        return ;
    }*/
    //$file_path=$filePath;
    /*echo $_FILES['userfile']['name'];
    exit();*/
    download($_SESSION['fileName'],$_SESSION['filePath']);


   // ob_end_flush();
//exit();
    //从用户库中提取信息
    $userInfoSql = <<<EOF
SELECT lasttime,lastip FROM djhuser WHERE username='{$_COOKIE['username']}'
EOF;
    $infos = pg_fetch_assoc(pg_query($userInfoSql));
    //插入数据库
    $upLogSql = <<<EOF
INSERT INTO log (username,tablename,operation,content,ip,logintime,operatetime) VALUES('{$_COOKIE['username']}','{$_SESSION['tableName']}','{$scToCh[SCRIPT]}','全部导出','{$infos['lastip']}','{$infos['lasttime']}',NOW())
EOF;
    //echo $upLogSql;
    pg_query($upLogSql);
  //  unlink($filePath);
  }
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title><?php echo '湖南省郴州东江湖水资源管理'?></title>
  <link rel="shortcut icon" href="dongjianghu.ico" />
  <script type="text/javascript" src="js/jquery-3.1.0.min.js"></script>
  <link rel="stylesheet" type="text/css" href="js/jQuery-jcDate-master/src/jcDate.css" media="all" />
  <script type="text/javascript" src="js/jQuery-jcDate-master/src/jQuery-jcDate.js" charset="utf-8"></script>
  <script type="text/javascript" src="js/baseManage.inc1.js"></script>
<link rel="stylesheet" type="text/css" href="templateCss.css"/>
<style type="text/css">

#mainUp form ul {
	list-style-type: none;
	height:120px;
	width:95%;
	overflow:auto;
}
#mainUp form ul li{

	display:inline-block;
	width:620px;
	height:35px;
}
#mainUp form ul li span.searchInfo{
	display:inline-block;
	/*border:red solid 1px;*/
	width:350px;
}
#mainUp form ul li span.searchInput{
	width:180px;
}
#mainUp form ul input.searchInput{
	width:60px;
	}

#mainUp form ul.displaySelect{

	height:110px;
	overflow-y:auto;
	overflow-x:hidden;
}
#mainUp form ul li.displaySelect{

	display:inline-block;
	width:170px;
	height:35px;
}
#mainUp form ul li.displayBatch{

	display:block;
	text-align:center;
	height:35px;
}
#mainUp form ul.submit{
	text-align:center;
	height:35px;
}
#mainUp form ul.methodSelect{
	height:35px;
	}
#mainUp form ul li.methodSelect{

	display:inline-block;
	width:320px;
	height:35px;
}
#apDiv1 {
	position: absolute;
	left: 1074px;
	top: 381px;
	width: 157px;
	height: 42px;
	z-index: 3;
}
</style>

</head>

<body bgcolor="#cfd4ff">

<?php
require_once("includes/header.inc.php");
?>
<div class="bodyContent">
<?php
require_once("includes/dbSelect.inc.php");
?>

<?php if($_SESSION['mainUpFlag']==1){?>
<div id="mainUp">
  <h2 id="operateTitle"><strong><?php echo $_SESSION['tableCh']?>数据库导出操作</strong></h2>

  <form enctype="multipart/form-data" method="post" action="export.php?action=download">
 <!-- <span class="title2">数据约束条件选择: </span>-->


<!--    <ul>
      <?php
/*      $i=0;
      //echo $sql;
      //echo $_SESSION['tableName'];
      foreach ($fields as $field){

          $strSql1=<<<EOF
SELECT {$field['attname']} FROM {$_SESSION['tableName']} WHERE {$field['attname']}=(select min({$field['attname']}) 
                from {$_SESSION['tableName']}) 
EOF;
          // echo $strSql1;
          $minResult=pg_query($strSql1);
          $mins=pg_fetch_assoc($minResult);
          $min=$mins[$field['attname']];
          //echo $min;
          $strSql2=<<<EOF
SELECT {$field['attname']} FROM {$_SESSION['tableName']} WHERE {$field['attname']}=(select max({$field['attname']}) 
                from {$_SESSION['tableName']}) 
EOF;
         // echo $strSql2;
          $maxResult=pg_query($strSql2);
          $maxs=pg_fetch_assoc($maxResult);
          $max=$maxs[$field['attname']];
          //echo $max;



          */?>
      <li><span class="searchInfo"><?php /*echo winDisplay($field['attname'])*/?>(最小:<?php /*echo $min;*/?>;最大:<?php /*echo $max;*/?>):</span>
      <span class="searchInput"> 从<input type="text" class="searchInput" name="<?php /*echo 'first'.$field['attname']*/?>" value="<?php /*echo $min;*/?>"/>到<input class="searchInput" type="text" name="<?php /*echo 'second'.$field['attname']*/?>" value="<?php /*echo $max;*/?>"/></span>
      </li>
      <?php
/*        $i++;
        if($i%3==0 && $i!=0){
        }
      }*/?>
    </ul>-->


<!--  <span  class="title2">导出字段选择:</span>
    <ul id="displaySelect" class="displaySelect">
        <?php /*foreach ($fields as $field){*/?>
          <li class="displaySelect"><input class="searchSimpleInput" type="checkbox" name="displays[]" id="<?php /*echo $field['attname']*/?>" value="<?php /*echo winDisplay($field['attname'])*/?>" />
        <label for="<?php /*echo $field['attname']*/?>"><?php /*echo winDisplay($field['attname'])*/?></label>
          <input type="hidden" name="<?php /*echo $field['attname']*/?>" value="<?php /*echo winDisplay($field['attname'])*/?>" />
          </li>
        <?php /*} */?>


    </ul>-->
<!--    <p class="displayBatch" style="text-align: center;"><input class="searchSimpleInput" type="checkbox" name="displayAll" id="displayAll" checked="checked" />
      <label for="displayAll">全选</label>
      <input type="checkbox" class="searchSimpleInput" name="displayReverse" id="displayReverse"   />
      <label for="displayReverse">反选</label>
    </p>-->
    <span  class="title2">导出方式选择:</span>
    <ul class="methodSelect">

      <li class="methodSelect"><input class="methodSelect" type="radio" name="exportMethod"  checked="checked" id="exportMethod1" value="全部导出"  />
        <label for="exportMethod1">全部导出</label></li>
      <li class="methodSelect"><input class="methodSelect" type="radio" name="exportMethod"
                                      id="exportMethod2" value="增量导出" />
        <label for="exportMethod2">增量导出</label></li>
      <!--<li class="methodSelect"><input class="methodSelect" type="radio" name="exportMethod"
                                      disabled="disabled"             id="exportMethod" value="修改导出"/>
        <label for="exportMethod3">修改导出</label></li>-->
    </ul>

    <span  class="title2">导出文件格式:</span>
    <ul class="methodSelect">
      <li class="methodSelect"><input class="methodSelect" type="radio" name="fileFormat" checked="checked" id="fileFormat1"   value="excel"  />
        <label for="fileFormat1">excel表(.xls)</label></li>
      <li class="methodSelect"><input class="methodSelect" type="radio" name="fileFormat" id="fileFormat2" disabled="disabled"   value="postgresql" />
        <label for="fileFormat2">postgresql</label></li>
      <li class="methodSelect"><input class="methodSelect" type="radio" name="fileFormat" id="fileFormat3" disabled="disabled"   value="doc"/>
        <label for="fileFormat3">doc文档</label></li>
    </ul>
   <!-- <span  class="title2">是否压缩:</span>
    <ul class="methodSelect">
      <li class="methodSelect"><input class="methodSelect" type="radio" name="press" id="press"  value="压缩"  />
        <label for="exportMethod">压缩</label></li>
      <li class="methodSelect"><input class="methodSelect" type="radio" name="press" id="press"  value="不压缩" checked="checked" />
        <label for="exportMethod">不压缩</label></li>
    </ul>-->
    <!--<span  class="title2">选择下载路径:</span>-->
    <!--<ul class="methodSelect">
      <style type="text/css">
        .a-upload {
          padding: 4px 10px;
          height: 20px;
          line-height: 20px;
          position: relative;
          cursor: pointer;
          color: #888;
          background: #dfc1fa;
          border: 1px solid #ddd;
          border-radius: 4px;
          overflow: hidden;
          display: inline-block;
          *display: inline;
          *zoom: 1
        }

        .a-upload  input {
          position: absolute;
          font-size: 100px;
          right: 0;
          top: 0;
          opacity: 0;
          filter: alpha(opacity=0);
          cursor: pointer
        }

        .a-upload:hover {
          color: #444;
          background: #eee;
          border-color: #ccc;
          text-decoration: none
        }
        .showFileName {
          display:inline-block;
          padding: 4px 10px;
          height: 20px;
          line-height: 20px
        }
      </style>

      <a href="javascript:;" class="a-upload" id="aUpload">
        <input type="file" name="userfile" id="userfile">请选择下载路径

      </a>

      <span class="showFileName" id="upFileName"></span><span class="fileerrorTip"></span>
      <script type="text/javascript">
        $(".a-upload").on("change","input[type='file']",function(){
          // alert(1);
          var filePath=$(this).val();
          // alert(filePath);
          //  $(".fileerrorTip").html("您未上传文件，或者您上传文件类型有误！");
          $(".fileerrorTip").html("").hide();
          var arr=filePath.split('\\');
          var fileName=arr[arr.length-1];
          $(".showFileName").html(fileName);
          /*  if(filePath.indexOf("jpg")!=-1 || filePath.indexOf("png")!=-1){
           $(".fileerrorTip").html("").hide();
           var arr=filePath.split('\\');
           var fileName=arr[arr.length-1];
           $(".showFileName").html(fileName);
           }else{
           $(".showFileName").html("");
           $(".fileerrorTip").html("您未上传文件，或者您上传文件类型有误！").show();
           return false
           }*/
        })

      </script>

    </ul>-->
    <ul class="submit">




      <li>
        <input type="submit" value="导出">
      </li>
    </ul>

  </form>
</div>
<?php }
if($_SESSION['mainUpFlag']!=1){
  echo '<div id="placeHolder" style="height:400px;"></div>';
}
?>
</div>
<?php require_once('includes/footer.inc.php');?>

<script type="text/javascript" src="js/<?php echo SCRIPT?>.js"></script>

</body>
</html>
