<?php
header("Content-Type:text/html;charset=utf-8");
session_start();
//定义个常量，用来授权调用includes里面的文件
define('IN_TG',true);
//定义个常量，用来指定本页的内容
define('SCRIPT','write');
//引入公共文件
require dirname(__FILE__).'/includes/common.inc.php';

if(!empty($_SESSION['tableName'])) {
    $iniUrlCon=$_SERVER["QUERY_STRING"];
    $sql = <<<EOF
SELECT a.attname, a.attnotnull as notnull FROM pg_class as c,pg_attribute as a  where c.relname = '{$_SESSION['tableName']}' and a.attrelid = c.oid and a.attnum>1
EOF;
//echo $sql;
    $result = pg_query($sql);
    $fields=array();
    while ($row = pg_fetch_assoc($result)) {
        $fields[] = $row;
    }
   // $_SESSION['write']=array();
    if(empty($_SESSION['write'])){
        $_SESSION['write']=array();
       // echo 'array()等效于空';
    }
    //echo $_SESSION['writeCount'];
    if(empty($_SESSION['writeCount'])){
        $_SESSION['writeCount']=0;
    }

    if ($_GET['firstAction'] == 'preWrite') {
        //$filDir=$_COOKIE['username'];
        //$fileName=$_COOKIE['username'].'_'.$_SESSION['tableName'].'_'.SCRIPT.'.json';
// 显示出来看看
        //var_dump($data1);


        $flag = 1;
        $data=array();
        foreach ($fields as $field5) {

            $data[$field5['attname']] = trim($_GET[$field5['attname']]);
            //echo $field5['attname'];
            //echo $_GET[$field5['attname']];
            //echo $data[$field5['attname']];
            if($field5['attname']!='datetime'){
                checkAll($field5['attname'],$data[$field5['attname']]);
                //exit();
            }

            if ($data[$field5['attname']] === '') {
                /*echo $field5['attname'];
                echo $_GET[$field5['attname']];
                echo '<br/>';*/
                $flag = 0;
                _alert_back('录入数据字段不能为空,请填写完整');
            }
            //失败了,结果array(2) { [4]=> array(1) { [0]=> string(10) "2011-02-06" } [5]=> array(1) { [0]=> string(1) "2" } }
            /*失败了, { [0]=> array(1) { ["datetime"]=> string(10) "2011-02-06" } [1]=> array(1) { ["wl"]=> string(1) "1" } [2]=> array(1) { ["datetime"]=> string(10) "2011-02-06" } [3]=> array(1) { ["wl"]=> string(1) "1" } }*/
           // $_SESSION['write'][][$field5['attname']]=$data[$field5['attname']];
            $_SESSION['write'][$_SESSION['writeCount']][$field5['attname']]=$data[$field5['attname']];

        }
        $_SESSION['writeCount']++;
        //var_dump($_SESSION['write']);
        //保存完后，去firstaction跳转，防止前进后退刷新都会录入firstaction（前进后退测试结果，以页面而不是代码为准，效果十分理想）
        $iniUrlCon=strtr($iniUrlCon,array('firstAction=preWrite'=>''));
        _location('','?'.$iniUrlCon);
       /* $_SESSION['write'][][]=$data;
        $_SESSION['writeCount']++;
        var_dump($_SESSION);*/
        /*$_SESSION['write'][]=$data;
        $_SESSION['writeCount']++;
        var_dump($_SESSION);*/
       /* array_push($_SESSION['write'],$data);
        $_SESSION['writeCount']++;
        var_dump($_SESSION);
        unset($_SESSION['write']);*/
       /* unset($_SESSION['write']);
        var_dump($_SESSION['write']);*/
       // exit();
        if ($flag == 0) {
            _alert_back('录入数据字段不能为空,请填写完整');
        }
        $info = '';
//字段不为空时，判断一下是否符合要求
        /* switch($_SESSION['tableName']){
             case 'zxctable':
                 $judge = new Java("Judge");
                 $value=$judge->judgeHY( $_SESSION['tableName'],$_GET);
                 //$value=$batchImport->judgeHY();
                 $info=java_values($value);
                 //echo $info;
                 break;
             case 'rpcitable':
                 $judge = new Java("Judge");
                 $value=$judge->judgeHY( $_SESSION['tableName'],$_GET);
                 $info=java_values($value);
                 // echo $info;
                 break;
             case 'hydraulictable':
                 $judge = new Java("Judge");
                 $value=$judge->judgeHY( $_SESSION['tableName'],$_GET);
                 $info=java_values($value);
                 break;
             case 'attable':
                 $judge = new Java("Judge");
                 $value=$judge->judgeHY( $_SESSION['tableName'],$_GET);
                 $info=java_values($value);
                 break;
             case 'wqmtable':
                 $judge = new Java("Judge");
                 $value=$judge->judgeHY( $_SESSION['tableName'],$_GET);
                 $info=java_values($value);
                 break;
             case 'ftable':
                 $judge = new Java("Judge");
                 $value=$judge->judgeHY( $_SESSION['tableName'],$_GET);
                 $info=java_values($value);
                 break;
             case 'imtable':
                 $judge = new Java("Judge");
                 $value=$judge->judgeHY( $_SESSION['tableName'],$_GET);
                 $info=java_values($value);
                 break;
             case 'lstable':
                 $judge = new Java("Judge");
                 $value=$judge->judgeHY( $_SESSION['tableName'],$_GET);
                 $info=java_values($value);
                 break;
             default:
                 break;
         }*/
        /*$test=array('datetime'=>'5434');
         $judge = new Java("Judge");
         $value=$judge->judgeHY('hydraulictable',$test);
         $info=java_values($value);
         var_dump($info);*/

        /*$arr[]=$data;
        array_push($arr,$data);
        var_dump($arr);*/


    }
    if($_GET['secondAction']=='delete'){
       // echo $_GET['deleteID'];
        //array_slice后数组未变化=>array_slice只取出数据，而不删除数据
        //array_slice($_SESSION['write'],$_GET['deleteID'],1);
        //array_splice第四个参数默认为false，即重建索引
        array_splice($_SESSION['write'],$_GET['deleteID'],1);
     //   var_dump($_SESSION['write']);
        $_SESSION['writeCount']--;
        //重定向
        //$iniUrlCon=strtr($iniUrlCon,array('secondAction=delete'=>''));
        $pos=strpos($iniUrlCon,'secondAction');
        $iniUrlCon=substr($iniUrlCon,0,$pos);
        _location('','?'.$iniUrlCon);
    }

    if ($_GET['action'] == 'drop') {
        /*    echo "<script type='text/javascript'>isDrop();</script>";*/
//echo '<script>'
        $iniUrlCon=strtr($iniUrlCon,array('&action=drop'=>''));
        //_confirm('是否要清空写入临时空间的数据','?'.$iniUrlCon);
        unset($_SESSION['write']);
        unset($_SESSION['writeCount']);
    }
    if ($_GET['action'] == "writeSave") {
        //echo $json_string;
        // echo '<br/>';
        //转化为数组
        if (empty($_SESSION['write'])) {
            _alert_back('不能提交空白数据，请先填写数据');
        } else {
            //var_dump($_SESSION['write']);
            $idSql = <<<EOF
SELECT id FROM {$_SESSION['tableName']} where id=(SELECT max(id) FROM {$_SESSION['tableName']})
EOF;
            $idTrueMaxs = pg_fetch_assoc(pg_query($idSql));
            $idTrueMax = $idTrueMaxs['id'] + 1;
            foreach ($_SESSION['write'] as $items) {
                $insertSqlPart = '';
                foreach ($items as $item) {
                    $insertSqlPart .= ' \'' . $item . '\',';
                }
                $insertSqlPart1 = '';
                foreach ($fields as $field8) {
                    $insertSqlPart1 .= $field8['attname'] . ',';
                }
                $insertSqlPartNew = substr($insertSqlPart, 0, -1);
                $insertSqlPart1New = substr($insertSqlPart1, 0, -1);

//echo $insertSql;
                $insertSql='';
                do {
                    $insertSql = <<<EOF
INSERT INTO {$_SESSION['tableName']} (id,$insertSqlPart1New) VALUES ($idTrueMax,$insertSqlPartNew)
EOF;
                    $insertResult = pg_query($insertSql);
                    $idTrueMax++;
                } while (pg_affected_rows($insertResult) != 1);
                //从用户库中提取信息
                $userInfoSql = <<<EOF
SELECT lasttime,lastip FROM djhuser WHERE username='{$_COOKIE['username']}'
EOF;
                $infos = pg_fetch_assoc(pg_query($userInfoSql));
                //插入数据库
                //$content = count($_SESSION['write']) . '条数据';
                $content=$insertSql;
                $upLogSql = <<<EOF
INSERT INTO log (username,tablename,operation,operatetime,content,ip,logintime) VALUES('{$_COOKIE['username']}','{$_SESSION['tableName']}','{$scToCh[SCRIPT]}',NOW(),'{$content}','{$infos['lastip']}','{$infos['lasttime']}')
EOF;
                //  ECHO $upLogSql;
                pg_query($upLogSql);

            }

            _alert_info('录入成功');

            /*//从用户库中提取信息
            $userInfoSql = <<<EOF
SELECT lasttime,lastip FROM djhuser WHERE username='{$_COOKIE['username']}'
EOF;
            $infos = pg_fetch_assoc(pg_query($userInfoSql));
            //插入数据库
            $content = count($_SESSION['write']) . '条数据';
            $upLogSql = <<<EOF
INSERT INTO log (username,tablename,operation,operatetime,content,ip,logintime) VALUES('{$_COOKIE['username']}','{$_SESSION['tableName']}','{$scToCh[SCRIPT]}',NOW(),'{$content}','{$infos['lastip']}','{$infos['lasttime']}')
EOF;
            //  ECHO $upLogSql;
            pg_query($upLogSql);*/
            //清空数据
            unset($_SESSION['write']);
            unset($_SESSION['writeCount']);
        }
    }

}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

    <?php require_once('includes/title.inc.php')?>
 <script type="text/javascript" src="js/jquery-3.1.0.min.js"></script>
 <link rel="stylesheet" type="text/css" href="js/jQuery-jcDate-master/src/jcDate.css" media="all" />
 <script type="text/javascript" src="js/jQuery-jcDate-master/src/jQuery-jcDate.js" charset="utf-8"></script>
    <link href="js/jquery-easyui-1.5/themes/default/easyui.css" rel="stylesheet" type="text/css" />
    <link href="js/jquery-easyui-1.5/themes/icon.css" rel="stylesheet" type="text/css" />
    <script src="js/jquery-easyui-1.5/jquery-1.6.4.min.js" type="text/javascript"></script>
    <script src="js/jquery-easyui-1.5/jquery.easyui.min.js" type="text/javascript"></script>
    <script src="js/jquery-easyui-1.5/locale/easyui-lang-zh_CN.js" type="text/javascript"></script>
 <script type="text/javascript" src="js/baseManage.inc1.js"></script>
<link rel="stylesheet" type="text/css" href="templateCss.css"/>
<style type="text/css">
    div.displayClass {
        width: 98%;
        height: auto;
        max-height: 600px;
        z-index: 1;
        background-color: #FFF;
        border-radius: 8px;
        font-size: 18px;
        overflow: auto;
        text-align: center;
    }
    /*div.displayClass div.displayMain{
        width:100px;
    }*/
    div.displayClass table td div.displayMain{
        width:auto;
        min-width:150px;
        height:auto;
    }
    div.displayClass table td div.displayMain input{
        width:auto;
        min-width:100px;
        height:25px;
    }
    div.displayClass table td a{
        color: #7c7eff;
        font-size: 0.9em;
    }
    div.displayClass table td a:hover{
        color: #2eff20;
    }
    div.displayClass table td div.displayMainSelect{
        width:100px;
    }
</style>

    <script type="text/javascript">
        function isGo(url){
            var flag=false;
            if(confirm("你确定要清空临时空间的数据吗?")){
                flag=true;
            }
            if(flag==true){
                window.location.href=url;
            }

        }

    </script>
</head>

<body bgcolor="#cfd4ff">
<?php
require_once("includes/header.inc.php");
?>
<div class="bodyContent">
<?php
require_once("includes/dbSelect.inc.php");
//require_once("includes/dbFieldOperate.php");
?>



  <?php 

 /*   $sqlSearch=<<<EOF
  SELECT * FROM {$_SESSION['tableName']} WHERE ;
EOF;
  $resSearch=pg_query($sqlSearch);*/
    //$rows=pg_fetch_assoc($res);
    //echo $_SESSION['tableName'];
    //print_r($rows);
    ?>

<?php if(!empty($_SESSION['tableName'])){
  ?>



<div id="mainDown">
<h2> 写入临时空间</h2>

  <form id="preWrite" method="get" action="?action=preWrite">
    <div id="displayHeader" class="displayClass">
      <table width="100%" border="1">
        <tr>
          <!--<td><div class="displayMain"></div></td>-->
          <?php foreach ($fields as $field2){?>
            <td><div class="displayMain"><?php echo winDisplay($field2['attname']); ?></div></td>
          <?php }?>
          <!--<td><div class="displayMain">操作</div></td>-->

        </tr>
        <tr>
          <!--<td><div class="displayMain">序号</div></td>-->
          <?php foreach ($fields as $field3){?>
            <td>
                <div class="displayMain">
                    <input type="text" name="<?php echo $field3['attname']?>" />
                </div>
            </td>
          <?php }?>
          <!--<td>
              <div class="displayMain">

              </div>
          </td>-->

        </tr>
        </table>

    </div>
      <p><input type="submit" value="写入"/><input type="hidden" name="firstAction" value="preWrite"/>(未真正写进数据库，需要点击保存才能将数据真正录入数据库)</p>
    </form>
  <form id="write" method="post" action="?action=writeSave">
<div class="displayClass">
    <h2>录入结果预览</h2>
    <table width="100%" border="1">
        <tr>
            <td><div class="displayMain">序号</div></td>
            <?php foreach ($fields as $field6){?>
                <td><div class="displayMain"><?php echo winDisplay($field6['attname']); ?></div></td>
            <?php }?>
            <td>操作</td>

        </tr>
  <!--  </table>
</div>
<div id="display" class="displayClass">

    <table width="100%" border="1">-->
      <!--有多少条-->
      <?php
      $idSql=<<<EOF
SELECT id FROM {$_SESSION['tableName']} where id=(SELECT max(id) FROM {$_SESSION['tableName']})
EOF;
      $idMaxs=pg_fetch_assoc(pg_query($idSql));
      $idMax=$idMaxs['id'];
      $writeDisplayCount=0;
      foreach($_SESSION['write'] as $disAss){?>
  <tr>
      <td>
          <div class="displayMain">
              <?php
              //id
              echo ++$idMax;
              ?>
          </div>
      </td>
    <?php
    //错误理解：外层foreach用的临时变量$value遍历和里层foreach用的临时变量会冲突，解决方法:1去不同名字2将外层变量付给新的变量
    //实际上是函数没写正确，没用返回值;注意没用返回值光输出时$rowsSearch[iniField($value)],没取出结果
    foreach ($fields as $field4){?>
      <td>
        <div class="displayMain">
            <?php
            /*$key=iniField($field4['attname']);
          echo $rowsSearch[$key];*/
            echo $disAss[$field4['attname']];
            ?>
        </div>

      </td>
    <?php }?>
      <td><div class="displayMain"><a href="?<?php echo $iniUrlCon.'&secondAction=delete&'.'deleteID='.$writeDisplayCount;?>">删除</a></div></td>
  </tr>
      <?php
          $writeDisplayCount++;
      }
      ?>
</table>
</div>
   <!-- <input class="selectSimpleInput" type="checkbox" name="selectAll" id="selectAll"  />
    <label for="selectAll">全选</label>
    <input type="checkbox" class="selectSimpleInput" name="selectReverse" id="selectReverse"  />
    <label for="selectReverse">反选</label>
    <input id="delete" type="submit" value="删除"/>-->
      <p><input id="drop" onclick="javascript:isGo('<?php echo '?'.$iniUrlCon.'&action=drop'?>');"  type="button" value="放弃"/>  <input id="save" type="submit" value="保存"/></p>

  <!--    <p><input id="drop" onclick="javascript:isGo('?action=drop');"  type="button" value="放弃"/>  <input id="save" type="submit" value="保存"/></p>-->
  </form>



</div>
<?php }
/*if($_SESSION['mainUpFlag']!=1){
    echo '<div id="placeHolder" style="height:400px;"></div>';
}*/

?>
</div>
<?php require_once("includes/footer.inc.php")?>
<script type="text/javascript" src="js/<?php echo SCRIPT?>.js"></script>
</body>
</html>
