
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>按日期查询</title>

    <!--<script type="text/javascript" src="js/baseManage.header.js"></script>-->
</head>
<body>

<div id="date">

    <div>
      <!--  <h2><?php /*echo $_GET['baseType'].'数据高级查询'*/?></h2>-->
        <dl>
            <form>
            <dt></dt>
            <dd>选择查询日期:
                <select name="year">
                    <?php
                    foreach (range(1985,2016) as $_num) {
                        echo '<option value="'.$_num.'"> '.$_num.'</option>';
                    }
                    ?>
                </select>年
                <select name="month">
                    <?php
                    foreach (range(1,12) as $_num) {
                        echo '<option value="'.$_num.'"> '.$_num.'</option>';
                    }
                    ?>
                </select>月
                <select name="day">
                    <?php
                    foreach (range(1,12) as $_num) {
                        echo '<option value="'.$_num.'"> '.$_num.'</option>';
                    }
                    ?>
                </select>日
                <input type="submit" value="查询" id="search" >

            </dd>
            </form>
        </dl>
    </div>
</div>


<?php
require ROOT_PATH.'includes/footer.inc.php';
?>
<script type="text/javascript" src="js/baseManage.inc.js"></script>
</body>
</html>
