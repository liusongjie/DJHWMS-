<?php
//set_time_limit(0);
ignore_user_abort(true);
/*file_put_contents('test.log', '1 connection status: ' . connection_status() . "abort:" . connection_aborted() . PHP_EOL, FILE_APPEND | LOCK_EX);*/

sleep(3);

for($i = 0; $i<100; $i++) {
    echo "22222";
    flush();
    sleep(1);
    file_put_contents('test.log', '2 connection status: ' . connection_status() . "abort:" . connection_aborted(). PHP_EOL, FILE_APPEND | LOCK_EX);
}
?>


<!DOCTYPE html>
<html>
<head>
</head>

<body ">

<h1>欢迎访问我的首页</h1>
<p>请关闭窗口，或按 F5 刷新页面。</p>

</body>
</html>
