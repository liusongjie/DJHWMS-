<?php
header("Content-Type:text/html;charset=utf-8");
session_start();
//定义个常量，用来授权调用includes里面的文件
define('IN_TG',true);
//定义个常量，用来指定本页的内容
define('SCRIPT','modify');
//引入公共文件
require dirname(__FILE__).'/includes/common.inc.php';

if(!empty($_SESSION['tableName'])) {
    $iniUrlCon=$_SERVER["QUERY_STRING"];
    $sql = <<<EOF
SELECT a.attname, a.attnotnull as notnull FROM pg_class as c,pg_attribute as a  where c.relname = '{$_SESSION['tableName']}' and a.attrelid = c.oid and a.attnum>1
EOF;
//echo $sql;
    $result = pg_query($sql);
    while ($row = pg_fetch_assoc($result)) {
        $fields[] = $row;
    }
//var_dump($_POST);
//echo $_POST["modifyMethod"];
    if ($_GET['action'] == "modify") {
        //经测试，还要截断action,否则修改完之后继续修改还会带着action=modify
        $re=array('action=modify'=>'');
        $iniUrlCon=strtr($iniUrlCon,$re);
         /*echo $iniUrlCon;
        exit();*/

        if (!isset($_POST['ids'])) {
            _alert_back('请先勾选要修改的数据');
        }
       // echo $_POST["modifyMethod"];
        if ($_POST["modifyMethod"] == "batchModify") {
            //修改之前，先检测是否存在
            if (!isset($_POST['batchs'])) {
                _alert_back('请先勾选要修改的字段');
            }
            foreach ($_POST['ids'] as $moId) {
               /* $sqlDec = <<<EOF
SELECT id FROM {$_SESSION['tableName']} WHERE id={$moId}
EOF;
                $dec = pg_fetch_assoc(pg_query($sqlDec));*/

            }

            $muflag=1;
            $moSqlPart = implode(',', $_POST['ids']);
            $moSqlPart1 = '';
            foreach ($_POST['batchs'] as $moField) {
                $moBatchName = $moField . 'batch';
                $moSqlPart1 .= $moField . '=' . '\'' . $_POST[$moBatchName] . '\'' . ',';
                $mulFieldData=trim($_POST[$moBatchName]);
                //检查1
                checkAll($moField,$mulFieldData);
                if( $mulFieldData=== ''){
                    $muflag=0;
                }
            }
            if($muflag==0){
                _alert_back('不能将要修改的字段设置为空！');
            }
           // echo $moSqlPart1.'<br/>';
            $moSqlPart2 = substr($moSqlPart1, 0, -1);
            $moSql = <<<EOF
UPDATE {$_SESSION['tableName']} SET {$moSqlPart2} WHERE id in ($moSqlPart)
EOF;
            /*echo $moSql;
            exit();*/
            if($exeMu=pg_query($moSql)){
                //_alert_info("修改成功");
                if(pg_affected_rows($exeMu)==count($_POST['ids'])){
                    _location("修改成功",'?'.$iniUrlCon);

                }else{
                    _location("修改成功,部分数据可能在别处被删除",'?'.$iniUrlCon);
                }
            }

            //从用户库中提取信息
            $userInfoSql = <<<EOF
SELECT lasttime,lastip FROM djhuser WHERE username='{$_COOKIE['username']}'
EOF;
            /*echo $userInfoSql;
            exit();*/
            $infos = pg_fetch_assoc(pg_query($userInfoSql));
            $content=str_replace("'","''",$moSql);
            //$content=$moSql;
            //插入数据库
            $upLogSql = <<<EOF
INSERT INTO log (username,tablename,operation,content,ip,logintime) VALUES('{$_COOKIE['username']}','{$_SESSION['tableName']}','{$scToCh[SCRIPT]}','{$content}','{$infos['lastip']}','{$infos['lasttime']}')
EOF;
            pg_query($upLogSql);

        } elseif ($_POST["modifyMethod"] == "singleModify") {
            //var_dump($_POST['singles']);
            //$simo单个需要修改的id号,$siMoIDField单条数据对应的id+字段名
           /* var_dump($_POST['ids']);
                            exit();*/
           pg_query('BEGIN');
            $siEffect=0;
            foreach ($_POST['ids'] as $siMoID) {
                $siflag=1;
                 /*var_dump($_POST['singles']);
                exit();*/
/*不置为空会出现UPDATE hydraulictable SET datetime='2011-01-31',precipitation='3',avgflow='114' WHERE id='31'
                UPDATE hydraulictable SET datetime='2011-01-31',precipitation='3',avgflow='114',datetime='2011-02-01',precipitation='2',avgflow='124' WHERE id='32'
UPDATE hydraulictable SET datetime='2011-01-31',precipitation='3',avgflow='114',datetime='2011-02-01',precipitation='2',avgflow='124',datetime='2011-02-02',precipitation='1',avgflow='102' WHERE id='33'*/
                $siSqlPart1 = '';
                //$siMoCHField改了之后，直接是原字段名
                foreach ($_POST['singles'] as $siMoField) {
                    //post数组中要修改的数据的键名
                    $siMoPostField = $siMoField . $siMoID;
                    //要修改的字段名，单个修改时被显示的所有的字段
                    $siSqlPart1 .= $siMoField . '=' . '\'' . $_POST[$siMoPostField] . '\'' . ',';
                    $input=trim($_POST[$siMoPostField]);
                    checkAll($siMoField,$input);
                    if($input===''){
                        pg_query("ROLLBACK");
                        _alert_back('不能将要修改的字段设置为空！');
                    }
                }
                $siSqlPart2 = substr($siSqlPart1, 0, -1);
                $siSql = <<<EOF
UPDATE {$_SESSION['tableName']} SET {$siSqlPart2} WHERE id='{$siMoID}'
EOF;
                /*echo $siSql;
                echo '<br/>';*/

                $exeMu=pg_query($siSql);
                if(pg_affected_rows($exeMu)==1){
    //从用户库中提取信息，放前面，因为后面会跳转
    $userInfoSql = <<<EOF
SELECT lasttime,lastip FROM djhuser WHERE username='{$_COOKIE['username']}'
EOF;
                    /*echo $userInfoSql;
                    exit();*/
                    $infos = pg_fetch_assoc(pg_query($userInfoSql));
                    //插入数据库
                    $content=str_replace("'","''",$siSql);
                    $upLogSql = <<<EOF
                INSERT INTO log (username,tablename,operation,content,ip,logintime) VALUES('{$_COOKIE['username']}','{$_SESSION['tableName']}','{$scToCh[SCRIPT]}','{$content}','{$infos['lastip']}','{$infos['lasttime']}')
EOF;
                    /* echo $upLogSql;
                     exit();*/
                    pg_query($upLogSql);
                }

                $siEffect+=pg_affected_rows($exeMu);
            }
            //exit();
            pg_query("COMMIT");



            if($siEffect==count($_POST['ids'])){
                _location("修改成功",'?'.$iniUrlCon);
            }else{
                _location("修改成功,部分数据可能在别处被删除",'?'.$iniUrlCon);
            }
        }
    }
//查询处理模块
    if ($_GET['firstAction'] == 'search') {
        $partSql = '';
        foreach ($fields as $field) {
            //ok
            //echo $_GET['first'.$field['attname']];
            //枚举类型处理
            $enumFields = array('loc', 'item', 'vname', 'stname', 'riname', 'sename', 'watercode', 'selocation');
            if (in_array($field['attname'], $enumFields) || ($field['attname']=='datetime' && $_SESSION['tableName']=='ftable')) {
                if ($_GET[$field['attname']] == 'all') {
                    continue;
                }
                $acArray[] = '(' . $field['attname'] . '=' . '\'' . $_GET[$field['attname']] . '\'' . ')';
                continue;
            }


            $acmin = pg_escape_string($_GET['first' . $field['attname']]);
            $acmax = pg_escape_string($_GET['second' . $field['attname']]);
            if($_SESSION['tableName']=='runofftable' || $_SESSION['tableName']=='metable'){
                if($field['attname']=='datetime'){
                    $acArray[]='(substr(datetime,7,2)||\'/\'||substring(datetime,1,6)||substr(datetime,9) BETWEEN substr(' . '\'' . $acmin . '\'' . ',7,2)||\'/\'||substring(' . '\'' . $acmin . '\'' . ',1,6)||substr(' . '\'' . $acmin . '\'' . ',9) and substr(' . '\'' . $acmax . '\'' . ',7,2)||\'/\'||substring(' . '\'' . $acmax . '\'' . ',1,6)||substr(' . '\'' . $acmax . '\'' . ',9)
                 )';
                    continue;
                }
            }
            // $partSql.=$field['attname'].' between '.$acmin.' and '.$acmax.' ';
            //$acArray[]='('.$field['attname'].' between '.$acmin.' and '.$acmax.' '.')';
            $acArray[] = '(' . $field['attname'] . ' between ' . '\'' . $acmin . '\'' . ' and ' . '\'' . $acmax . '\'' . ' ' . ')';
            //$acArray[]='('.$field['attname'].' between '.'{'.$acmin.'}'.' and '.'{'.$acmax.'}'.' '.')';
            //echo $acArray;
        }
        $sqlPart = implode(' and ', $acArray);
        //echo $sqlPart;
        /*echo $sqlPart;
          echo $partSql;
          echo '<br/>';*/
        $acSql = <<<EOF
SELECT * FROM {$_SESSION['tableName']} WHERE {$sqlPart} ORDER BY id
EOF;
        /*echo $acSql;
        exit();*/
        $resSearch = pg_query($acSql);
        $rowsSearch=array();
        while($rowsSearchIni=pg_fetch_assoc($resSearch)){
            $rowsSearch[]=$rowsSearchIni;
        }
        /*分页模块
  $_pagenum:从第几条开始提取
  $_pagesize:每页大小,
  */
        global $_pagenum,$_pagesize,$urlCon;
//接action=modify和page用不同变量的好处;page=xxx,action=xxx是在不同的链接上添加的，如果用同一个变量好像顺序正确的话也不会出问题

        $pos=strpos($iniUrlCon,'page');
        if(!!$pos){
            $urlCon=substr($iniUrlCon,0,$pos);
        }else{
            $urlCon=$iniUrlCon.'&';
        }
//echo sizeof($data);
//sizeof($data):数据总条数,15:每页大小
        if(!empty($_GET['pageSize'])){
            $_SESSION['pageSize']=$_GET['pageSize'];
        }
        $pageSize=15;
        if(!empty($_SESSION['pageSize'])){
            $pageSize=$_SESSION['pageSize'];
        }
        _page(sizeof($rowsSearch),$pageSize);
    }
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

  <?php require_once('includes/title.inc.php')?>
  <script type="text/javascript" src="js/jquery-3.1.0.min.js"></script>
  <link rel="stylesheet" type="text/css" href="js/jQuery-jcDate-master/src/jcDate.css" media="all" />
  <script type="text/javascript" src="js/jQuery-jcDate-master/src/jQuery-jcDate.js" charset="utf-8"></script>
  <script type="text/javascript" src="js/baseManage.inc1.js"></script>
<link rel="stylesheet" type="text/css" href="templateCss.css"/>
<style type="text/css">
    #fieldDisplay1 {
        width: 99%;
        height: auto;
        z-index: 1;
        /*margin-top: -15px;
        margin-right: 10px;
        margin-bottom: 10px;
        margin-left: 15px;*/
        background-color: #FFF;
        border-radius: 8px;
        font-size: 18px;
        overflow:auto;
        text-align: center;
        color:blue;
        font-weight: bold;
    }

</style>

</head>

<body bgcolor="#cfd4ff">
<?php require_once("includes/header.inc.php");  ?>
<div class="bodyContent">
<?php
require_once("includes/dbSelect.inc.php");
require_once("includes/dbFieldOperate.php");
?>





<?php if(!empty($_GET['firstAction'])){?>
<div id="mainDown">


  <form id="formSelect" method="post" action="?<?php echo $iniUrlCon?>&action=modify">
    <h2> 修改</h2>
      <?php
      _paging(2);
      ?>
      每页条数：
      <a  href="?<?php echo $urlCon."pageSize=15"; ?>">15</a>&nbsp&nbsp
      <a  href="?<?php echo $urlCon."pageSize=50"; ?>">50</a>&nbsp&nbsp
      <a  href="?<?php echo $urlCon."pageSize=100";  ?>">100</a>&nbsp&nbsp
      <br/>
    <input type="radio" name="modifyMethod" value="batchModify" id="batchMethod" />
    <label for="batchMethod"><span  class="title2"> 批量修改(<span class="explan">先点击修改方式，再勾选需要修改的数据条目，和需要批量修改的字段，填入数据，最后保存才能修改成功</span>)</span></label>
      <br/>
      <input type="radio" name="modifyMethod" value="singleModify" id="singleMethod" />
      <label for="singleMethod"><span  class="title2">  逐条修改(<span class="explan">先点击修改方式，再勾选需要修改的数据条目，填入数据，最后保存才能修改成功</span>)</span></label>
    <div class="displayClass" id="fieldDisplay">
      <table width="100%" border="1">
        <tr>
          <td><div class="displayMain">可修改字段(请勾选)</div></td>
          <?php foreach ($_GET['displays'] as $value){?>
            <td>

                <div class="displayMain" >
                    <input type="checkbox" name="batchs[]" value="<?php echo $value; ?>"  />
                    <label for=""><span  class="title2">  <?php echo winDisplay($value); ?> </span></label>
                </div>

              </td>
          <?php }?>
          <!--<td><div class="displayMain">是否选择</div></td>-->
            <td ><div class="displayMain">占位</div></td>
        </tr>
        <tr>

            <td><div class="displayMain">请填入数据</div></td>
            <?php foreach ($_GET['displays'] as $value){?>
                <td><div class="displayMain"><input type="text" class="batchModify" name="<?php echo $value.'batch'; ?>" readonly="readonly" ></div></td>
            <?php }?>
            <td ><div class="displayMain">占位</div></td>
            <!--<td><div class="displayMain">是否选择</div></td>-->
        </tr>
      </table>
    </div>

      <div id="fieldDisplay1" class="displayClass">
          <table width="100%" border="1">
              <tr>
                  <td><div class="displayMain">序号</div></td>
                  <?php foreach ($_GET['displays'] as $value){?>
                      <td>
                          <div class="displayMain">
                              <input type="checkbox" name="singles[]" checked="checked"  value="<?php echo $value; ?>"  />
                              <label for=""><span  class="title2">  <?php echo winDisplay($value); ?> </span></label>
                          </div>
                      </td>


                  <?php }?>

                  <td><div class="displayMain">是否选择</div></td>

              </tr>
          </table>
      </div>
<div id="display">
    <table width="100%" border="1">
  <!--<tr>
    <td><div class="displayMain">序号</div></td>
      <?php /*foreach ($_GET['displays'] as $value){*/?>
      <td>
          <div class="displayMain">
              <input type="checkbox" name="singles[]" checked="checked"  value="<?php /*echo $value; */?>"  />
              <label for=""><span  class="title2">  <?php /*echo winDisplay($value); */?> </span></label>
          </div>
      </td>


      <?php /*}*/?>

      <td><div class="displayMain">是否选择</div></td>

  </tr>-->
      <!--有多少条-->
      <?php for($i=0;$i<$pageSize;$i++){?>
  <tr>
    <td>
      <div class="displayMain"><?php echo $rowsSearch[$_pagenum+$i]['id']?></div>
    </td>
    <?php
    //错误理解：外层foreach用的临时变量$value遍历和里层foreach用的临时变量会冲突，解决方法:1去不同名字2将外层变量付给新的变量
    //实际上是函数没写正确，没用返回值;注意没用返回值光输出时$rowsSearch[iniField($value)],没取出结果
    foreach ($_GET['displays'] as $displayValue){?>

      <td><div class="displayMain"><input type="text" name="<?php echo $displayValue.$rowsSearch[$_pagenum+$i]['id']?>" class="singleModify" value="<?php $key=iniField($displayValue);
              echo $rowsSearch[$_pagenum+$i][$displayValue]; ?>" readonly="readonly"></div></td>

    <?php }?>
    <td><div class="displayMainSelect"><input class="selectSimpleInput" type="checkbox" disabled="disabled" name="ids[]" value="<?php echo $rowsSearch[$_pagenum+$i]['id']?>" /></div></td>
  </tr>
      <?php }?>
      <td colspan="<?php echo sizeof($fields)+2;?>">
        </td>
</table>
</div>
    <p><input class="selectSimpleInput" disabled="disabled" type="checkbox" name="selectAll" id="selectAll"  />
    <label for="selectAll">全选</label>
    <input type="checkbox" class="selectSimpleInput" disabled="disabled" name="selectReverse" id="selectReverse"  />
    <label for="selectReverse">反选</label></p>
    <input id="delete" type="submit" value="修改"/>
  </form>



</div>
<?php }?>
    </div>
<?php require_once("includes/footer.inc.php")?>
<script type="text/javascript" src="js/<?php echo SCRIPT?>.js"></script>
</body>
</html>
