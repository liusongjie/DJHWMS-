<?php
/**
* TestGuest Version1.0
* ================================================
* Copy 2010-2012 yc60
* Web: http://www.yc60.com
* ================================================
* Author: Lee
* Date: 2010-8-10
*/
header("Content-Type:text/html;charset=utf-8");
session_start();
//定义个常量，用来授权调用includes里面的文件
define('IN_TG',true);
//定义个常量，用来指定本页的内容
define('SCRIPT','index');
//引入公共文件
require dirname(__FILE__).'/includes/common.inc.php'; //转换成硬路径，速度更快
global $_system;
//echo 2;
//开始处理登录状态
if ($_GET['action'] == 'login') {
	if (!empty($_system['code'])) {
		//为了防止恶意注册，跨站攻击
		_check_code($_POST['code'], $_SESSION['code']);
	}
//引入验证文件
	include ROOT_PATH . 'includes/login.func.php';
//接受数据
	$_clean = array();
	$_clean['username'] = _check_username($_POST['username'], 2, 20);
	$_clean['password'] = _check_password($_POST['password'], 4);
	echo $_clean['username'];
//$_clean['time'] = _check_time($_POST['time']);
//到数据库去验证,php的变量写到sql语句中时，如果不是数字，则需要加上引号,sql语句中引用变量必须要加花括号
	global $_conn;
	$sql = <<<EOF
			SELECT username,authority,department,loginstate,active From djhuser WHERE username='{$_clean['username']}' AND password='{$_clean['password']}';
EOF;
	//echo $sql;
	$result = pg_query($sql);
//$rows=pg_fetch_array($result,PGSQL_ASSOC);
	$rows = pg_fetch_assoc($result);
//echo $rows['username'];
	/*$sql=<<<EOF
            SELECT username,authority,department,loginstate From djhuser WHERE id=1;
    EOF;
    echo $sql;
    $result=pg_query($sql);
    $rows=pg_fetch_row($result);
    echo $rows[0];*/
	/*$result=pg_query("SELECT * From djhuser WHERE username='{$_clean['username']}' AND password='{$_clean['password']}'");*/
	/*$_conn = pg_connect("host=localhost port=5432 dbname=postgres user=postgres password=123456");
    $result0=pg_query($_conn,"SELECT * From hydraulictable WHERE id=15");
    $rows0=pg_fetch_array($result0,PGSQL_ASSOC);
    echo $rows0['datetime'];
    $result=pg_query($_conn,"SELECT * From djhuser WHERE username=contract");

    $rows=pg_fetch_array($result,PGSQL_ASSOC);
    echo $rows['username'];
    echo 2;*/
	/*if(!!$rows=_fetch_array("SELECT username,authority,department,loginstate From djhuser WHERE username='{$_clean['username']}' AND password='{$_clean['password']}'")){*/
echo !!$rows;
	if (!!$rows) {
		//echo $rows['username'];
		//不允许用户异地登录
		/*if($rows['loginstate']==true){
            _alert_back('你的账号已经在其他地方登陆');
        }*/
		if ($rows['active'] == false) {
			_alert_back('你的账号未激活');
		}
		//登陆成功后，更改登录信息
		$updateSql = <<<EOF
				UPDATE djhuser SET 
									loginState=true,
									lastTime=NOW(),
									lastIp='{$_SERVER['REMOTE_ADDR']}',
									loginCount=loginCount+1
							  WHERE
									username='{$rows['username']}';
EOF;

		pg_query($updateSql);
		//_setcookies($_clean['username']);
		setcookie('username',$_clean['username']);
		echo $_COOKIE['username'];
		if ($rows['authority'] == 1) {
			$_SESSION['authority'] = 1;
			$_SESSION['superUser'] = $_clean['username'];
		} elseif ($rows['authority'] == 2) {
			$_SESSION['authority'] = 2;
			$_SESSION['admin'] = $_clean['username'];
		}
		//记录用户所属部门

		$_SESSION['department'] = $rows['department'];
		pg_close();
		//pg_errormessage($_conn);
		//设置了cookie，重新刷新，解决cookie 慢半拍的问题
		_location(null, 'index.php');
	} else {
		_close();
		//echo "failed";
		_session_destroy();
		_location('用户名密码不正确或者该账户未被激活！', 'index.php?fres=new');
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php 
	require ROOT_PATH.'includes/title.inc.php';
?>

	<script type="text/javascript" src="http://keleyi.com/keleyi/pmedia/jquery/jquery-1.4.2.min.js"></script>
	<script type="text/javascript">
		// 树状菜单
		$(document).ready(function () {
			$(".l1").toggle(function () {
				$(".slist").animate({ height: 'toggle', opacity: 'hide' }, "slow");
				$(this).next(".slist").animate({ height: 'toggle', opacity: 'toggle' }, "slow");
			}, function () {
				$(".slist").animate({ height: 'toggle', opacity: 'hide' }, "slow");
				$(this).next(".slist").animate({ height: 'toggle', opacity: 'toggle' }, "slow");
			});

			/*$(".l2").toggle(function () {
				$(this).next(".sslist").animate({ height: 'toggle', opacity: 'toggle' }, "slow");
			}, function () {
				$(this).next(".sslist").animate({ height: 'toggle', opacity: 'toggle' }, "slow");
			});*/

			/*$(".l2").click(function () {
				$(".l3").removeClass("currentl3");
				$(".l2").removeClass("currentl2");
				$(this).addClass("currentl2");
			});*/

			$(".l3").click(function () {
				$(".l3").removeClass("currentl3");
				$(this).addClass("currentl3");
			});

			$(".close").toggle(function () {
				$(".slist").animate({ height: 'toggle', opacity: 'show' }, "fast");
				$(".sslist").animate({ height: 'toggle', opacity: 'show' }, "fast");
			}, function () {
				$(".slist").animate({ height: 'toggle', opacity: 'hide' }, "fast");
				$(".sslist").animate({ height: 'toggle', opacity: 'hide' }, "fast");
			});
		});
	</script>
</head>
<body class="index">

<?php 
	require ROOT_PATH.'includes/header.inc.php';
?>
<div id="img">
	<img src="images/ditu.jpg" height="100%" usemap="#areamap" alt="ditu"/>
	<map name="areamap" id="areamap">
		<area
			shape="rect"
			coords="470,50,550,120"
			href ="baseManage.php?area=dongjianghu"
			target ="_blank"
			alt="东江湖" />
	</map>
</div>


<div class="module" id="manage" >

	<dl id="dataManage">
		<h1>综合数据管理</h1>
		<h2 class="l1"><a href="#">水文局</a></h2>
		<ul class="slist">
			<li class="l2"><a href="baseManage.php?department=水力&baseType=水文">·水文数据库</a></li>
			<li class="l2"><a href="baseManage.php?department=水力&baseType=水力">·水质数据库</a></li>
		</ul>
		<h2 class="l1"><a href="#">环保局</a></h2>
		<ul class="slist">
			<li class="l2"><a href="#">·环保数据库</a></li>
		</ul><h2 class="l1"><a href="#">气象局</a></h2>
		<ul class="slist">
			<li class="l2"><a href="#">·气象数据库</a></li>
		</ul><h2 class="l1"><a href="#">农业局</a></h2>
		<ul class="slist">
			<li class="l2"><a href="#">·农调数据库</a></li>
		</ul><h2 class="l1"><a href="#">统计局</a></h2>
		<ul class="slist">
			<li class="l2"><a href="#">·统计数据库</a></li>
		</ul><h2 class="l1"><a href="#">移民局</a></h2>
		<ul class="slist">
			<li class="l2"><a href="#">·移民数据库</a></li>
		</ul>
		<h2 class="l1"><a href="#">水位局</a></h2>
		<ul class="slist">
			<li class="l2"><a href="#">·水位数据库</a></li>
		</ul>
		<h2 class="l1"><a href="#">财政局</a></h2>
		<ul class="slist">
			<li class="l2"><a href="#">·财政数据库</a></li>
		</ul>
		<h2 class="l1"><a href="#">畜牧局</a></h2>
		<ul class="slist">
			<li class="l2"><a href="#">·畜牧数据库</a></li>
		</ul>

	</dl>
</div>
<div class="module" id="analyze">
	<!--<p>综合数据分析</p>-->
	<dl id="dataAnalyze">
		<h1>综合数据管理</h1>
		<h2 class="l1"><a href="#">水利局</a></h2>
		<ul class="slist">
			<li class="l2"><a href="#">·水文数据库</a></li>
		</ul>
		<h2 class="l1"><a href="#">环保局</a></h2>
		<ul class="slist">
			<li class="l2"><a href="#">·环保数据库</a></li>
		</ul><h2 class="l1"><a href="#">气象局</a></h2>
		<ul class="slist">
			<li class="l2"><a href="#">·气象数据库</a></li>
		</ul><h2 class="l1"><a href="#">农业局</a></h2>
		<ul class="slist">
			<li class="l2"><a href="#">·农调数据库</a></li>
		</ul><h2 class="l1"><a href="#">统计局</a></h2>
		<ul class="slist">
			<li class="l2"><a href="#">·统计数据库</a></li>
		</ul><h2 class="l1"><a href="#">移民局</a></h2>
		<ul class="slist">
			<li class="l2"><a href="#">·移民数据库</a></li>
		</ul>
		<h2 class="l1"><a href="#">水位局</a></h2>
		<ul class="slist">
			<li class="l2"><a href="#">·水位数据库</a></li>
		</ul>
		<h2 class="l1"><a href="#">财政局</a></h2>
		<ul class="slist">
			<li class="l2"><a href="#">·财政数据库</a></li>
		</ul>
		<h2 class="l1"><a href="#">畜牧局</a></h2>
		<ul class="slist">
			<li class="l2"><a href="#">·畜牧数据库</a></li>
		</ul>
	</dl>
</div>



<?php 
	require ROOT_PATH.'includes/footer.inc.php';
?>
<script type="text/javascript" src="js/index.js"></script>
</body>
</html>
