<?php
/**
 * Created by PhpStorm.
 * User: hetong
 * Date: 2016/8/16
 * Time: 10:32
 */
header("Content-type:text/html;charset=utf-8");
session_start();
//定义个常量，用来授权调用includes里面的文件
define('IN_TG',true);
//定义个常量，用来指定本页的内容
define('SCRIPT','shuiwenSuperSearchResult');
//引入公共文件
require dirname(__FILE__).'/includes/common.inc.php';
require_once("http://localhost:8080/JavaBridgeTemplate611/java/Java.inc");
if($_SESSION['department']=="水文" || $_SESSION['authority']==2){
    $superSearch=new Java("HYSearch");
    $convert=new Java("ConvertList");
}else{
    _alert_back('你不是'.$_SESSION['department'].'部门的人');
}




if($_GET['action']=='delete'){
    $str=implode(',',$_POST['ids']);
    $batchDel=new Java("HYDelete");
    $batchDel->MultipleIDDelete($str);
    echo "<script type='text/javascript'>history.back();</script>";
    //echo "<script type='text/javascript'>window.onload();</script>";

}

if(isset($_GET['dateSelect']) && !isset($_GET['preSelect']) && !isset($_GET['avgSelect'])) {
    echo $dateSql = $_GET['date0'] . ".." . $_GET['date1'];
    //$result=$superSearch->DTRangeSearch();
    $result = $superSearch->DTRangeSearch($_GET['date0'], $_GET['date1']);
    $data = java_values($convert->convertList($result));
    //var_dump($data);
}elseif(!isset($_GET['dateSelect']) && isset($_GET['preSelect']) && !isset($_GET['avgSelect'])){
    switch($_GET['precipitation']){
        case 0:
            $result = $superSearch->PerciGTSearch($_GET['GTPre']);
            $data = java_values($convert->convertList($result));

            break;
        case 1:
            $result = $superSearch->PerciLTSearch($_GET['LTPre']);
            $data = java_values($convert->convertList($result));
            break;
        case 2:
            $result = $superSearch->PerciRangeSearch($_GET['midPre0'], $_GET['midPre1']);
            $data = java_values($convert->convertList($result));
            break;
        default:
            break;
    }


}elseif(!isset($_GET['dateSelect']) && !isset($_GET['preSelect']) && isset($_GET['avgSelect'])){
    switch($_GET['avgFlow']){
        case 0:
            $result = $superSearch->AFGTSearch($_GET['GTFlow']);
            $data = java_values($convert->convertList($result));
            break;
        case 1:
            $result = $superSearch->AFLTSearch($_GET['LTFlow']);
            $data = java_values($convert->convertList($result));
            break;
        case 2:
            $result = $superSearch->AFRangeSearch($_GET['midFlow0'], $_GET['midFlow1']);
            $data = java_values($convert->convertList($result));
            break;
        default:
            break;
    }
}

/*分页模块
$_pagenum:从第几条开始提取
$_pagesize:每页大小,
*/
global $_pagenum,$_pagesize;

if(!empty($_GET['pageSize'])){
    $_SESSION['waterSuperPageSize']=$_GET['pageSize'];
}
$pageSize=15;
if(!empty($_SESSION['waterSuperPageSize'])){
    $pageSize=$_SESSION['waterSuperPageSize'];
}
/*if(!empty($_GET['pageSize'])){
    $pageSize=$_GET['pageSize'];
}else{
    $pageSize=15;
}*/
$iniUrlCon=$_SERVER["QUERY_STRING"];
//echo $iniUrlCon;
$pos=strpos($iniUrlCon,'page');
if(!!$pos){
    $urlCon=substr($iniUrlCon,0,$pos);
}else{
    $urlCon=$iniUrlCon.'&';
}
//echo $urlCon;

/*echo $nexUrlCon;
$urlCon=$nexUrlCon.'&';*/

//echo sizeof($data);
//sizeof($data):数据总条数,15:每页大小
_page(sizeof($data),$pageSize);


?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <?php
    //echo ROOT_PATH.'includes/title.inc.php';
    require ROOT_PATH.'includes/title.inc.php';
    ?>
    <link rel="stylesheet" type="text/css" href="js/jQuery-jcDate-master/src/jcDate.css" media="all" />
    <!-- <script src="http://cdn.bootcss.com/jquery/2.2.4/jquery.js"></script>-->
    <script type="text/javascript" src="js/jquery-3.1.0.min.js"></script>
    <script type="text/javascript" src="js/jQuery-jcDate-master/src/jQuery-jcDate.js" charset="utf-8"></script>
    <script type="text/javascript" src="js/baseManage.inc1.js"></script>
    <script type="text/javascript" src="js/shuiwenSuperSearchResult.js"></script>
</head>
<body>
<?php
require ROOT_PATH.'includes/header.inc.php';
?>

<div id="baseManage">
    <?php
    require ROOT_PATH.'includes/baseManage.inc.php';
    ?>
    <div id="baseManageMain">
        <h2><?php echo $_GET['baseType'].'数据查询结果'?></h2>

        <form method="post" action="?<?php echo $urlCon.'&'?>action=delete">
            <table cellspacing="1">
                <tr>
                    <th>id</th>
                    <th>逐日降雨量(mm)</th>
                    <th>逐日平均流量(m3/s)</th>
                    <th>日期</th>
                    <?php if ($_SESSION['authority']==1 || $_SESSION['authority']==2){?> <th>删除</th><?php };?>
                </tr>
                <?php
                for($i=0;$i<$_pagesize;$i++){
                    ?>
                    <tr>
                        <td><?php echo $data[$_pagenum+$i]["id"]?></td>
                        <td><?php echo $data[$_pagenum+$i]["percipitation"]?></td>
                        <td><?php echo $data[$_pagenum+$i]["avgflow"]?></td>
                        <td><?php echo $data[$_pagenum+$i]["datetime"]?></td>
                        <td><input type="checkbox" name="ids[]" value="<?php echo $data[$_pagenum+$i]["id"];?>"  /></td>

                    </tr>
                    <?php

                }

                ?>
                <?php if ($_SESSION['authority']==1 || $_SESSION['authority']==2){ ?><tr><td colspan="5" class="selectAll"><label for="all" >全选 <input type="checkbox" name="chkall" id="all" /></label>&nbsp&nbsp<label for="reverse" >反选 <input type="checkbox" name="reverse" id="reverse" /></label> &nbsp&nbsp<input type="submit" value="批删除" /></td></tr><?php }?>
                <tr>
                    <td colspan="5">
                        每页条数：
                        <a  href="?<?php echo "pageSize=15".$urlCon; ?>">15</a>&nbsp&nbsp
                        <a  href="?<?php echo "pageSize=50".$urlCon; ?>">50</a>&nbsp&nbsp
                        <a  href="?<?php echo "pageSize=100".$urlCon; ?>">100</a>&nbsp&nbsp
                        <a  href="?<?php echo "pageSize=1000".$urlCon; ?>">1000</a>&nbsp&nbsp

                    </td>
                </tr>
            </table>
        </form>
        <?php _paging(2);?>
    </div>
</div>


<?php
require ROOT_PATH.'includes/footer.inc.php';
?>
<script type="text/javascript" src="js/baseManage.inc.js"></script>
</body>
</html>

