<?php
/**
 * Created by PhpStorm.
 * User: hetong
 * Date: 2016/8/25
 * Time: 14:12
 */

/*$paths = "C://Documents and Settings//sk//Desktop//s//";
$d = dir($paths);
while (false !== ($entry = $d->read())) {
    $table_change = array(' '=>'_');
    $newName = strtr($entry,$table_change);
    $newName = substr($newName, 0,-4);
    rename($paths.$entry, $paths.$newName."_s.jpg");
}
$d->close();
echo "done";*/
/*function FindFile($dir)
{
    $files = array();
    if($handle = opendir($dir))   //打开目录
    {
        while(($file = readdir($handle)) !== false)  //读取文件名
        {
            if($file !="." && $file !="..")    //排除上级目录 和当前目录
            {
                if(is_dir($dir."\\".$file))    //如果还是文件夹  继续遍历
                {
                    $files[$file] = scandir($dir . "/" . $file);
                }else {
                    $files[] = $file;
                }
            }
        }
        closedir($handle);
        return $files;
    }
}
$aaa = FindFile("E:\\project\\查询模板");
var_dump($aaa);*/

$files = array();
/*$handle = opendir("E:/project/查询模板");*/
$dir="E:/project/check";
echo str_replace("world","Shanghai","Hello world!");
if($handle = opendir($dir))   //打开目录
{
    while(($file = readdir($handle)) !== false)  //读取文件名
    {
        if($file !="." && $file !="..")    //排除上级目录 和当前目录
        {
            if(is_dir($dir."/".$file))    //如果还是文件夹  继续遍历
            {
                $files[$file] = scandir($dir . "/" . $file);
                foreach($files[$file] as $key =>  &$value){
                    echo $value;
                    echo '<br/>';
                    $newname=str_replace('renliziyuan','renjunshouru',$value);
                    echo $value;
                    echo '<br/>';
                    rename($dir."/".$file."/".$value,$dir."/".$file."/".$newname);
                }




               // print_r($files[$file]);
            }else {
                $files[] = $file;
            }
        }
       // var_dump($files[$file]);
    }
    closedir($handle);
    var_dump($files);
}