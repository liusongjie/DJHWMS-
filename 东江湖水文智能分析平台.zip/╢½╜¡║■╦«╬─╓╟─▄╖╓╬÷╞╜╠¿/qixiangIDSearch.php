<?php
/**
 * TestGuest Version1.0
 * ================================================
 * Copy 2010-2012 yc60
 * Web: http://www.yc60.com
 * ================================================
 * Author: Lee
 * Date: 2010-9-2
 */
header("Content-Type:text/html;charset=utf-8");
header("Cache-Control: no-cache");
session_start();
//定义个常量，用来授权调用includes里面的文件
define('IN_TG',true);
//定义个常量，用来指定本页的内容
define('SCRIPT','qixiangIDSearch');
//引入公共文件
require dirname(__FILE__).'/includes/common.inc.php';
/*if(!empty($_GET['area'])){
	header('Location: manage_project.php?area='.$_GET['area']);
}*/
require_once("http://localhost:8080/JavaBridgeTemplate611/java/Java.inc");

/*$search=new Java("ConvertList");
$result=new Java("SearchByID");

$result1=java_values($search->convertList($result->fileSearch()));

var_dump($result1);
$endResult=$result1[0];*/
if($_SESSION['department']=="气象" || $_SESSION['authority']==2){
    $search=new Java("ATSearch");
    $convert=new Java("ConvertList");
    $inidata=java_values($convert->convertList($search->IDSearch()));
    $data=$inidata[0];
}



/*$data=java_values($convert->convertList($search->IDSearch()));*/
//var_dump($data);
//echo $endResult["datetime"];
//必须是管理员才能登录
//_manage_login();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <?php
    //echo ROOT_PATH.'includes/title.inc.php';
    require ROOT_PATH.'includes/title.inc.php';
    ?>
    <!--  <script type="text/javascript" src="js/baseManage.header.js"></script>-->
</head>
<body>
<?php
require ROOT_PATH.'includes/header.inc.php';
?>

<div id="baseManage">
    <?php
    require ROOT_PATH.'includes/baseManage.inc.php';
    ?>
    <div id="baseManageMain">
        <h2><?php echo $_GET['baseType'].'数据查询结果'?></h2>
        <table cellspacing="1">
            <tr>
                <th>id</th>
                <th>年份</th>
                <th>年暴雨日</th>
                <th>1月气温</th>
                <th>2月气温</th>
                <th>3月气温</th>
                <th>4月气温</th>
                <th>5月气温</th>
                <th>6月气温</th>
                <th>7月气温</th>
                <th>8月气温</th>
                <th>9月气温</th>
                <th>10月气温</th>
                <th>11月气温</th>
                <th>12月气温</th>
                <th>年平均气温</th>
                <th>年最低气温</th>
                <th>年最高气温</th>
                <th>年蒸发量</th>
            </tr>
            <tr>
                <?php
/*                foreach($data as $key=>$value){
                    echo '<td>'.$value.'</td>';
                }
                */?>
                <td><?php echo $data["id"]?></td>
                <td><?php echo $data["datetime"]?></td>
                <td><?php echo $data["arsd"]?></td>
                <td><?php echo $data["jan"]?></td>
                <td><?php echo $data["feb"]?></td>
                <td><?php echo $data["mar"]?></td>
                <td><?php echo $data["apr"]?></td>
                <td><?php echo $data["may"]?></td>
                <td><?php echo $data["june"]?></td>
                <td><?php echo $data["july"]?></td>
                <td><?php echo $data["aug"]?></td>
                <td><?php echo $data["sept"]?></td>
                <td><?php echo $data["oct"]?></td>
                <td><?php echo $data["nov"]?></td>
                <td><?php echo $data["dec"]?></td>
                <td><?php echo $data["aaat"]?></td>
                <td><?php echo $data["aminat"]?></td>
                <td><?php echo $data["amaxat"]?></td>
                <td><?php echo $data["aec"]?></td>
            </tr>
        </table>
    </div>
</div>


<?php
require ROOT_PATH.'includes/footer.inc.php';
?>
<script type="text/javascript" src="js/baseManage.inc.js"></script>
</body>
</html>
