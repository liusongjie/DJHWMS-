<?php
/**
 * Created by PhpStorm.
 * User: hetong
 * Date: 2016/8/14
 * Time: 12:00
 */
header("Content-Type:text/html;charset=utf-8");
session_start();
//定义个常量，用来授权调用includes里面的文件
define('IN_TG',true);
//定义个常量，用来指定本页的内容
define('SCRIPT','shuiwenWholeSearch');
//引入公共文件
require dirname(__FILE__).'/includes/common.inc.php';



//提取数据
require_once("http://localhost:8080/JavaBridgeTemplate611/java/Java.inc");

//删除数据
if($_GET["action"]=="delete" && isset($_POST["ids"])){
    $shouldDelete=pg_escape_string(implode(",",$_POST["ids"]));
    $str=implode(',',$_POST['ids']);
    $batchDel=new Java("HYDelete");
    $batchDel->MultipleIDDelete($str);
    echo "<script type='text/javascript'>history.back();</script>";
}

$HYSearch=new Java("HYSearch");
$convert=new Java("ConvertList");
$result=$HYSearch->SearchAll();
$inidata=$convert->convertList($result);
$data=java_values($inidata);
//var_dump($data);

/*分页模块
$_pagenum:从第几条开始提取
$_pagesize:每页大小,
*/
global $_pagenum,$_pagesize,$urlCon;
//echo sizeof($data);
//sizeof($data):数据总条数,15:每页大小
if(!empty($_GET['pageSize'])){
    $_SESSION['waterWholePageSize']=$_GET['pageSize'];
}
$pageSize=15;
if(!empty($_SESSION['waterWholePageSize'])){
    $pageSize=$_SESSION['waterWholePageSize'];
}
/*if($_SESSION['pageSize0']!=15){

}*/

_page(sizeof($data),$pageSize);
//$urlCon='baseType='.$_SESSION['department'].'&'.'pageSize='.$pageSize.'&';
$urlCon='baseType='.$_SESSION['department'].'&';

?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <?php
    //echo ROOT_PATH.'includes/title.inc.php';
    require ROOT_PATH.'includes/title.inc.php';
    ?>
    <!--  <script type="text/javascript" src="js/baseManage.header.js"></script>-->
    <script type="text/javascript" src="js/baseManage.inc1.js"></script>

</head>
<body>
<?php
require ROOT_PATH.'includes/header.inc.php';
?>

<div id="baseManage">
    <?php
    require ROOT_PATH.'includes/baseManage.inc.php';
    ?>
    <div id="baseManageMain">
        <h2><?php echo $_GET['baseType'].'数据查询结果'?></h2>
        <form method="post" action="?action=delete">
        <table cellspacing="1">
            <tr>
                <th>id</th>
                <th>逐日降雨量(mm)</th>
                <th>逐日平均流量(m3/s)</th>
                <th>日期</th>
               <?php if ($_SESSION['authority']==1 || $_SESSION['authority']==2){?> <th>删除</th><?php };?>
            </tr>
            <?php

                for($i=0;$i<$pageSize;$i++){
                    ?>
                    <tr>
                        <td><?php echo $data[$_pagenum+$i]["id"]?></td>
                        <td><?php echo $data[$_pagenum+$i]["percipitation"]?></td>
                        <td><?php echo $data[$_pagenum+$i]["avgflow"]?></td>
                        <td><?php echo $data[$_pagenum+$i]["datetime"]?></td>
                        <?php if ($_SESSION['authority']==1 || $_SESSION['authority']==2){?><td><input type="checkbox" name="ids[]" value="<?php echo $data[$_pagenum+$i]["id"];?>"  /></td><?php };?>

                    </tr>
            <?php

                }

            ?>
            <?php if ($_SESSION['authority']==1 || $_SESSION['authority']==2){?><tr><td colspan="5" class="selectAll"><label for="all" >全选 <input type="checkbox" name="chkall" id="all" /></label>&nbsp&nbsp<label for="reverse" >反选 <input type="checkbox" name="reverse" id="reverse" /></label> &nbsp&nbsp<input type="submit" value="批删除" /></td></tr><?php };?>
            <tr>
                <td colspan="5">
                    每页条数：
                    <a  href="?<?php echo $urlCon."pageSize=15"; ?>">15</a>&nbsp&nbsp
                    <a  href="?<?php echo $urlCon."pageSize=50"; ?>">50</a>&nbsp&nbsp
                    <a  href="?<?php echo $urlCon."pageSize=100";  ?>">100</a>&nbsp&nbsp
                    <a  href="?<?php echo $urlCon."pageSize=1000";  ?>">1000</a>&nbsp&nbsp

                </td>
            </tr>
        </table>
        </form>
       <?php _paging(2);?>
    </div>
</div>


<?php
require ROOT_PATH.'includes/footer.inc.php';
?>
<!--<script type="text/javascript" src="js/wholeSearch.js"></script>-->

</body>
</html>


