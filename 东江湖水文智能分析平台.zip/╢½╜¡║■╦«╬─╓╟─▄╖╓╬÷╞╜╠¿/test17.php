



<html>
<body>
<!--1降雨量表-->
<?php
if(isset($_POST['select']) && $_POST['select']=="hydraulictable"){
    ?>
    <table  width="700" border="1" cellpadding="1" cellspacing="1" bordercolor="#FFFFFF" bgcolor="#666666">
        <!--第二行-->
        <tr>
            <td  align="center" bgcolor="#FFFFFF">您的账号：</td>
            <td bgcolor="#FFFFFF"><?php echo $_SESSION['user']; ?></td>
            <td  bgcolor="#FFFFFF">您的IP地址：</td>
            <td bgcolor="#FFFFFF"><?php echo $_SERVER["REMOTE_ADDR"];?></td>
            <td  bgcolor="#FFFFFF">查询时间：</td>
            <td bgcolor="#FFFFFF"><?php date_default_timezone_set('Etc/GMT-8');     //这里设置了时区
                echo date("Y-m-d H:i:s");?></td>
        </tr>
        <tr>
            <td align="center" bgcolor="#FFFFFF">查询数据库名称：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
            <td align="center" bgcolor="#FFFFFF">查询数据条数：</td>
            <td bgcolor="#FFFFFF"><?php $sql="SELECT COUNT(*) AS count FROM TABLE ";
                $result=pg_fetch_assoc(pg_query($sql));
                $count=$result['count']; echo $count;?></td>
            <td bgcolor="#FFFFFF">天数：</td>
            <td bgcolor="#FFFFFF"></td>
        </tr>
        <tr>
            <td align="center" bgcolor="#FFFFFF">降雨量最大值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
            <td align="center" bgcolor="#FFFFFF">降雨量最小值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
            <td align="center" bgcolor="#FFFFFF">降雨量平均值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
        </tr>
        <tr>
            <td align="center" bgcolor="#FFFFFF">平均流量最大值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
            <td align="center" bgcolor="#FFFFFF">平均流量最小值：</td>
            <td bgcolor="#FFFFFF">
                <?php
                mysql_select_db("date");
                $result=mysql_query("select max(id+0) max_id from music",$conn);
                $field=mysql_fetch_row($result);
                echo $field;
                ?>
            </td>
            <td align="center" bgcolor="#FFFFFF">平均流量平均值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
        </tr>
        <tr>
            <td align="center" bgcolor="#FFFFFF">时间最大值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
            <td align="center" bgcolor="#FFFFFF">时间最小值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
            <td align="center" bgcolor="#FFFFFF">平均流量最大值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
        </tr>
    </table>
    <?php
}
?>

<!--2水资源表-->
<?php
if(isset($_POST['select']) && $_POST['select']=="wqmtable"){
    ?>
    <table  width="700" border="1" cellpadding="1" cellspacing="1" bordercolor="#FFFFFF" bgcolor="#666666">
        <!--第二行-->
        <tr>
            <td  align="center" bgcolor="#FFFFFF">您的账号：11</td>
            <td bgcolor="#FFFFFF"><?php echo $_SESSION['user']; ?></td>
            <td  bgcolor="#FFFFFF">您的IP地址：11</td>
            <td bgcolor="#FFFFFF"><?php echo $_SERVER["REMOTE_ADDR"];?></td>
            <td  bgcolor="#FFFFFF">查询时间：11</td>
            <td bgcolor="#FFFFFF"><?php date_default_timezone_set('Etc/GMT-8');     //这里设置了时区
                echo date("Y-m-d H:i:s");?></td>
        </tr>
        <tr>
            <td align="center" bgcolor="#FFFFFF">查询数据库名称：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
            <td align="center" bgcolor="#FFFFFF">查询数据条数：</td>
            <td bgcolor="#FFFFFF"><?php $sql="SELECT COUNT(*) AS count FROM TABLE ";
                $result=pg_fetch_assoc(pg_query($sql));
                $count=$result['count']; echo $count;?></td>
            <td bgcolor="#FFFFFF">天数：</td>
            <td bgcolor="#FFFFFF"></td>
        </tr>
        <tr>
            <td align="center" bgcolor="#FFFFFF">时间最大值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
            <td align="center" bgcolor="#FFFFFF">时间最小值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
            <td align="center" bgcolor="#FFFFFF">0000</td>
            <td bgcolor="#FFFFFF">00000</td>
        </tr>
        <tr>
            <td align="center" bgcolor="#FFFFFF">测站名称：</td>
            <td bgcolor="#FFFFFF">  1.郴州市<br>2.资兴市</td>
            <td align="center" bgcolor="#FFFFFF">河流名称：</td>
            <td bgcolor="#FFFFFF">  1.资江耒水<br></td>
            <td align="center" bgcolor="#FFFFFF">断面名称：</td>
            <td bgcolor="#FFFFFF">  1.滁口<br>2.黄草<br>更多...</td>
        </tr>
        <tr>
            <td align="center" bgcolor="#FFFFFF">水期代码：</td>
            <td bgcolor="#FFFFFF">  1.K<br>2.F<br>3.P</td>
            <td align="center" bgcolor="#FFFFFF">断面位置：</td>
            <td bgcolor="#FFFFFF">  1.左<br>2.中<br>3.右</td>
            <td align="center" bgcolor="#FFFFFF">000</td>
            <td bgcolor="#FFFFFF">  000</td>
        </tr>
        <tr>
            <td align="center" bgcolor="#FFFFFF">水温最大值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
            <td align="center" bgcolor="#FFFFFF">水温最小值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
            <td align="center" bgcolor="#FFFFFF">水温平均值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
        </tr>
        <tr>
            <td align="center" bgcolor="#FFFFFF">流量最大值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
            <td align="center" bgcolor="#FFFFFF">流量最小值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
            <td align="center" bgcolor="#FFFFFF">流量平均值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
        </tr>
        <tr>
            <td align="center" bgcolor="#FFFFFF">PH最大值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
            <td align="center" bgcolor="#FFFFFF">PH最小值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
            <td align="center" bgcolor="#FFFFFF">PH最大值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
        </tr>
        <tr>
            <td align="center" bgcolor="#FFFFFF">溶解氧最大值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
            <td align="center" bgcolor="#FFFFFF">溶解氧最小值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
            <td align="center" bgcolor="#FFFFFF">溶解氧最大值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
        </tr>
        <tr>
            <td align="center" bgcolor="#FFFFFF">CODMn最大值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
            <td align="center" bgcolor="#FFFFFF">CODMn最小值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
            <td align="center" bgcolor="#FFFFFF">CODMn最大值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
        </tr>
        <tr>
            <td align="center" bgcolor="#FFFFFF">BD5最大值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
            <td align="center" bgcolor="#FFFFFF">BD5最小值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
            <td align="center" bgcolor="#FFFFFF">BD5最大值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
        </tr>
        <tr>
            <td align="center" bgcolor="#FFFFFF">化学需氧量最大值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
            <td align="center" bgcolor="#FFFFFF">化学需氧量最小值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
            <td align="center" bgcolor="#FFFFFF">化学需氧量最大值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
        </tr>
        <tr>
            <td align="center" bgcolor="#FFFFFF">氨氮量最大值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
            <td align="center" bgcolor="#FFFFFF">氨氮量最小值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
            <td align="center" bgcolor="#FFFFFF">氨氮量最大值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>

        <tr>
            <td align="center" bgcolor="#FFFFFF">总磷量最大值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
            <td align="center" bgcolor="#FFFFFF">总磷量最小值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
            <td align="center" bgcolor="#FFFFFF">总磷量最大值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
        </tr>
        <tr>
            <td align="center" bgcolor="#FFFFFF">总氮量最大值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
            <td align="center" bgcolor="#FFFFFF">总氮量最小值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
            <td align="center" bgcolor="#FFFFFF">总氮量最大值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
        </tr>
        <tr>
            <td align="center" bgcolor="#FFFFFF">铜量最大值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
            <td align="center" bgcolor="#FFFFFF">铜量最小值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
            <td align="center" bgcolor="#FFFFFF">铜量最大值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
        </tr>
        <tr>
            <td align="center" bgcolor="#FFFFFF">锌量最大值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
            <td align="center" bgcolor="#FFFFFF">锌量最小值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
            <td align="center" bgcolor="#FFFFFF">锌量最大值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
        </tr>
        <tr>
            <td align="center" bgcolor="#FFFFFF">汞量最大值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
            <td align="center" bgcolor="#FFFFFF">汞量最小值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
            <td align="center" bgcolor="#FFFFFF">汞量最大值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
        </tr>
        <tr>
            <td align="center" bgcolor="#FFFFFF">镉量最大值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
            <td align="center" bgcolor="#FFFFFF">镉量最小值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
            <td align="center" bgcolor="#FFFFFF">镉量最大值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
        </tr>
        <tr>
            <td align="center" bgcolor="#FFFFFF">六价铬量最大值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
            <td align="center" bgcolor="#FFFFFF">六价铬量最小值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
            <td align="center" bgcolor="#FFFFFF">六价铬量最大值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
        </tr>
        <tr>
            <td align="center" bgcolor="#FFFFFF">铅量最大值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
            <td align="center" bgcolor="#FFFFFF">铅量最小值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
            <td align="center" bgcolor="#FFFFFF">铅量最大值：</td>
            <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
        </tr>
    </table>
    <?php
}
?>

<!--3常年气温表-->
<?php
if(isset($_POST['select']) && $_POST['select']=="attable"){
?>
<table  width="700" border="1" cellpadding="1" cellspacing="1" bordercolor="#FFFFFF" bgcolor="#666666">
    <!--第二行-->
    <tr>
        <td  align="center" bgcolor="#FFFFFF">您的账号：</td>
        <td bgcolor="#FFFFFF"><?php echo $_SESSION['user']; ?></td>
        <td  bgcolor="#FFFFFF">您的IP地址：</td>
        <td bgcolor="#FFFFFF"><?php echo $_SERVER["REMOTE_ADDR"];?></td>
        <td  bgcolor="#FFFFFF">查询时间：</td>
        <td bgcolor="#FFFFFF"><?php date_default_timezone_set('Etc/GMT-8');     //这里设置了时区
            echo date("Y-m-d H:i:s");?></td>
    </tr>
    <tr>
        <td align="center" bgcolor="#FFFFFF">查询数据库名称：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
        <td align="center" bgcolor="#FFFFFF">查询数据条数：</td>
        <td bgcolor="#FFFFFF"><?php $sql="SELECT COUNT(*) AS count FROM TABLE ";
            $result=pg_fetch_assoc(pg_query($sql));
            $count=$result['count']; echo $count;?></td>

        <td bgcolor="#FFFFFF">年份数：</td>
        <td bgcolor="#FFFFFF"></td>
    </tr>
    <tr>
        <td align="center" bgcolor="#FFFFFF">暴雨日最大天数：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
        <td align="center" bgcolor="#FFFFFF">暴雨日最小天数：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
        <td align="center" bgcolor="#FFFFFF">暴雨日平均值天数：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
    </tr>

    <tr>
        <td align="center" bgcolor="#FFFFFF">年份最大值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
        <td align="center" bgcolor="#FFFFFF">年份最小值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
        <td align="center" bgcolor="#FFFFFF">平均流量最大值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
    </tr>
    <tr>
        <td align="center" bgcolor="#FFFFFF">1月气温最大值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
        <td align="center" bgcolor="#FFFFFF">1月气温最小值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
        <td align="center" bgcolor="#FFFFFF">1月气温平均值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
    </tr>
    <tr>
        <td align="center" bgcolor="#FFFFFF">2月气温最大值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
        <td align="center" bgcolor="#FFFFFF">2月气温最小值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
        <td align="center" bgcolor="#FFFFFF">2月气温平均值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
    </tr>
    <tr>
        <td align="center" bgcolor="#FFFFFF">3月气温最大值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
        <td align="center" bgcolor="#FFFFFF">3月气温最小值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
        <td align="center" bgcolor="#FFFFFF">3月气温平均值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
    </tr>
    <tr>
        <td align="center" bgcolor="#FFFFFF">4月气温最大值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
        <td align="center" bgcolor="#FFFFFF">4月气温最小值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
        <td align="center" bgcolor="#FFFFFF">4月气温平均值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
    </tr>
    <tr>
        <td align="center" bgcolor="#FFFFFF">5月气温最大值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
        <td align="center" bgcolor="#FFFFFF">5月气温最小值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
        <td align="center" bgcolor="#FFFFFF">5月气温平均值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
    </tr>
    <tr>
        <td align="center" bgcolor="#FFFFFF">6月气温最大值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
        <td align="center" bgcolor="#FFFFFF">6月气温最小值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
        <td align="center" bgcolor="#FFFFFF">6月气温平均值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
    </tr>
    <tr>
        <td align="center" bgcolor="#FFFFFF">7月气温最大值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
        <td align="center" bgcolor="#FFFFFF">7月气温最小值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
        <td align="center" bgcolor="#FFFFFF">7月气温平均值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
    </tr>
    <tr>
        <td align="center" bgcolor="#FFFFFF">8月气温最大值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
        <td align="center" bgcolor="#FFFFFF">8月气温最小值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
        <td align="center" bgcolor="#FFFFFF">8月气温平均值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
    </tr>
    <tr>
        <td align="center" bgcolor="#FFFFFF">9月气温最大值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
        <td align="center" bgcolor="#FFFFFF">9月气温最小值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
        <td align="center" bgcolor="#FFFFFF">9月气温平均值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
    </tr>
    <tr>
        <td align="center" bgcolor="#FFFFFF">10月气温最大值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
        <td align="center" bgcolor="#FFFFFF">10月气温最小值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
        <td align="center" bgcolor="#FFFFFF">10月气温平均值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
    </tr>
    <tr>
        <td align="center" bgcolor="#FFFFFF">11月气温最大值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
        <td align="center" bgcolor="#FFFFFF">11月气温最小值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
        <td align="center" bgcolor="#FFFFFF">11月气温平均值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
    </tr>
    <tr>
        <td align="center" bgcolor="#FFFFFF">12月气温最大值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
        <td align="center" bgcolor="#FFFFFF">12月气温最小值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
        <td align="center" bgcolor="#FFFFFF">12月气温平均值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
    </tr>
    <tr>
        <td align="center" bgcolor="#FFFFFF">年平均气温最大值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
        <td align="center" bgcolor="#FFFFFF">年平均气温最小值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
        <td align="center" bgcolor="#FFFFFF">年平均气温平均值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
    </tr>
    <tr>
        <td align="center" bgcolor="#FFFFFF">年最高气温最大值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
        <td align="center" bgcolor="#FFFFFF">年最高气温最小值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
        <td align="center" bgcolor="#FFFFFF">年最高气温平均值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
    </tr>
    <tr>
        <td align="center" bgcolor="#FFFFFF">年最低气温最大值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
        <td align="center" bgcolor="#FFFFFF">年最低气温最小值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
        <td align="center" bgcolor="#FFFFFF">年最低气温平均值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
    </tr>
    <tr>
        <td align="center" bgcolor="#FFFFFF">年蒸发量最大值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
        <td align="center" bgcolor="#FFFFFF">年蒸发量最小值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
        <td align="center" bgcolor="#FFFFFF">年蒸发量平均值：</td>
        <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
    </tr>

    <!--4人口出生死亡表-->
    <?php
    if(isset($_POST['select']) && $_POST['select']=="zxctable"){
        ?>
        <table  width="700" border="1" cellpadding="1" cellspacing="1" bordercolor="#FFFFFF" bgcolor="#666666">
            <!--第二行-->
            <tr>
                <td  align="center" bgcolor="#FFFFFF">您的账号：</td>
                <td bgcolor="#FFFFFF"><?php echo $_SESSION['user']; ?></td>
                <td  bgcolor="#FFFFFF">您的IP地址：</td>
                <td bgcolor="#FFFFFF"><?php echo $_SERVER["REMOTE_ADDR"];?></td>
                <td  bgcolor="#FFFFFF">查询时间：</td>
                <td bgcolor="#FFFFFF"><?php date_default_timezone_set('Etc/GMT-8');     //这里设置了时区
                    echo date("Y-m-d H:i:s");?></td>
            </tr>
            <tr>
                <td align="center" bgcolor="#FFFFFF">查询数据库名称：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
                <td align="center" bgcolor="#FFFFFF">查询数据条数：</td>
                <td bgcolor="#FFFFFF"><?php $sql="SELECT COUNT(*) AS count FROM TABLE ";
                    $result=pg_fetch_assoc(pg_query($sql));
                    $count=$result['count']; echo $count;?></td>

                <td bgcolor="#FFFFFF">年份数：</td>
                <td bgcolor="#FFFFFF"></td>
            </tr>
            <tr>
                <td align="center" bgcolor="#FFFFFF">年份值最大数：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
                <td align="center" bgcolor="#FFFFFF">年份值最小数：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
                <td align="center" bgcolor="#FFFFFF">年份值平均值数：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
            </tr>

            <tr>
                <td align="center" bgcolor="#FFFFFF">总户数最大值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
                <td align="center" bgcolor="#FFFFFF">总户数最小值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
                <td align="center" bgcolor="#FFFFFF">总户数值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
            </tr>
            <tr>
                <td align="center" bgcolor="#FFFFFF">1月气温最大值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
                <td align="center" bgcolor="#FFFFFF">1月气温最小值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
                <td align="center" bgcolor="#FFFFFF">1月气温平均值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
            </tr>
            <tr>
                <td align="center" bgcolor="#FFFFFF">2月气温最大值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
                <td align="center" bgcolor="#FFFFFF">2月气温最小值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
                <td align="center" bgcolor="#FFFFFF">2月气温平均值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
            </tr>
            <tr>
                <td align="center" bgcolor="#FFFFFF">3月气温最大值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
                <td align="center" bgcolor="#FFFFFF">3月气温最小值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
                <td align="center" bgcolor="#FFFFFF">3月气温平均值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
            </tr>
            <tr>
                <td align="center" bgcolor="#FFFFFF">4月气温最大值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
                <td align="center" bgcolor="#FFFFFF">4月气温最小值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
                <td align="center" bgcolor="#FFFFFF">4月气温平均值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
            </tr>
            <tr>
                <td align="center" bgcolor="#FFFFFF">5月气温最大值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
                <td align="center" bgcolor="#FFFFFF">5月气温最小值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
                <td align="center" bgcolor="#FFFFFF">5月气温平均值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
            </tr>
            <tr>
                <td align="center" bgcolor="#FFFFFF">6月气温最大值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
                <td align="center" bgcolor="#FFFFFF">6月气温最小值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
                <td align="center" bgcolor="#FFFFFF">6月气温平均值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
            </tr>
            <tr>
                <td align="center" bgcolor="#FFFFFF">7月气温最大值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
                <td align="center" bgcolor="#FFFFFF">7月气温最小值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
                <td align="center" bgcolor="#FFFFFF">7月气温平均值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
            </tr>
            <tr>
                <td align="center" bgcolor="#FFFFFF">8月气温最大值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
                <td align="center" bgcolor="#FFFFFF">8月气温最小值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
                <td align="center" bgcolor="#FFFFFF">8月气温平均值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
            </tr>
            <tr>
                <td align="center" bgcolor="#FFFFFF">9月气温最大值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
                <td align="center" bgcolor="#FFFFFF">9月气温最小值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
                <td align="center" bgcolor="#FFFFFF">9月气温平均值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
            </tr>
            <tr>
                <td align="center" bgcolor="#FFFFFF">10月气温最大值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
                <td align="center" bgcolor="#FFFFFF">10月气温最小值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
                <td align="center" bgcolor="#FFFFFF">10月气温平均值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
            </tr>
            <tr>
                <td align="center" bgcolor="#FFFFFF">11月气温最大值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
                <td align="center" bgcolor="#FFFFFF">11月气温最小值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
                <td align="center" bgcolor="#FFFFFF">11月气温平均值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
            </tr>
            <tr>
                <td align="center" bgcolor="#FFFFFF">12月气温最大值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
                <td align="center" bgcolor="#FFFFFF">12月气温最小值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
                <td align="center" bgcolor="#FFFFFF">12月气温平均值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
            </tr>
            <tr>
                <td align="center" bgcolor="#FFFFFF">年平均气温最大值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
                <td align="center" bgcolor="#FFFFFF">年平均气温最小值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
                <td align="center" bgcolor="#FFFFFF">年平均气温平均值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
            </tr>
            <tr>
                <td align="center" bgcolor="#FFFFFF">年最高气温最大值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
                <td align="center" bgcolor="#FFFFFF">年最高气温最小值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
                <td align="center" bgcolor="#FFFFFF">年最高气温平均值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
            </tr>
            <tr>
                <td align="center" bgcolor="#FFFFFF">年最低气温最大值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
                <td align="center" bgcolor="#FFFFFF">年最低气温最小值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
                <td align="center" bgcolor="#FFFFFF">年最低气温平均值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
            </tr>
            <tr>
                <td align="center" bgcolor="#FFFFFF">年蒸发量最大值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
                <td align="center" bgcolor="#FFFFFF">年蒸发量最小值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
                <td align="center" bgcolor="#FFFFFF">年蒸发量平均值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
            </tr>
        </table>
        <?php
    }
    ?>


    <?php
    if(isset($_POST['select']) && $_POST['select']=="1"){
        ?>

        <table  width="700" border="1" cellpadding="1" cellspacing="1" bordercolor="#FFFFFF" bgcolor="#666666">
            <!--第二行-->
            <tr>
                <td width="83" align="center" bgcolor="#FFFFFF">11111您的账号：</td>
                <td width="144" bgcolor="#FFFFFF"><?php echo $_SESSION['user']; ?></td>
                <td width="71" bgcolor="#FFFFFF">11111您的IP地址：</td>
                <td width="146" bgcolor="#FFFFFF"><?php echo $_SERVER["REMOTE_ADDR"];?></td>
                <td width="213" bgcolor="#FFFFFF">查询时间：</td>
                <td bgcolor="#FFFFFF"><?php date_default_timezone_set('Etc/GMT-8');     //这里设置了时区
                    echo date("Y-m-d H:i:s");?></td>
            </tr>
            <tr>
                <td align="center" bgcolor="#FFFFFF">查询数据库名称：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
                <td align="center" bgcolor="#FFFFFF">查询数据条数：</td>
                <td bgcolor="#FFFFFF"><?php $sql="SELECT COUNT(*) AS count FROM TABLE ";
                    $result=pg_fetch_assoc(pg_query($sql));
                    $count=$result['count']; echo $count;?></td>

                <td align="center" bgcolor="#FFFFFF">平均流量最小值：</td>
                <td bgcolor="#FFFFFF">
                    <?php
                    mysql_select_db("date");
                    $result=mysql_query("select max(id+0) max_id from music",$conn);
                    $field=mysql_fetch_row($result);
                    echo $field;
                    ?>
                </td>
            </tr>
            <tr>
                <td align="center" bgcolor="#FFFFFF">降雨量最大值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
                <td align="center" bgcolor="#FFFFFF">降雨量最小值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?>"</td>
                <td align="center" bgcolor="#FFFFFF">平均流量最大值：</td>
                <td bgcolor="#FFFFFF"><?php  echo $_POST['select'];?></td>
            </tr>
        </table>
        <?php
    }
    ?>

    <br/>
    <body>
</html>


