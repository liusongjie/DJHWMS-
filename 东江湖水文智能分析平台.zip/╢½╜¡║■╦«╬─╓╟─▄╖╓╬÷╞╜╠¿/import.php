<?php
header("Content-Type:text/html;charset=utf-8");
session_start();
//定义个常量，用来授权调用includes里面的文件
define('IN_TG',true);
//定义个常量，用来指定本页的内容
define('SCRIPT','import');
//引入公共文件
require dirname(__FILE__).'/includes/common.inc.php';

if(!empty($_SESSION['tableName'])) {
    $sql = <<<EOF
SELECT a.attname, a.attnotnull as notnull FROM pg_class as c,pg_attribute as a  where c.relname = '{$_SESSION['tableName']}' and a.attrelid = c.oid and a.attnum>1
EOF;
//echo $sql;
    $result = pg_query($sql);
    while ($row = pg_fetch_assoc($result)) {
        $fields[] = $row;
    }
    $allowUpLoad = 0;
    if ($_GET['action'] == 'inspect') {
        /* echo $_FILES['userfile']['name'];
         exit(1);*/
        if (empty($_SESSION['tableName'])) {
            _alert_back('请先选择数据库');
        }
        //判断后缀名
        $n = explode('.', strrev($_FILES['userfile']['name']));
        $suffix = strrev($n[0]);
        if ($suffix != $_POST['fileFormat']) {
            _alert_back('文件格式不正确，请重新选择文件');
        }else{
            //echo "<script type='text/javascript'>alert('文件合法，可以导入');</script>";
        }
        //echo $_FILES['userfile']['name'];
        $filePath = upload('userfile', $_SESSION['tableName'], $_COOKIE['username']);
      /*  echo $filePath;
                exit();*/
        require_once 'PHPExcel_1.8.0_doc/Classes/PHPExcel.php';

        //避免中文文件名，进行转码
        $filePath = iconv('utf-8', 'gb2312', $filePath);
        /*echo 3;
        exit();*/
        $PHPReader = new PHPExcel_Reader_Excel2007();
        /* echo $filePath;
         exit(122);*/
        if (!$PHPReader->canRead($filePath)) {
            $PHPReader = new PHPExcel_Reader_Excel5();

            if (!$PHPReader->canRead($filePath)) {

                _alert_back('no Excel');
            }
        }
        /*echo 1;
        exit();*/
        set_time_limit(0);//设置不超时
        @ini_set('memory_limit', '512M');//设置PHP能使用的内存大小
        $PHPExcel = $PHPReader->load($filePath);
        /*echo 1.5;
        exit();*/
        //读取excel文件中的第一个工作表
        $currentSheet = $PHPExcel->getSheet(0);
        /*echo 2;
        exit();*/
        //取得最大的列号
        $allColumn = $currentSheet->getHighestColumn();
        $highestColumnNum = PHPExcel_Cell::columnIndexFromString($allColumn);
        /*echo 3;
        exit();*/
        //从数据库中取出有多少字段
        $colFieldSQL = <<<EOF
select count(*) as colnum from information_schema.COLUMNS where table_name='{$_SESSION['tableName']}';
EOF;
        /*echo $colFieldSQL;
        exit();*/
        $colFromSqls = pg_fetch_assoc(pg_query($colFieldSQL));
        $colFromSql = intval($colFromSqls['colnum']);
       /*echo $highestColumnNum;
        echo $colFieldSQL;
        echo $colFromSql;
        exit();*/
        /* var_dump($colFromSqls);
         echo $highestColumnNum;
         echo $colFromSql;
         echo '<br/>';
         $encode = mb_detect_encoding($highestColumnNum, array("ASCII",'UTF-8','GB2312',"GBK"));
     echo $encode;*/
        if ($highestColumnNum != $colFromSql) {
            unlink($filePath);
            _alert_back('上传文件内容不符合要求,已被删除,请重新选择文件');
        }else{
            _alert_info('导入文件合法,可以开始导入');
        }

        $_SESSION['importPath'] = $filePath;
        $allowUpLoad = 1;
    }



    if ($_GET['action'] == 'import') {
        /*echo $_SESSION['importPath'];
        exit(1);*/
        require_once("http://localhost:8080/JavaBridgeTemplate611/java/Java.inc");


        switch ($_SESSION['tableName']) {
            case 'zxctable':
                $import = new Java("ImportZXCxlsToDB");
                $value = $import->exe($_SESSION['importPath']);
                //$value=$batchImport->exe();
                $info = java_values($value);
                //echo $info;
                break;
            case 'rpcitable':
                $import = new Java("ImportRPCIxlsToDB");
                $value = $import->exe($_SESSION['importPath']);
                $info = java_values($value);
                // echo $info;
                break;
            case 'hydraulictable':
                $import = new Java("ImportHDxlsToDB");
                $value = $import->exe($_SESSION['importPath']);
                $info = java_values($value);
                break;
            case 'attable':
                $import = new Java("ImportATxlsToDB");
                $value = $import->exe($_SESSION['importPath']);
                $info = java_values($value);
                break;
            case 'wqmtable':
                $import = new Java("ImportWQMxlsToDB");
                $value = $import->exe($_SESSION['importPath']);
                $info = java_values($value);
                break;
            case 'ftable':
                $import = new Java("ImportFxlsToDB");
                $value = $import->exe($_SESSION['importPath']);
                $info = java_values($value);
                break;
            case 'imtable':
                $import = new Java("ImportIMxlsToDB");
                $value = $import->exe($_SESSION['importPath']);
                $info = java_values($value);
                break;
            case 'lstable':
                $import = new Java("ImportlSxlsToDB");
                $value = $import->exe($_SESSION['importPath']);
                $info = java_values($value);
                break;
            case 'wltable':
                $import = new Java("ImportWLxlsToDB");
                $value = $import->exe($_SESSION['importPath']);
                $info = java_values($value);
                break;
            case 'metable':
                $import = new Java("ImportMExlsToDB");
                $value = $import->exe($_SESSION['importPath']);
                $info = java_values($value);
                break;
            case 'runofftable':
                $import = new Java("ImportROxlsToDB");
                $value = $import->exe($_SESSION['importPath']);
                $info = java_values($value);
                break;
            case 'fwtable':
                $import = new Java("ImportFWxlsToDB");
                $value = $import->exe($_SESSION['importPath']);
                $info = java_values($value);
                break;
            default:
                break;
        }

        //$_SESSION['importPath'] = NULL;
        //unlink($filePath);
       // echo "<script type='text/javascript'>alert('$info');</script>";

        //从用户库中提取信息
        $userInfoSql = <<<EOF
SELECT lasttime,lastip FROM djhuser WHERE username='{$_COOKIE['username']}'
EOF;
        $infos = pg_fetch_assoc(pg_query($userInfoSql));
        //插入数据库
        $upLogSql = <<<EOF
INSERT INTO log (username,tablename,operation,operatetime,content,ip,logintime) VALUES('{$_COOKIE['username']}','{$_SESSION['tableName']}','{$scToCh[SCRIPT]}',NOW(),'{$_SESSION['importPath']}','{$infos['lastip']}','{$infos['lasttime']}')
EOF;
        //echo $upLogSql;
        pg_query($upLogSql);

        $allowUpLoad = 0;
        $_SESSION['importPath'] = NULL;
        //exit();
        _location('导入成功','import.php');
    }
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

  <title><?php echo '湖南省郴州东江湖水资源管理'?></title>
  <link rel="shortcut icon" href="dongjianghu.ico" />
  <script type="text/javascript" src="js/jquery-3.1.0.min.js"></script>
  <link rel="stylesheet" type="text/css" href="js/jQuery-jcDate-master/src/jcDate.css" media="all" />
  <script type="text/javascript" src="js/jQuery-jcDate-master/src/jQuery-jcDate.js" charset="utf-8"></script>
  <script type="text/javascript" src="js/baseManage.inc1.js"></script>
  <link rel="stylesheet" type="text/css" href="templateCss.css"/>
<style type="text/css">
/*#header {
	height: 80px;
	z-index: 1;
	background-image: url(images/top1.png);
	background-repeat: repeat;
	line-height: 80px;
	vertical-align: middle;
	visibility: visible;
}*/

#mainUp #operateTitle {
	height: 30px;
	border-bottom-width: 2px;
	border-bottom-style: none;
	border-bottom-color: #399;
	vertical-align: middle;
	text-align: center;
}
h2 {
	color: #39C;
	font-weight: bold;
}
h2 {
	color: #36C;
}
.title2 {
	font-size: 18px;
}
.title2 {
	font-weight: bold;
}
#selectDB form table tr {
	height: 20px;
}
#mainUp form ul {
	list-style-type: none;
	height:120px;
	width:95%;
	overflow:auto;
}
#mainUp form ul li{

	display:inline-block;
	width:620px;
	height:35px;
}
#mainUp form ul li span.searchInfo{
	display:inline-block;
	/*border:red solid 1px;*/
	width:350px;
}
#mainUp form ul li span.searchInput{
	width:180px;
}
#mainUp form ul input.searchInput{
	width:60px;
	}

#mainUp form ul.displaySelect{

	height:110px;
	overflow-y:auto;
	overflow-x:hidden;
}
#mainUp form ul li.displaySelect{

	display:inline-block;
	width:170px;
	height:35px;
}
#mainUp form ul li.displayBatch{

	display:block;
	text-align:center;
	height:35px;
}
#mainUp form ul.submit{
	text-align:center;
	height:35px;
}
#mainUp form ul.methodSelect{
	height:35px;
	}
#mainUp form ul li.methodSelect{

	display:inline-block;
	width:300px;
	height:35px;
}
</style>

</head>

<body bgcolor="#cfd4ff">


<?php require_once("includes/header.inc.php");  ?>
<div class="bodyContent">
<?php
require_once("includes/dbSelect.inc.php");
?>
<?php if($_SESSION['mainUpFlag']==1){?>
<div id="mainUp">
  <h2 id="operateTitle"><strong><?php echo $_SESSION['tableCh']?>数据库导入操作</strong></h2>

  <form enctype="multipart/form-data" method="post" id="importForm" action="?action=inspect">
    <input type="hidden" name="action" value="inspect"/>
    <span  class="title2">导入文件格式:</span>
    <ul class="methodSelect" id="formatSelect">
      <li class="methodSelect"><input class="methodSelect" type="radio" name="fileFormat" checked="checked" id="fileFormat"   value="xls"  />
        <label for="fileFormat">excel表(.xls)</label></li>
      <li class="methodSelect"><input class="methodSelect" type="radio" name="fileFormat" id="fileFormat"   value="sql" disabled="disabled"/>
        <label for="fileFormat">sql</label></li>
     <!-- <li class="methodSelect"><input class="methodSelect" type="radio" name="fileFormat" id="fileFormat"   value="mysql" />
        <label for="fileFormat">mysql</label></li>
      <li class="methodSelect"><input class="methodSelect" type="radio" name="fileFormat" id="fileFormat"   value="sqlServer"/>
        <label for="exportMethod">sqlServer</label></li>-->
    </ul>


    <span  class="title2"> 导入文件选择:</span>
    <ul class="methodSelect">
      <li>
        <style type="text/css">
          .a-upload {
            padding: 4px 10px;
            height: 20px;
            line-height: 20px;
            position: relative;
            cursor: pointer;
            color: #888;
            background: #dfc1fa;
            border: 1px solid #ddd;
            border-radius: 4px;
            overflow: hidden;
            display: inline-block;
            *display: inline;
            *zoom: 1
          }

          .a-upload  input {
            position: absolute;
            font-size: 100px;
            right: 0;
            top: 0;
            opacity: 0;
            filter: alpha(opacity=0);
            cursor: pointer
          }

          .a-upload:hover {
            color: #444;
            background: #eee;
            border-color: #ccc;
            text-decoration: none
          }
          .showFileName {
              display:inline-block;
              padding: 4px 10px;
              height: 20px;
              line-height: 20px
          }
        </style>

        <a href="javascript:;" class="a-upload" id="aUpload">
          <input type="file" name="userfile" id="userfile">点击这里上传文件

        </a>

          <span class="showFileName" id="upFileName"></span><span class="fileerrorTip"></span>
          <script type="text/javascript">
              $(".a-upload").on("change","input[type='file']",function(){
                 // alert(1);
                  var filePath=$(this).val();
                 // alert(filePath);
                //  $(".fileerrorTip").html("您未上传文件，或者您上传文件类型有误！");
                  $(".fileerrorTip").html("").hide();
                  var arr=filePath.split('\\');
                  var fileName=arr[arr.length-1];
                  $(".showFileName").html(fileName);
                /*  if(filePath.indexOf("jpg")!=-1 || filePath.indexOf("png")!=-1){
                      $(".fileerrorTip").html("").hide();
                      var arr=filePath.split('\\');
                      var fileName=arr[arr.length-1];
                      $(".showFileName").html(fileName);
                  }else{
                      $(".showFileName").html("");
                      $(".fileerrorTip").html("您未上传文件，或者您上传文件类型有误！").show();
                      return false
                  }*/
              })

          </script>
    </li>
    </ul>


   <span  class="title2">导入文件合法性检查:</span>
    <ul class="submit">
      <li class="methodSelect"><input class="methodSelect" type="submit" name="inspect" id="inspect"  value="检查"  />
        </li>
    </ul>
</form>

<?php if($allowUpLoad==1){?>
<form method="get" action="?" >
   <span  class="title2">导入文件:</span>
    <ul class="submit">
      <li>

        <input type="submit" value="开始导入">
          <input type="hidden" name="action" value="import">
      </li>
    </ul>

  </form>
</div>
<?php }?>
<?php }
if($_SESSION['mainUpFlag']!=1){
    echo '<div id="placeHolder" style="height:400px;"></div>';
}
?>
</div>
<?php require_once('includes/footer.inc.php');?>

<script type="text/javascript" src="js/<?php echo SCRIPT?>.js"></script>

</body>
</html>
