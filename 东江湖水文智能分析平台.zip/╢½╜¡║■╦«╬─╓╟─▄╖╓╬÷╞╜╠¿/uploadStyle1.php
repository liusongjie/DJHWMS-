<?php
/**
 * Created by PhpStorm.
 * User: hetong
 * Date: 2016/9/29
 * Time: 17:35
 *
 */
?>
<style type="text/css">
.a-upload {
padding: 4px 10px;
height: 20px;
line-height: 20px;
position: relative;
cursor: pointer;
color: #888;
background: #fafafa;
border: 1px solid #ddd;
border-radius: 4px;
overflow: hidden;
display: inline-block;
*display: inline;
*zoom: 1
}

.a-upload input {
position: absolute;
font-size: 100px;
right: 0;
top: 0;
opacity: 0;
filter: alpha(opacity=0);
cursor: pointer
}

.a-upload:hover {
color: #444;
background: #eee;
border-color: #ccc;
text-decoration: none;
}
</style>
<a href="javascript:;" class="a-upload">
    <input type="file" name="" id="">点击这里上传文件
</a>
