﻿<?php
/**
 * Created by PhpStorm.
 * User: hetong
 * Date: 2016/9/29
 * Time: 13:08
 */
header("Content-Type:text/html;charset=utf-8");
session_start();
//定义个常量，用来授权调用includes里面的文件
define('IN_TG',true);
//定义个常量，用来指定本页的内容
define('SCRIPT','search');
//引入公共文件
require dirname(__FILE__).'/includes/common.inc.php';
require dirname(__FILE__).'/includes/check.func.php';
if ($_GET['action']=='modifyInfo'){
  if(!empty($_POST['mobile'])){
    $_clean['mobile'] =_check_mobile($_POST['mobile']);
  }

  $_clean['email'] = _check_email($_POST['email'],6,40);
  $_clean['password']=_check_password($_POST['password'],$_POST['checkPassword'],6);
  $upSqlInfo=<<<EOF
UPDATE djhuser SET password='{$_clean['password']}',email='{$_clean['email']}',mobile='{$_clean['mobile']}'
WHERE username='{$_COOKIE['username']}'
EOF;
  //echo $upSqlInfo;

  $upResult=pg_query($upSqlInfo);
//echo pg_affected_rows($upResult);
  if(pg_affected_rows($upResult)==1){
    //echo "<script type='text/javascript'>alert('修改成功');</script>";

    _confirm('修改成功，是否转到首页?','index.php');
  }else{
    _alert_back('修改失败，请重新输入');
  }


}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

  <title><?php echo '湖南省郴州东江湖水资源管理'?></title>
<link rel="shortcut icon" href="dongjianghu.ico" />
<script type="text/javascript" src="js/jquery-3.1.0.min.js"></script>
<link rel="stylesheet" type="text/css" href="js/jQuery-jcDate-master/src/jcDate.css" media="all" />
<script type="text/javascript" src="js/jQuery-jcDate-master/src/jQuery-jcDate.js" charset="utf-8"></script>
<script type="text/javascript" src="js/baseManage.inc1.js"></script>
<link rel="stylesheet" type="text/css" href="templateCss.css"/>
  <style type="text/css">
    #register {
      width: 96%;
      height: auto;
      z-index: 1;
      margin-top: 15px;
      margin-right: 15px;
      margin-bottom: 10px;
      margin-left: 15px;
      background-color: #FFF;
      border-radius: 8px;
      font-size: 18px;
      text-algin: center;
      padding: 10px;
      overflow: auto;
    }
    #selectDB h2 strong {
      font-weight: bold;
      color: #36C;
    }

    #register #operateTitle {
      height: 30px;
      border-bottom-width: 2px;
      border-bottom-style: none;
      border-bottom-color: #399;
      vertical-align: middle;
      text-align: center;
    }
    h2 {
      color: #39C;
      font-weight: bold;
      text-align:center;
    }
    h2 {
      color: #36C;
      font-size: 24px;
    }
    .title2 {
      font-size: 18px;
    }
    .title2 {
      font-weight: bold;
      font-size: 22px;
      color: #000;
    }
   /* #selectDB form table tr {
      height: 20px;
    }
    #register form ul {
      list-style-type: none;
      height:120px;
      width:98%;
      overflow:auto;
    }
    #register form ul li{

      display:inline-block;
      width:620px;
      height:35px;
    }
    #register form ul li span.searchInfo{
      display:inline-block;
      !*border:red solid 1px;*!
      width:350px;
    }
    #register form ul li span.searchInput{
      width:180px;
    }
    #register form ul input.searchInput{
      width:80px;
    }

    #register form ul.displaySelect{

      height:auto;
      max-height:110px;
      width:95%;
      overflow:auto;
    }
    #register form ul li.displaySelect{

      display:inline-block;
      width:180px;
      height:35px;
    }
    #register form ul li.displayBatch{

      display:block;
      text-align:center;
      width:90%;
      height:35px;
    }
    #register form ul.submit{
      text-align:center;
      width:95%;
      height:auto;
    }*/
    p .title2 {
      font-size: 20px;
    }
    #register #manageMain p {
      text-align: center;

    }
    #manageMain{
      width: 99%;
      overflow: auto;
    }
    #register {
      height:600px;
      border:2px solid #ccc;
      font-size:12px;
    }
    #register h2 {
      text-indent:0;
      text-align:center;
    }
    #register dl {
      width:500px;
      margin:0 auto;
    }
    #register dl dt {
      text-align:center;
      padding:10px 0;
      font-weight:bold;
    }
    #register dl dd {
	padding: 5px 0;
	/*color: #660;*/
    }
    #register dl dd.face {
      padding:5px 0 5px 120px;
    }
    #register dl dd.face img {
      cursor:pointer;
    }
    #register dl dd input.text {
      width:220px;
      height:19px;
      border:1px solid #333;
      background:#fff;
    }
    #register dl dd input.yzm {
      width:60px;
    }
    #register dl dd input.submit {
      width:80px;
     /* height:19px;*/
      cursor:pointer;
      margin:0 0 0 120px;
    }
    #register dl dd img#code {
      position:relative;
      top:8px;
      cursor:pointer;
    }
    #register dl dd select{
      width:170px;
    }#register dl dd select option{
       width:170px;
     }
    #register dl dd span.necessary{
     color:red;
    }

  </style>

</head>

<body bgcolor="#cfd4ff">

<?php
require_once("includes/header.inc.php");
?>
<div class="bodyContent">
<div id="register">
  <h2>修改个人资料</h2>
  <?php if (!empty($_system['register'])) {?>
    <form enctype="multipart/form-data" method="post" name="register" action="?action=modifyInfo">
      <input type="hidden" name="uniqid" value="<?php //echo $_uniqid ?>" />
      <dl>
        <dt>请认真填写每项内容</dt>
<?php

$infoSql=<<<EOF
SELECT * FROM djhuser WHERE username='{$_COOKIE['username']}'
EOF;
$infos=pg_fetch_assoc(pg_query($infoSql));


?>
        <dd>重设密码：<input type="password" name="password" class="text" /> <span class="necessary">(*必填,至少六位)</span></dd>
        <dd>确认密码：<input type="password" name="checkPassword" class="text" /> (<span class="necessary">*必填</span>)</dd>
        <dd>电子邮件：<input type="text" name="email" class="text" value="<?php echo $infos['email']?>"/> (<span class="necessary">*必填</span>)</dd>
        <dd>手机号码：<input type="text" name="mobile" class="text" value="<?php echo $infos['mobile']?>"/> (可选)</dd>
        <input type="hidden" name="MAX_FILE_SIZE" value="1000000" />

        <dd><input type="submit" class="submit"  value="保存修改" /></dd>
      </dl>
    </form>
  <?php } else {
    echo '<h4 style="text-align:center;padding:20px;">本站关闭了注册功能！</h4>';
  }?>
</div>
  </div>
<?php require_once('includes/footer.inc.php');?>
<script type="text/javascript" src="js/<?php echo SCRIPT?>.js"></script>
</body>
</html>
