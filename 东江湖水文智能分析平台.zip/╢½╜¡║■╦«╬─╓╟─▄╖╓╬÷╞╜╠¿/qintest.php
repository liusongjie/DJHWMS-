<?php
header("Content-Type:text/html;charset=utf-8");
session_start();
//定义个常量，用来授权调用includes里面的文件
define('IN_TG',true);
//定义个常量，用来指定本页的内容
define('SCRIPT','intelAnalyze');
//引入公共文件
require dirname(__FILE__).'/includes/common.inc.php';

//目前只有环保数据库能用
if(!empty($_SESSION['tableName'])){
    if($_SESSION['tableName']!='wqmtable'){
      /*  $_SESSION['tableName']='';
        $_SESSION['tableCh']='';*/
        $_SESSION['tableName']=NULL;
        $_SESSION['tableCh']=NULL;
        _alert_back('此数据库暂未开通智能分析功能');

    }



$sql=<<<EOF
SELECT a.attname, a.attnotnull as notnull FROM pg_class as c,pg_attribute as a  where c.relname = '{$_SESSION['tableName']}' and a.attrelid = c.oid and a.attnum>1
EOF;
//echo $sql;
$result=pg_query($sql);
while($row=pg_fetch_assoc($result)){
    $fields[]=$row;
}

//设置访问界面，因为跨界面，所以用全局变量，session较熟悉,而cookie要重定位


$placeToCh=array('bailang'=>'白廊','chukou'=>'滁口','dongping'=>'东坪');
if($_GET['action']=='intelAnalyze'){

    if ($_GET['intelPlace']=='--地点--' || $_GET['intelTime']=='--时间--'){
        _alert_back('请选择时间和地点');
    }
    $imgUrl='www/'.$_GET['intelPlace'].$_GET['intelTime'].'0.jpg';
}

}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

    <?php require_once('includes/title.inc.php')?>
    <link rel="shortcut icon" href="dongjianghu.ico" />
    <script type="text/javascript" src="js/jquery-3.1.0.min.js"></script>
    <link rel="stylesheet" type="text/css" href="js/jQuery-jcDate-master/src/jcDate.css" media="all" />
    <script type="text/javascript" src="js/jQuery-jcDate-master/src/jQuery-jcDate.js" charset="utf-8"></script>
    <script type="text/javascript" src="js/baseManage.inc1.js"></script>
    <link rel="stylesheet" type="text/css" href="templateCss.css"/>
    <style type="text/css">

        #mainUp  ul {
            list-style-type: none;
            height:120px;
            width:1300px;
            overflow:auto;
        }
        #mainUp  ul li{

            display:inline-block;
            width:620px;
            height:35px;
        }
        #mainUp  ul li span.searchInfo{
            display:inline-block;
            /*border:red solid 1px;*/
            width:350px;
        }
        #mainUp  ul li span.searchInput{
            width:180px;
        }
        #mainUp  ul input.searchInput{
            width:60px;
        }

        #mainUp  ul.displaySelect{

            height:110px;
            width:1300px;
            overflow-y:auto;
            overflow-x:hidden;
        }
        #mainUp  ul li.displaySelect{

            display:inline-block;
            width:170px;
            height:35px;
        }
        #mainUp  ul li.displayBatch{

            display:block;
            text-align:center;
            width:1300px;
            height:35px;
        }
        #mainUp  ul.submit{
            text-align:center;
            width:1300px;
            height:35px;
        }
        #mainUp  ul.methodSelect{
            height:35px;
        }
        #mainUp  ul li.methodSelect{

            display:inline-block;
            width:320px;
            height:35px;
        }
        #apDiv1 {
            position: absolute;
            left: 1074px;
            top: 381px;
            width: 157px;
            height: 42px;
            z-index: 3;
        }
    </style>

</head>

<body bgcolor="#cfd4ff">

<?php
require_once("includes/header.inc.php");
?>
<div width="100%" height="100%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<img src="images/analyze2.jpg" width="500px" height="400px"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<img src="images/analyze1.jpg" width="500px" height="400px"/><br/>
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;未处理数据结果&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;处理数据结果

		
		
</div>


<?php require_once('includes/footer.inc.php');?>

<script type="text/javascript" src="js/<?php echo SCRIPT?>.js"></script>

</body>
</html>
