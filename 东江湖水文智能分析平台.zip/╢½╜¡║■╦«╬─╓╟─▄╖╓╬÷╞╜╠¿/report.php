<?php
header("Content-Type:text/html;charset=utf-8");
session_start();
//定义个常量，用来授权调用includes里面的文件
define('IN_TG',true);
//定义个常量，用来指定本页的内容
define('SCRIPT','report');
//引入公共文件
require dirname(__FILE__).'/includes/common.inc.php';

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

    <?php require_once('includes/title.inc.php')?>
    <script type="text/javascript" src="js/jquery-3.1.0.min.js"></script>
    <link rel="stylesheet" type="text/css" href="js/jQuery-jcDate-master/src/jcDate.css" media="all" />
    <script type="text/javascript" src="js/jQuery-jcDate-master/src/jQuery-jcDate.js" charset="utf-8"></script>
    <script type="text/javascript" src="js/baseManage.inc1.js"></script>
    <link rel="stylesheet" type="text/css" href="templateCss.css"/>



</head>

<body bgcolor="#cfd4ff">

<?php
require_once("includes/header.inc.php");

?>

<div class="bodyContent">
    <div id="selectDB">
        <h2><p>选择数据库</p>
        </h2>

        <ul>
            <?php
            //提取数据库
            $keys=array_keys($dbInDp);
            $strKeys=implode(',',$keys);
            $DBSql=<<<EOF
SELECT   {$strKeys} from djhuser   WHERE username='{$_COOKIE['username']}'
EOF;
            //echo $DBSql;
            $dep=pg_fetch_assoc(pg_query($DBSql));

            //$dep:部门=》权限数组
            foreach($dep as $key=>$value){
                if ($value>=1){
                    $imgPath='images/department3/'.$key.'.jpg';

                    /*echo '<li><span class="department" style='.'background: url("<?php echo $images;?>") no-repeat left;'.' >'.departmentCH($key).':</span>';*/
                    echo '<li>';
                    ?>

                    <p class="department" style="background: url('<?php echo $imgPath;?>') no-repeat left;background-size:contain;">
                        <?php echo departmentCH($key);?>
                    </p>
                    <?php
                    //$dbInDp:部门=》数据库数组的数组  $dbInDp[$key]:$key部门=》数据库数组
                    foreach ($dbInDp[$key] as $dbCh=>$db){
                        echo '<p class="table"><a href="print.php?tableCh='.$dbCh.'">'.$dbCh.'</a></p>';
                    }

                    echo '</li>';
                }
            }?>
        </ul>
    </div>


</div>
<?php require_once('includes/footer.inc.php');?>
<script type="text/javascript" src="js/<?php echo SCRIPT?>.js"></script>
</body>
</html>

