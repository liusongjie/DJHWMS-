<?php
header("Content-Type:text/html;charset=utf-8");
header("Cache-Control:no-cache");
$n=explode('.',strrev($_POST['upFileName']));
$suffix=strrev($n[0]);
/*file_put_contents('inspect.txt',$_POST['upFileName'],FILE_APPEND);
file_put_contents('inspect.txt',$suffix,FILE_APPEND);*/
if($_POST['fileFormat']==$suffix){
    echo 1;
}else{
    echo 0;
}
$map='';
if ($_POST['intelPlace']=='白廊'){
    $map="{place:[2008,2009,2010]}";
    $map2="[2008,2009,2010]";
    $map1=array(2008,2009,2010);
}elseif($_POST['intelPlace']=='东坪'){
    $map="{'place':[2008,2009,2010,2011,2012,2013]}";
    $map1=array(2008,2009,2010,2011,2012,2013);
    $map2="[2008,2009,2010,2011,2012,2013]";
}elseif($_POST['intelPlace']=='滁口'){
    $map="{'place':[2008,2009,2010,2011,2012,2013]}";
    $map1=array(2008,2009,2010,2011,2012,2013);
    $map2="[2008,2009,2010,2011,2012,2013]";
}

/*file_put_contents('place.json',$_POST['intelPlace'],FILE_APPEND);
file_put_contents('place.json',$map);
file_put_contents('place1.json',$en);*/
$en=json_encode($map1);
//echo $en;
/*echo $en;*/

?>