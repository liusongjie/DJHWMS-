<?php

header("Content-Type:text/html;charset=utf-8");
session_start();
require_once ('includes/global.func.php');
download($_SESSION['fileName'],$_SESSION['filePath']);
_location('','exp')
/*function downfile($fileurl)
{
    $filename=$fileurl;
    $date=date("Ymd-H:i:m");
    header( "Content-type:  application/octet-stream ");
    header( "Accept-Ranges:  bytes ");
    header( "Content-Disposition:  attachment;  filename= {$date}.xls");
    $size=readfile($filename);
    header( "Accept-Length: " .$size);
}
//$url="C:\\software\\httpd-2.4.23-x64\\Apache\\htdocs\\export\\hetong_hydraulictable1476703464.xls";
downfile($_SESSION['filePath']);*/
?>
