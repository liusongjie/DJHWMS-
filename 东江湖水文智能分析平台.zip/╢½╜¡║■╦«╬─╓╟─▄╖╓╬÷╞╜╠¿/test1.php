<?php

if ($_conn = @pg_connect("host=localhost port=5432 dbname=postgres user=postgres password=123456")) {
    echo 'success';
}else{
    echo('数据库连接失败');
}


/*$tmpFile=iconv("utf-8","gbk",$tmpFile); //$tmpFile为文件名，此处为处理中文乱码
$data=file_get_contents(UPLOAD_FILE_PATH.$tmpFile);//文献的完整路径*/
if($data=file_get_contents("./filetest.txt")){
    echo 'success1';
}

$escaped=pg_escape_bytea($data); //关键处
$insertSQL=<<<EOF
insert into tbfile (id , file) values(1 , '{$escaped}');
EOF;
$result3=pg_query($_conn,$insertSQL); //执行插入语句命令

function readBlob()
{
$dbconn=CreatePGConnect(); //数据库连接
$insertSQL=<<<EOF
select file from tbfile where id=1
EOF;
;//查询语句
$query=pg_query($_conn,$insertSQL);
$row=pg_fetch_result($query,'filecontent');

$filecontent=pg_unescape_bytea($row); //获得二进制数据
file_put_contents('./filetest1.txt',$filecontent); //将二进制数据转为PDF文件
return "OK";
}

$insertSQL=<<<EOF
select file from tbfile where id=1
EOF;
//查询语句
$query=pg_query($_conn,$insertSQL);
$row=pg_fetch_result($query,'filecontent');

$filecontent=pg_unescape_bytea($row); //获得二进制数据
file_put_contents('./filetest1.txt',$filecontent);

?>