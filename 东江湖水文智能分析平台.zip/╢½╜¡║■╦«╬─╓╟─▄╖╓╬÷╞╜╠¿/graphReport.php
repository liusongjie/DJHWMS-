
<?php
header("Content-Type:text/html;charset=utf-8");
session_start();
//定义个常量，用来授权调用includes里面的文件
define('IN_TG',true);
//定义个常量，用来指定本页的内容
define('SCRIPT','report');
//引入公共文件
require dirname(__FILE__).'/includes/common.inc.php';
_manage_login();

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

    <?php require_once('includes/title.inc.php')?>
    <script type="text/javascript" src="js/jquery-3.1.0.min.js"></script>
    <link rel="stylesheet" type="text/css" href="js/jQuery-jcDate-master/src/jcDate.css" media="all" />
    <script type="text/javascript" src="js/jQuery-jcDate-master/src/jQuery-jcDate.js" charset="utf-8"></script>
    <script type="text/javascript" src="js/baseManage.inc1.js"></script>
    <link rel="stylesheet" type="text/css" href="templateCss.css"/>



</head>

<body bgcolor="#cfd4ff">

<?php
require_once("includes/header.inc.php");

?>

<div class="bodyContent">
    <div id="selectDB">
        <h2><p>选择报表内容</p>
        </h2>
        <form name="form1" method="post" action="graph/graphprocess.php">

        <ul>

            <form name="form1" method="post" action="graphprocess.php">
                <table  width="800" border="1" cellpadding="1" cellspacing="1" bordercolor="#FFFFFF" bgcolor="green">
                    <tr><td  bgcolor="#FFFFFF">请选择您需要查询的显示的功能：</td>
                        <td  bgcolor="#FFFFFF"><select name="select1" title="1" id="select1">
                                <option name="1" value="datanum" selected>数据库数据分布</option>
                                <option name="2"  value="usernum" >系统注册用户数分布</option>
                                <option name ="3" value="hydraulictable" >水文分析</option>
                                <option value="attable">气象分析</option>
                                <!--<option value="wltable">水位分析</option>-->
                                <!--第一个div表格<option value="attable">气象分析</option>
                                <option value="zxctable">人力分析</option>
                                <option value="rpcitable">农业分析</option>
                                <option value="ftable">财政分析</option>
                                <option value="imtable">移民分析</option>
                                <option value="wltable">水位分析</option>
                                <option value="lstable">畜牧</option>
                                <option value="fwtable">测流堰数据</option>
                                <option value="runofftable">径数据</option>
                                <option value="metable">气象站数据</option>
                                <option name="11" value="test1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>-->
                            </select>
                        </td>
                        <td rowspan="2"align="center" bgcolor="#FFFFFF"><input type="submit" value="确认提交" >      &nbsp;&nbsp;
                            <input type="reset" value="刷新重置" >    &nbsp;&nbsp;</td>
                    </tr>
                    <tr bgcolor="#FFFFFF"><td >请选择数据分析类型：</td>
                        <td ><select name="select2"title="2" id="select2">
                                <option name="zzt"value="zzt">柱状图分析</option>
                                <option name="bzt" value="bzt">饼状图分析</option>
                                <option name="zxt" value="zxt">折线图分析</option>
                                <!--<option name="qxt"value="qxt">曲线图分析</option>-->
                            </select></td></tr>

                </table>
            </form>
            <li>

            </li>
            <li>

            </li>
        </ul>
    </form>
    </div>


</div>
<?php require_once('includes/footer.inc.php');?>
<script type="text/javascript" src="js/<?php echo SCRIPT?>.js"></script>
</body>
</html>

