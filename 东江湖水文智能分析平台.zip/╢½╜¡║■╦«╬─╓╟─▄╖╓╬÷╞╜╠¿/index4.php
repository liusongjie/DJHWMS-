<?php
header("Content-Type:text/html;charset=utf-8");
session_start();
//定义个常量，用来授权调用includes里面的文件
define('IN_TG',true);
//定义个常量，用来指定本页的内容
define('SCRIPT','searchNew2');
//引入公共文件
require dirname(__FILE__).'/includes/common.inc.php';

if($_GET['dataBase']=='shuiwenxinxi'){
  // 得到所有字段名
  /*$sql=<<<EOF
      SHOW FULL COLUMNS FROM HYDRAULICTABLE;
      EOF;*/
  //setcookie('tableName','hydraulictable');
  $_SESSION['tableName']='hydraulictable';


  /*$ziduanDis=pg_fetch_assoc($result);
  print_r($ziduanDis);*/
}elseif($_GET['dataBase']=='qixiangxinxi'){
  $_SESSION['tableName']='attable';
}elseif($_GET['dataBase']=='tongjixinxi'){
    $_SESSION['tableName']='zxctable';
}
$sql=<<<EOF
SELECT a.attname, a.attnotnull as notnull FROM pg_class as c,pg_attribute as a  where c.relname = '{$_SESSION['tableName']}' and a.attrelid = c.oid and a.attnum>1
EOF;
//echo $sql;
$result=pg_query($sql);
while($row=pg_fetch_assoc($result)){
  $fields[]=$row;
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

  <title><?php echo '湖南省郴州东江湖水资源管理'?></title>
  <link rel="shortcut icon" href="dongjianghu.ico" />
  <script type="text/javascript" src="js/jquery-3.1.0.min.js"></script>
  <link rel="stylesheet" type="text/css" href="js/jQuery-jcDate-master/src/jcDate.css" media="all" />
  <script type="text/javascript" src="js/jQuery-jcDate-master/src/jQuery-jcDate.js" charset="utf-8"></script>
  <script type="text/javascript" src="js/baseManage.inc1.js"></script>
<script type="text/javascript" src="js/<?php echo SCRIPT?>.js"></script>
<style type="text/css">
/*#header {
	height: 80px;
	z-index: 1;
	background-image: url(images/top1.png);
	background-repeat: repeat;
	line-height: 80px;
	vertical-align: middle;
	visibility: visible;
}*/
body {
  width:1420px;
  margin:0 auto;
  background-color: #cfd4ff;
  font-size:20px;
}

ul {
  list-style-type:none;
}
h2 {
  font-size:14px;
  background:#eee;
  height:25px;
  line-height:25px;
  text-indent:10px;
}
img.mark{
  display:inline;
  width:16px;
}
#header {
  background:url(../../images/top.png);
  height:72px;
}
#header a.header{
  width:720px;
  height:39px;
  margin:10px 0 0 5px;
  font-size: 35px;
  text-decoration: none;
  text-indent:0px;
  line-height:70px;
  font-family: 黑体,"Reenie Beanie",arial,sans-serif,微软雅黑;
  font-style:italic;
  font-weight:300;
  color:white;
}
#header a.header{
  /* background:url(images/header.png);*/
}
#header a:hover{
  background-color:yellow;
  color:blue;
  text-decoration: none;
}
#header img{
  margin:10px 0 0 10px;
  width:40px;
  height:39px;
  line-height:70px;
}

#header ul {
  float:right;
  text-align:right;
  vertical-align: middle;
  line-height:70px;
  font-size: 16px;
  font-family:黑体;
  margin-right:30px;
  color:white;
}

#header ul li {
  display:inline;
  height:39px;
}
#header ul #configure{
  background:url(../../images/configure.png) no-repeat left;
  width: 20px;
  height: 100px;
  padding-left:20px;
}
#header ul #conflog{
  margin-left: -5px;
  background:url(../../images/donwarrow.png) no-repeat left;
  width: 20px;
  height: 100px;
  padding-left:20px;
}
#header ul #help{
  background:url(../../images/help.png) no-repeat left;
  width: 20px;
  height: 20px;
  padding-left:20px;
}
#header ul li.logout{
  background:url(../../images/logout.png) no-repeat left;
  width: 20px;
  height: 20px;
  padding-left:20px;
}
#header ul form{
  display:inline;
}
#header ul form input{
  width:70px;
}
#header ul form input.login{
  width:50px;
  /*background: url("../../images/login.gif");*/
}
#header ul form input.register{
  /*-webkit-appearance: none; -moz-appearance: none; -o-appearance: none; appearance: none;
  background: url("../../images/register.gif");*/
  width:50px;
}
#header ul li a {
  text-decoration:none;
  color:white;
}
#header ul li a.manage {
  color:red;
}
#header ul li a:hover {
  color:#f00;
  text-decoration:underline;
}
#header ul li #user{
  color: #ffff00;
}
#header ul li strong.noread {
  background:url(../../images/noread.gif) no-repeat left center;
  padding:0 0 0 20px;
}
#header ul li strong.read {
  background:url(../../images/meg.gif) no-repeat left center;
  padding:0 0 0 20px;
}
#header ul li.skin {
  position:relative;
}
#header ul li dl#skin {
  position:absolute;
  top:14px;
  left:-30px;
  border:1px dashed #333;
  width:80px;
  background:#fff;
  text-align:center;
  padding:5px;
  display:none;
}



#header {
  width:100%;
  background:url(images/top.png);
  height:72px;
}
img.titile{
    display:inline;
}
#header p.title{
	height: 80px;
	font-size: 32px;
	margin: 0px 0px;
	text-decoration: none;
	text-indent: 0px;
	line-height: 80px;
	font-family: 黑体,"Reenie Beanie",arial,sans-serif,微软雅黑;
	font-weight: 300;
	color: white;
	background-image: url(images/djh-logo.png);
	background-repeat: no-repeat;
	background-position: left;
	padding-left: 50px;
	
	float:left;
}
#header ul {
	text-align: right;
	vertical-align: middle;
	line-height: 80px;
	font-size: 16px;
	font-family: 黑体;
	margin-right: 30px;
	color: white;
	float:right;
}

#header ul li {
	display:inline;
    height:40px;
	line-height: 40px;
}
#header ul li a{
	color:white;
	}
	#header ul li a:hover{
	color:yellow;
	}
#header ul #configure{
    background:url(images/configure.png) no-repeat left;
    width: 20px;
    height: 110px;
    padding-left:20px;
}
#header ul li.headerUser{
    color:yellow;
}
#header ul #conflog{
    margin-left: -5px;
    background:url(images/donwarrow.png) no-repeat left;
    width: 20px;
    height: 100px;
    padding-left:20px;
}
#header ul #help{
    background:url(images/help.png) no-repeat left;
    width: 20px;
    height: 20px;
    padding-left:20px;
}
#header ul li.logout{
    background:url(images/logout.png) no-repeat left;
    width: 20px;
    height: 20px;
    padding-left:20px;
}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	background-image: url(images/database1.jpg);
	background-position: top;
	padding-top: 60px;
}
a:hover {
	text-decoration: underline;
	color: #0F0;
	padding-top: 40px;
}
a:active {
	text-decoration: none;
}
#conf {
	position: absolute;
	border: 2px solid #669;
	left: 1135px;
	top: 62px;
	width: 121px;
	height: 152px;
	z-index: 2;
	font-size: 16px;
	background-color: #36C;
	display:none;
}
#header ul #configure #conf table {
	text-align: center;
}
#selectDB {
	width: 98%;
	height: auto;
	z-index: 2;
	font-size: 18px;
	background-color: #FFFFFF;
	border-radius: 8px;
	margin-top: 5px;
	margin-right: 10px;
	margin-bottom: 5px;
	margin-left: 15px;
	vertical-align: center;
	padding: 0px;
}
#selectDB h2{
	margin:auto;
	text-align: center;
}
#selectDB p{
	background-image: url(images/database1.jpg);
	background-repeat: no-repeat;
	background-position: top;
	padding-top: 29px;
	text-align: center;
	font-size:16px;
}
#selectDB form .department {
	font-weight: bold;
	margin-left: 20px;
	line-height: 30px;
	padding-top: 0px;
	padding-right: 0px;
	padding-bottom: 10px;
	padding-left: 10px;
}

#mainUp {
	width: 98%;
	height: auto;
	z-index: 1;
	margin-top: -15px;
	margin-right: 10px;
	margin-bottom: 10px;
	margin-left: 15px;
	background-color: #FFF;
	border-radius: 8px;
	font-size: 18px;
}
#selectDB h2 strong {
	font-weight: bold;
	color: #36C;
}
#mainUp #operateTitle {
	height: 30px;
	border-bottom-width: 2px;
	border-bottom-style: none;
	border-bottom-color: #399;
	vertical-align: middle;
	text-align: center;
}
h2 {
	color: #39C;
	font-weight: bold;
}
h2 {
	color: #36C;
}
.title2 {
	font-size: 18px;
}
.title2 {
	font-weight: bold;
}
#selectDB form table tr {
	height: 20px;
}
#mainUp form ul {
	list-style-type: none;
}
#mainUp form ul input.searchInput{
	width:60px;
	}


#img{
  margin-top: -2px;
  width:auto;
}
#userInfo{
  margin:20px;
  width:200px;
  height:200px;
  background:white;
  text-align: center;
  line-height: 30px;
  padding-bottom: 1px;
  border: 1px solid #CBC9C9;
  background: #fff;
  border-radius: 5px;
}
div.module{
  margin:20px;
  /*width:300px;*/
  height:auto;
  text-align: center;
  /*font-size:40px;*/
  line-height: 150px;

  padding-bottom: 1px;
  border: 1px solid #CBC9C9;
  background: #fff;
  border-radius: 5px;
  float: left;
}
div.module dt{
  font-size:24px;
  font-family: 黑体;
  border-bottom:1px solid;
}
#dataManage{
  /*position:absolute;
  top:280px;
  left:200px;*/
  /*border:1px solid #ccc;*/
  width:470px;
  padding-bottom: 1px;
  border: 1px solid #CBC9C9;
  background: #fff;
  border-radius: 5px;
  /*height:140px;*/
  height:auto;
  text-align:center;
  line-height: 30px;
  padding:5px;
  font-size: 18px;
}

#dataAnalyze{
  padding-bottom: 1px;
  border: 1px solid #CBC9C9;
  background: #fff;
  border-radius: 5px;
  /*position:absolute;
  top:450px;
  left:200px;*/
  width:570px;
  height:auto;
  text-align:center;
  line-height: 30px;
  padding:5px;
  font-size: 18px;
  /*display:none;*/
}


#footer {
  margin-top: auto;
  clear:both;
  width:1430px;
  height:60px;
  text-align:center;
  padding:10px 0 0 0;
  border-top:solid 2px blueviolet;
}
#footer p {
  font-size:12px;
  letter-spacing:1px;
  padding:5px 0 0 0;
}
#footer p span {
  color:#06f;
}
</style>

</head>

<body bgcolor="#cfd4ff">
<div id="header" >
  <p class="title">东江湖流域数据管理与综合分析智能中心</p>
  <ul>
		
		<li><a href="index.php">首页</a></li>
	<li>你好!</li>
        <li class="headerUser">用户名</li>
	<li><a href="index.php">个人设置</a></li>
		<li  id="configure"><a href="manage.php">系统管理</a>
        <div id="conf">
          <table width="119" height="208" border="0">
            <tr>
              <td><a href="#" target="_self">用户管理</a></td>
            </tr>
            <tr>
              <td><a href="#" target="_self">数据库管理</a></td>
            </tr>
            <tr>
              <td><a href="javascritp:window.print() " target="_self">打印机管理</a></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
            </tr>
            <tr>
              <td>&nbsp;</td>
            </tr>
          </table>
        </div>
</li>
		<li id="conflog"></li>
		<li  id="help" ><a href="help.php">帮助</a></li>

	<li class="logout"><a href="logout.php">退出登录</a></li>
		
  </ul>
</div>
<div id="img"><img src="images/dianti.jpg" alt="东江湖"/> </div>
<div class="module" id="userInfo">
  <?php
  if(isset($_COOKIE['username'])){
    echo '你好，'.$_COOKIE['username'];
    echo '<br/>';
    echo '你于'.$_COOKIE["loginTime"].'开始登录';
    echo '已经登录'.date("Y-m-d H-i-s");
  }else{
    echo '你好，欢迎来到东江湖流域数据综合管理与智能分析系统';
  }

  ?>
</div>

<div class="module" id="manage" >
  <!--<p>综合数据管理</p>-->
  <dl id="dataManage">
    <dt>数据资源类别介绍</dt>
    <dd>&nbsp;</dd>
    <dd>
      <table width="471" height="847" border="0">
        <tr>
          <th width="122" height="63" valign="middle" scope="row"><p><img src="images/shuwen1.jpg" width="76" height="53" alt="水文" /> 水文</p></th>
          <td width="101"><p><img src="images/database1.jpg" width="64" height="45" alt="数据库" /></p>
            <p>水文</p></td>
          <td width="113"><p><img src="images/database1.jpg" width="64" height="45" alt="数据库" /></p>
            <p>待定</p></td>
          <td width="117"><p><img src="images/database1.jpg" width="64" height="45" alt="数据库" /></p>
            <p>待定</p></td>
        </tr>
        <tr>
          <th height="50" scope="row"><img src="huanbao.png" width="76" height="49" alt="环保" />环保</th>
          <td><p><img src="images/database1.jpg" width="64" height="45" alt="数据库" /></p>
            <p>环保</p></td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <th height="50" scope="row"><img src="images/shuiwei.jpg" width="76" height="48" alt="水位" />水位</th>
          <td><p><img src="images/database1.jpg" width="64" height="45" alt="数据库" /></p>
            <p> 水位</p></td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <th height="69" scope="row"><img src="qixiang1.jpg" width="76" height="43" alt="气象" />气象</th>
          <td><p><img src="images/database1.jpg" width="64" height="45" alt="数据库" /></p>
            <p> 气象</p></td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <th height="47" scope="row"><img src="images/xumu.jpg" width="76" height="56" alt="畜牧" />畜牧</th>
          <td><p><img src="images/database1.jpg" width="64" height="45" alt="数据库" /></p>
            <p> 畜牧</p></td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <th height="48" scope="row"><img src="images/nongye.jpg" width="76" height="52" alt="农业" />农业</th>
          <td><p><img src="images/database1.jpg" width="64" height="45" alt="数据库" /></p>
            <p>农调</p></td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <th scope="row"><img src="images/renli.jpg" width="76" height="50" alt="财政" />人力</th>
          <td><p><img src="images/database1.jpg" width="64" height="45" alt="数据库" /></p>
            <p> 统计</p></td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <th height="70" scope="row"><img src="images/yiming.jpg" width="76" height="50" alt="移民" />移民</th>
          <td><p><img src="images/database1.jpg" width="64" height="45" alt="数据库" /></p>
            <p> 移民</p></td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <th scope="row"><img src="caizheng1.jpg" width="76" height="43" alt="财政" />财政</th>
          <td><p><img src="images/database1.jpg" width="64" height="45" alt="数据库" /></p>
            <p> 财政</p></td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <th height="21" scope="row">&nbsp;</th>
          <td colspan="3">&nbsp;</td>
        </tr>
        <tr>
          <th height="21" scope="row">&nbsp;</th>
          <td colspan="3">&nbsp;</td>
        </tr>
      </table>
    </dd>
    <!--<<dd><a href="baseManage.php?baseType=水文">水文数据库</a></dd>
    <dd><a href="baseManage.php?baseType=环保">环保数据库</a></dd>
    <dd><a href="baseManage.php?baseType=气象">气象数据库</a></dd>
    <dd><a href="baseManage.php?baseType=统计">人口统计数据库</a></dd>
    <dd><a href="baseManage.php?baseType=农调">人均收入数据库</a></dd>
    <dd><a href="baseManage.php?baseType=农调">人均收入数据库</a></dd>
    <dd><a href="baseManage.php?baseType=农调">人均收入数据库</a></dd>
    <dd><a href="baseManage.php?baseType=农调">人均收入数据库</a></dd>
    <dd><a href="baseManage.php?baseType=农调">人均收入数据库</a></dd>
    <dd><a href="baseManage.php?baseType=农调">更多>></a></dd>-->

  </dl>

</div>
<div class="module" id="analyze">
  <!--<p>综合数据分析</p>-->
  <dl class="operator" id="dataAnalyze">
    <dt>数据资源操作和分析</dt>
    <dd>&nbsp;</dd>
    <dd>
      <table width="576" height="839">
        <tr>
          <th width="124" class="operate" scope="row"><p><a href="search.php"><img src="images/cha.jpg" width="40" height="40" alt="查询" /></a></p>
            <p><a href="search.php">查询</a></p></th>
          <td width="440" style="font-style: italic">通过客户端向系统提交约束条件，获取指定的内容。</td>
        </tr>
        <tr>
          <th  class="operate" scope="row" onmouseover="MM_effectHighlight(this, 1000, '#ffffff', '#ff0000', '#ffffff', false)"><p><img src="images/shan.jpg" width="29" height="32" alt="查询" /></p>
            <p>删除</p></th>
          <td style="font-style: italic">通过客户端向系统提交约束条件，删除指定的内容。</td>
        </tr>
        <tr>
          <th class="operate" scope="row"><p><img src="images/gai.png" width="40" height="40" alt="查询" /></p>
            <p>修改</p></th>
          <td style="font-style: italic">通过客户端向系统提交约束条件，对指定的内容进行修改。</td>
        </tr>
        <tr>
          <th class="operate" scope="row"><p><img src="images/jia.jpg" width="40" height="40" alt="查询" /></p>
            <p>录入</p></th>
          <td style="font-style: italic">在客户端键入一条或多条数据，将数据录入数据库服务器</td>
        </tr>
        <tr>
          <th class="operate" scope="row"><p><img src="images/import.png" width="40" height="40" alt="查询" /></p>
            <p>导入</p></th>
          <td style="font-style: italic">在客户端上传数据库对应的excel文件，sql文件，将数据批量导入数据库服务器。</td>
        </tr>
        <tr>
          <th class="operate" scope="row"><p><img src="images/export.png" width="40" height="40" alt="查询" /></p>
            <p>导出</p></th>
          <td style="font-style: italic">通过客户端向系统提交约束条件，从数据库服务器导出数据到客户端。</td>
        </tr>
        <tr>
          <th class="operate" scope="row"><p><img src="images/tongjifenxi.jpg" width="54" height="59" alt="查询" /></p>
            <p>统计分析</p></th>
          <td>通过对数据进行简单的统计分析得到较为直观的统计数据</td>
        </tr>
        <tr>
          <th height="105" class="operate" scope="row" onmouseover="MM_effectHighlight(this, 1000, '#ffffff', '#0033FF', '#0033FF', true)" onmouseout="MM_effectHighlight(this, 1000, '#0033FF', '#FFFFFF', '#ffffff', true)"><p><img src="images/zhinengfenxi.png" width="40" height="40" alt="查询" /></p>
            <p>智能分析</p></th>
          <td style="font-style: italic">通过聚类，分类，神经网络等技术，对数据进行智能分析，获得较为准确的预测数据</td>
        </tr>
        <tr>
          <th class="operate" scope="row"><p>&nbsp;</p></th>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <th height="33" class="operate" scope="row"><p>&nbsp;</p></th>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <th height="83" class="operate" scope="row"><p>&nbsp;</p></th>
          <td>&nbsp;</td>
        </tr>
      </table>
    </dd>
    <dd>&nbsp; </dd>
    <!--<dd><a href="baseManage.php?baseType=水文">水文数据库</a></dd>
    <dd><a href="baseManage.php?baseType=环保">环保数据库</a></dd>
    <dd><a href="baseManage.php?baseType=气象">气象数据库</a></dd>
    <dd><a href="baseManage.php?baseType=统计">人口统计数据库</a></dd>
    <dd><a href="baseManage.php?baseType=农调">人均收入数据库</a></dd>
    <dd><a href="baseManage.php?baseType=农调">人均收入数据库</a></dd>
    <dd><a href="baseManage.php?baseType=农调">人均收入数据库</a></dd>
    <dd><a href="baseManage.php?baseType=农调">人均收入数据库</a></dd>
    <dd><a href="baseManage.php?baseType=农调">人均收入数据库</a></dd>
    <dd><a href="baseManage.php?baseType=农调">更多>></a></dd>-->
  </dl>
</div>



<?php
require ROOT_PATH.'includes/footer.inc.php';
?>
<script type="text/javascript" src="js/index.js"></script>
</body>
</html>

</body>
</html>
