<?php
/**
 * TestGuest Version1.0
 * ================================================
 * Copy 2010-2012 yc60
 * Web: http://www.yc60.com
 * ================================================
 * Author: Lee
 * Date: 2010-8-21
 */
/*if(extension_loaded('gd')){
	echo '你可以使用gd';

}*/
session_start();
//定义个常量，用来授权调用includes里面的文件
//echo 1;
define('IN_TG',true);
//定义个常量，用来指定本页的内容
define('SCRIPT','login');
//引入公共文件
require dirname(__FILE__).'/includes/common.inc.php';
//登录状态


//_login_state();
global $_system;
//echo 2;
//开始处理登录状态
if ($_GET['action'] == 'login') {
	if (!empty($_system['code'])) {
		//为了防止恶意注册，跨站攻击
		_check_code($_POST['code'],$_SESSION['code']);
	}
	//引入验证文件
	include ROOT_PATH.'includes/login.func.php';
	//接受数据
	$_clean = array();
	$_clean['username'] = _check_username($_POST['username'],2,20);
	$_clean['password'] = _check_password($_POST['password'],6);
	$_clean['time'] = _check_time($_POST['time']);
	//到数据库去验证,php的变量写到sql语句中时，如果不是数字，则需要加上引号,sql语句中引用变量必须要加花括号
	global $_conn;
	$sql=<<<EOF
			SELECT username,authority,department,loginstate,active From djhuser WHERE username='{$_clean['username']}' AND password='{$_clean['password']}';
EOF;
	//echo $sql;
	$result=pg_query($sql);
	//$rows=pg_fetch_array($result,PGSQL_ASSOC);
	$rows=pg_fetch_assoc($result);
	var_dump($rows);
	exit();
	//echo $rows['username'];
	/*$sql=<<<EOF
			SELECT username,authority,department,loginstate From djhuser WHERE id=1;
EOF;
	echo $sql;
	$result=pg_query($sql);
	$rows=pg_fetch_row($result);
	echo $rows[0];*/
	/*$result=pg_query("SELECT * From djhuser WHERE username='{$_clean['username']}' AND password='{$_clean['password']}'");*/
    /*$_conn = pg_connect("host=localhost port=5432 dbname=postgres user=postgres password=123456");
    $result0=pg_query($_conn,"SELECT * From hydraulictable WHERE id=15");
    $rows0=pg_fetch_array($result0,PGSQL_ASSOC);
    echo $rows0['datetime'];
	$result=pg_query($_conn,"SELECT * From djhuser WHERE username=contract");

	$rows=pg_fetch_array($result,PGSQL_ASSOC);
	echo $rows['username'];
	echo 2;*/
	/*if(!!$rows=_fetch_array("SELECT username,authority,department,loginstate From djhuser WHERE username='{$_clean['username']}' AND password='{$_clean['password']}'")){*/
	//echo !!$rows;
	if(!!$rows){
		//echo $rows['username'];
		//不允许用户异地登录
		/*if($rows['loginstate']==true){
			_alert_back('你的账号已经在其他地方登陆');
		}*/
		if ($rows['active']!='t'){
			_alert_back('你的账号未激活');
		}
		//登陆成功后，更改登录信息
		$updateSql=<<<EOF
				UPDATE djhuser SET 
									loginState=true,
									lastTime=NOW(),
									lastIp='{$_SERVER['REMOTE_ADDR']}',
									loginCount=loginCount+1
							  WHERE
									username='{$rows['username']}';
EOF;

		pg_query($updateSql);
		_setcookies($_clean['username'],$_clean['time']);
		if($rows['authority']==1){
			$_SESSION['authority']=1;
			$_SESSION['superUser']=$_clean['username'];
		}elseif($rows['authority']==2){
			$_SESSION['authority']=2;
			/*ECHO $_SESSION['authority'];
			exit();*/
			$_SESSION['admin']=$_clean['username'];
		}
		//记录用户所属部门
		//$_SESSION['department']=$rows['department'];
		_close();
		//pg_errormessage($_conn);
		_location(null,'index.php');
	}else {
		_close();
		//echo "failed";
		_session_destroy();
		_location('用户名密码不正确或者该账户未被激活！','login.php?fres=new');
	}


	/*if (!!$_rows = _fetch_array("SELECT tg_username,tg_uniqid,tg_level FROM tg_user WHERE tg_username='{$_clean['username']}' AND tg_password='{$_clean['password']}' AND tg_active='' LIMIT 1")) {
		//登录成功后，记录登录信息
		_query("UPDATE tg_user SET
															tg_last_time=NOW(),
															tg_last_ip='{$_SERVER["REMOTE_ADDR"]}',
															tg_login_count=tg_login_count+1
												WHERE
															tg_username='{$_rows['tg_username']}'
													");
		//_session_destroy();
		_setcookies($_rows['tg_username'],$_rows['tg_uniqid'],$_clean['time']);
		if ($_rows['tg_level'] == 1) {
			$_SESSION['admin'] = $_rows['tg_username'];
		}
		_close();
		_location(null,'member.php');
	} else {
		_close();
		//_session_destroy();
		_location('用户名密码不正确或者该账户未被激活！','login.php');
	}*/
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <?php
	require ROOT_PATH.'includes/title.inc.php';

	//require 'C:/software/httpd-2.4.23-x64/Apache/htdocs/dongjianghu1/'.'includes/title.inc.php';
    ?>
    <script type="text/javascript" src="js/code.js"></script>
    <script type="text/javascript" src="js/login.js"></script>
</head>
<body>
<?php
require ROOT_PATH.'includes/header.inc.php';
?>

<div id="login">
    <h2>登录</h2>
    <form method="post" name="login" action="login.php?action=login">
        <dl>
            <dt></dt>
            <dd>用 户 名：<input type="text" name="username" class="text" /></dd>
            <dd>密　　码：<input type="password" name="password" class="text" /></dd>
            <dd>保　　留：<input type="radio" name="time" value="0" checked="checked" /> 不保留 <input type="radio" name="time" value="1" /> 一天 <input type="radio" name="time" value="2" /> 一周 <input type="radio" name="time" value="3" /> 一月</dd>
            <?php if (!empty($_system['code'])) {?>
                <dd>验 证 码：<input type="text" name="code" class="text code"  /> <img src="code.php" id="code" onclick="javascript:this.src='code.php?tm='+Math.random();" alt="yzm"/></dd>
            <?php }?>
			<input type="hidden" id="fresh" value="<?php echo $_GET['fresh'];?>"/>
            <dd><input type="submit" value="登录" class="button" /> <input type="button" value="注册" id="location" class="button location" /></dd>

        </dl>
    </form>
</div>

<?php
require ROOT_PATH.'includes/footer.inc.php';
?>
</body>
</html>

