<?php
/**
 * Created by PhpStorm.
 * User: hetong
 * Date: 2016/11/4
 * Time: 22:41
 */
header("Content-Type:text/html;charset=utf-8");
function winDisplay($parameter)
{
    //echo $parameter;
    $display = '';
    //水文表
    if ($_SESSION['tableName'] == 'hydraulictable') {
        switch ($parameter) {
            case 'id':
                //echo "序号";
                $display = "序号";
                break;
            case 'datetime':
                // echo "日期";
                $display = "日期(格式:xxxx-xx-xx)";
                break;
            //水文
            case 'precipitation':
                // echo "降雨量";
                $display = "降雨量(mm)";
                break;
            case 'avgflow':
                // echo "平均流量";
                $display = "平均流量(m3/s)";
                break;
            default:
                // echo '不存在此字段';
                $display = '不存在此字段';
                break;
        }
        //统计表

    }
    //统计表
    if ($_SESSION['tableName'] == "zxctable") {
        switch ($parameter) {
            case 'id':
                //echo "序号";
                $display = "序号";
                break;
            case 'datetime':
                // echo "日期";
                $display = "年份";
                break;

            //统计
            case 'tnoh':
                // echo "降雨量";
                $display = "总户数";
                break;
            case 'tp':
                // echo "平均流量";
                $display = "合计";
                break;
            case 'mp':
                // echo "降雨量";
                $display = "男";
                break;
            case 'fp':
                // echo "平均流量";
                $display = "女";
                break;
            case 'bir':
                // echo "降雨量";
                $display = "出生人数";
                break;
            case 'bp':
                // echo "降雨量";
                $display = "出生千分率";
                break;
            case 'dea':
                // echo "平均流量";
                $display = "死亡人数";
                break;
            case 'dp':
                // echo "平均流量";
                $display = "死亡千分率";
                break;

            case 'ngp':
                // echo "平均流量";
                $display = "自然增长人数";
                break;

            case 'ngr':
                // echo "平均流量";
                $display = "自然增长千分率";
                break;


            default:
                // echo '不存在此字段';
                $display = '不存在此字段';
                break;
        }
    }
    //环保表
    if ($_SESSION['tableName'] == "wqmtable") {
        switch ($parameter) {
            case 'id':
                //echo "序号";
                $display = "序号";
                break;
            case 'datetime':
                // echo "日期";
                $display = "日期(格式:xxxx-xx-xx)";
                break;
            case 'stname':
                // echo "降雨量";
                $display = "测站名称";
                break;
            case 'riname':
                // echo "平均流量";
                $display = "河流名称";
                break;
            case 'sename':
                // echo "降雨量";
                $display = "断面名称";
                break;
            case 'watercode':
                // echo "平均流量";
                $display = "水期代码";
                break;
            case 'selocation':
                // echo "降雨量";
                $display = "断面位置";
                break;
            case 'watertemp':
                // echo "降雨量";
                $display = "水温(℃)";
                break;
            case 'flow':
                // echo "平均流量";
                $display = "流量";
                break;
            case 'ph':
                // echo "平均流量";
                $display = "pH值";
                break;

            case 'dox':
                // echo "平均流量";
                $display = "溶解氧";
                break;

            case 'codmn':
                // echo "平均流量";
                $display = "CODMn";
                break;

            case 'cod':
                // echo "平均流量";
                $display = "化学需氧量 ";
                break;
            case 'bod':
                // echo "平均流量";
                $display = "BOD5	";
                break;
            case 'an':
                // echo "平均流量";
                $display = "氨氮";
                break;
            case 'tp':
                // echo "平均流量";
                $display = "总磷	";
                break;
            case 'tn':
                // echo "平均流量";
                $display = "总氮	";
                break;
            case 'copper':
                // echo "平均流量";
                $display = "铜";
                break;
            //
            case 'zinc':
                // echo "平均流量";
                $display = "锌";
                break;
            case 'flu':
                // echo "平均流量";
                $display = "氟化物";
                break;
            case 'arsenic':
                // echo "平均流量";
                $display = "砷";
                break;
            case 'mercury':
                // echo "平均流量";
                $display = "汞";
                break;
            case 'cd':
                // echo "平均流量";
                $display = "镉";
                break;
            case 'crvi':
                // echo "平均流量";
                $display = "六价铬	";
                break;
            case 'lead':
                // echo "平均流量";
                $display = "铅";
                break;
            case 'cyanide':
                // echo "平均流量";
                $display = "氰化物";
                break;
            case 'vp':
                // echo "平均流量";
                $display = "挥发酚";
                break;
            case 'petro':
                // echo "平均流量";
                $display = "石油类";
                break;
            case 'las':
                // echo "平均流量";
                $display = "阴离子表面活性剂";
                break;
            case 'sulfide':
                // echo "平均流量";
                $display = "硫化物";
                break;
            case 'wqc':
                // echo "平均流量";
                $display = "水质类别";
                break;
            case 'ti':
                // echo "平均流量";
                $display = "超标项目";
                break;


            default:
                // echo '不存在此字段';
                $display = '不存在此字段';
                break;
        }
    }

    //气象表
    if ($_SESSION['tableName'] == "attable") {
        switch ($parameter) {
            case 'id':
                //echo "序号";
                $display = "序号";
                break;
            case 'datetime':
                // echo "日期";
                $display = "年份";
                break;
            //统计
            case 'arsd':
                // echo "降雨量";
                $display = "年暴雨日数";
                break;
            case 'jan':
                // echo "平均流量";
                $display = "	1月气温(℃)	";
                break;
            case 'feb':
                // echo "降雨量";
                $display = "2月气温(℃)";
                break;
            case 'mar':
                // echo "平均流量";
                $display = "	3月气温(℃)	";
                break;
            case 'apr':
                // echo "降雨量";
                $display = "4月气温(℃)";
                break;
            case 'may':
                // echo "降雨量";
                $display = "	5月气温(℃)";
                break;
            case 'june':
                // echo "平均流量";
                $display = "	6月气温(℃)	";
                break;
            case 'july':
                // echo "平均流量";
                $display = "7月气温(℃)";
                break;

            case 'aug':
                // echo "平均流量";
                $display = "	8月气温(℃)	";
                break;
            case 'sept':
                // echo "平均流量";
                $display = "9月气温(℃)	";
                break;
            case 'oct':
                // echo "平均流量";
                $display = "10月气温(℃)	";
                break;
            case 'nov':
                // echo "平均流量";
                $display = "11月气温(℃)	";
                break;
            case 'dec':
                // echo "平均流量";
                $display = "12月气温(℃)";
                break;
            case 'aaat':
                // echo "平均流量";
                $display = "	年平均气温(℃)";
                break;
            case 'amaxat':
                // echo "平均流量";
                $display = "	年最高气温(℃)	";
                break;
            case 'aminat':
                // echo "平均流量";
                $display = "年最低气温(℃)	";
                break;
            case 'aec':
                // echo "平均流量";
                $display = "年蒸发量";
                break;

            default:
                // echo '不存在此字段';
                $display = '不存在此字段';
                break;
        }
    }
    //农调
    if ($_SESSION['tableName'] == "rpcitable") {
        switch ($parameter) {


            case 'id':
                //echo "序号";
                $display = "序号";
                break;
            case 'datetime':
                // echo "日期";
                $display = "年份";
                break;
            case 'vname':
                // echo "降雨量";
                $display = "乡镇名称	";
                break;
            case 'tnoh':
                // echo "平均流量";
                $display = "总户数（户）";
                break;
            case 'tp':
                // echo "降雨量";
                $display = "	总人口（人）";
                break;
            case 'yeaa':
                // echo "平均流量";
                $display = "	年末耕地面积（亩）";
                break;
            case 'grdp':
                // echo "降雨量";
                $display = "	人均可支配收入（元）";
                break;
            case 'pcdi':
                // echo "降雨量";
                $display = "	国内生产总值（万元）";
                break;
            case 'fai':
                // echo "平均流量";
                $display = "	固定资产投资（万元）";
                break;

            default:
                // echo '不存在此字段';
                $display = '不存在此字段';
                break;
        }
    }
    //畜牧表
    if ($_SESSION['tableName'] == "lstable") {
        switch ($parameter) {
            case 'id':
                //echo "序号";
                $display = "序号";
                break;
            case 'item':
                // echo "日期";
                $display = "项目";
                break;

            //统计
            case 'num':
                // echo "降雨量";
                $display = "数量";
                break;

            default:
                // echo '不存在此字段';
                $display = '不存在此字段';
                break;
        }
    }
    //水位表
    if ($_SESSION['tableName'] == "wltable") {
        switch ($parameter) {
            case 'id':
                //echo "序号";
                $display = "序号";
                break;
            case 'datetime':
                // echo "日期";
                $display = "日期(格式:xxxx-xx-xx)";
                break;

            //统计
            case 'wl':
                $display = '大东江水位(m)';
                break;

            default:
                // echo '不存在此字段';
                $display = '不存在此字段';
                break;
        }
    }
    if ($_SESSION['tableName'] == "tongji") {
        switch ($parameter) {
            case 'id':
                //echo "序号";
                $display = "序号";
                break;
            case 'datetime':
                // echo "日期";
                $display = "日期";
                break;

            //统计
            case 'high':
                $display = '大东江水位(m)';
                break;

            default:
                // echo '不存在此字段';
                $display = '不存在此字段';
                break;
        }
    }
    //移民
    if ($_SESSION['tableName'] == "imtable") {
        switch ($parameter) {
            case 'id':
                //echo "序号";
                $display = "序号";
                break;
            case 'loc':
                // echo "日期";
                $display = "村组别";
                break;

            //统计
            case 'fqp':
                // echo "降雨量";
                $display = "	一季度人口";
                break;
            case 'sqc':
                // echo "平均流量";
                $display = "	二季度变动	";
                break;
            case 'sqs':
                // echo "降雨量";
                $display = "二季度应发";
                break;
            case 'ss':
                // echo "平均流量";
                $display = "	补助金额";
                break;
            case 'res':
                // echo "降雨量";
                $display = "	变动原因";
                break;

            default:
                // echo '不存在此字段';
                $display = '不存在此字段';
                break;
        }
    }
    //财政
    if ($_SESSION['tableName'] == "ftable") {


        switch ($parameter) {
            case 'id':
                //echo "序号";
                $display = "序号";
                break;
            case 'datetime':
                // echo "日期";
                $display = "年度";
                break;

            //统计
            case 'fr':
                // echo "降雨量";
                $display = "财政总收入";
                break;
            case 'ab1':

                // echo "平均流量";
                $display = "	年度预算1";
                break;
            case 'tc1':
                // echo "降雨量";
                $display = "累计完成1	";
                break;

            case 'tcp1':
                // echo "平均流量";
                $display = "为年度预算%1	";
                break;


            case 'tlyidp1':
                // echo "降雨量";
                $display = "比上年±%1	";
                break;
            case 'ct':
                // echo "降雨量";
                $display = "其中：上划中央“两税”	";
                break;
            case 'ab2':
                // echo "平均流量";
                $display = "年度预算2	";
                break;
            case 'tc2':
                // echo "平均流量";
                $display = "累计完成2	";
                break;

            case 'tcp2':
                // echo "平均流量";
                $display = "为年度预算%2	";
                break;

            case 'tlyidp2':
                // echo "平均流量";
                $display = "比上年±%	2";
                break;
            case 'pt':
                // echo "平均流量";
                $display = "上划中省“两个所得税”	";
                break;
            case 'ab3':
                // echo "平均流量";
                $display = "年度预算3";
                break;
            case 'tc3':
                // echo "平均流量";
                $display = "累计完成3	";
                break;
            case 'tcp3':
                // echo "平均流量";
                $display = "为年度预算%3";
                break;
            case 'tlyidp3':
                // echo "平均流量";
                $display = "	比上年±%3	";
                break;
            case 'gbr':
                // echo "平均流量";
                $display = "一般预算收入";
                break;
            case 'ab4':
                // echo "平均流量";
                $display = "	年度预算4";
                break;
            case 'tc4':
                // echo "平均流量";
                $display = "	累计完成4	";
                break;
            case 'tcp4':
                // echo "平均流量";
                $display = "为年度预算%4	";
                break;
            case 'tlyidp4':
                // echo "平均流量";
                $display = "比上年±%4";
                break;

            default:
                // echo '不存在此字段';
                $display = '不存在此字段';
                break;
        }
    }
    if ($_SESSION['tableName'] == "fwtable") {
        switch ($parameter) {
            case 'id':
                //echo "序号";
                $display = "序号";
                break;
            case 'datetime':
                // echo "日期";
                $display = "日期";
                break;
            //统计
            case 'data1':
                // echo "降雨量";
                $display = "数据一";
                break;
            case 'data2':
                // echo "平均流量";
                $display = "数据二";
                break;
            default:
                // echo '不存在此字段';
                $display = '不存在此字段';
                break;
        }
    }
    if ($_SESSION['tableName'] == "runofftable") {
        switch ($parameter) {
            case 'id':
                //echo "序号";
                $display = "序号";
                break;
            case 'datetime':
                // echo "日期";
                $display = "日期(格式:月(两位)/日(两位)/年(两位) x午xx时xx分xx秒),eg:07/31/14 上午10时57分36秒";
                break;
            //统计
            case 'temp':
                // echo "降雨量";
                $display = "温度";
                break;
            case 'event':
                // echo "平均流量";
                $display = "事件(event:ml)";
                break;
            case 'coulperdetached':
                // echo "平均流量";
                $display = "耦合器分离(coulperdetached)";
                break;
            case 'coulperattached':
                // echo "平均流量";
                $display = "耦合器连接(coulperattached)";
                break;
            case 'stopped':
                // echo "平均流量";
                $display = "停止(stopped)";
                break;
            case 'eof':
                // echo "平均流量";
                $display = "结束(eof)";
                break;
            default:
                // echo '不存在此字段';
                $display = '不存在此字段';
                break;
        }
    }
    if ($_SESSION['tableName'] == "metable") {
        switch ($parameter) {
            case 'id':
                //echo "序号";
                $display = "序号";
                break;
            case 'datetime':
                // echo "日期";
                $display = "日期(格式:月(两位)/日(两位)/年(两位) x午xx时xx分xx秒),eg:07/31/14 上午10时57分36秒";
                break;

            case 'pres':
                // echo "降雨量";
                $display = "压强(:kpa)";
                break;
            case 'rain':
                // echo "平均流量";
                $display = "降雨量(:mm)";
                break;
            case 'solar':
                // echo "平均流量";
                $display = "太阳辐射(W/m)";
                break;
            case 'wd':
                // echo "平均流量";
                $display = "风向(Wind Direction?)";
                break;
            case 'ws':
                // echo "平均流量";
                $display = "普通风速(:m/s)";
                break;
            case 'gs':
                // echo "平均流量";
                $display = "狂风风速(:m/s)";
                break;
            case 'temp':
                // echo "平均流量";
                $display = "温度(:℃)";
                break;
            case 'rh':
                // echo "平均流量";
                $display = "RH%";
                break;
            case 'batt':
                // echo "平均流量";
                $display = "电压(:v)";
                break;
            default:
                // echo '不存在此字段';
                $display = '不存在此字段';
                break;
        }
    }
    return $display;
}
pg_connect("host=localhost port=5432 dbname=postgres user=postgres password=123456")
or die("数据库连接失败");
$query1=<<<EOF
SELECT max(datetime) as date FROM  hydraulictable;
EOF;

$result1=pg_query($query1);
$timemax=pg_fetch_assoc($result1);
var_dump($timemax);