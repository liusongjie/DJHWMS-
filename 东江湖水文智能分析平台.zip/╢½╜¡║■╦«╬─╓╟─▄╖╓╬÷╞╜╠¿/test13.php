<?php
$fileName = $DbName . '_PgSQL_data_backup_' . date('Y-m-d-H-i-s').'.sql';
$dumpFileName= "$fileName";
/*header("Content-Disposition: attachment; filename=" . $fileName);*/
/*header("Content-type: application/octet-stream");
header("Pragma:no-cache");
header("Expires:0");*/
$DbHost = 'localhost';
$DbUser = 'postgres';
$DbPwd  = '123456';
$DbName = 'postgres';
/*echo `C:\\Program Files\\PostgreSQL\\pg94\\bin\\pg_dump -h $DbHost -U $DbUser -p $DbPwd $DbName > $dumpFileName`;*/
$cmd="pg_dump -h $DbHost -U $DbUser $DbName > $dumpFileName";
//echo $cmd;
system("pg_dump -h $DbHost -U $DbUser $DbName > test6.bak");
/*$hd = fopen($dumpFileName, 'rb');
echo fread($hd, filesize($dumpFileName));
fclose($hd);*/

    ?>