<?php
header("Content-Type:text/html;charset=utf-8");
session_start();
//定义个常量，用来授权调用includes里面的文件
define('IN_TG',true);
//定义个常量，用来指定本页的内容
define('SCRIPT','search');
//引入公共文件
require dirname(__FILE__).'/includes/common.inc.php';

if($_GET['tableCh']=='水文信息'){
    // 得到所有字段名
    /*$sql=<<<EOF
        SHOW FULL COLUMNS FROM HYDRAULICTABLE;
        EOF;*/
    //setcookie('tableName','hydraulictable');
    $_SESSION['tableCh']="水文信息";
    $_SESSION['tableName']='hydraulictable';


    /*$ziduanDis=pg_fetch_assoc($result);
    print_r($ziduanDis);*/
    //$_GET['tableCH']=='气象信息':要区分大小写
}elseif($_GET['tableCh']=='气象信息'){
    $_SESSION['tableCh']="气象信息";
    $_SESSION['tableName']='attable';
}elseif($_GET['tableCh']=='统计信息'){
    $_SESSION['tableCh']="统计信息";
    $_SESSION['tableName']='zxctable';
}elseif($_GET['tableCh']=='农调信息'){
    $_SESSION['tableCh']="农调信息";
    $_SESSION['tableName']='wqmtable';
} elseif($_GET['tableCh']=='环保信息'){
    $_SESSION['tableCh']="环保信息";
    $_SESSION['tableName']='wqmtable';
}
$sql=<<<EOF
SELECT a.attname, a.attnotnull as notnull FROM pg_class as c,pg_attribute as a  where c.relname = '{$_SESSION['tableName']}' and a.attrelid = c.oid and a.attnum>1
EOF;
//echo $sql;
$result=pg_query($sql);
while($row=pg_fetch_assoc($result)){
    $fields[]=$row;
}

?>