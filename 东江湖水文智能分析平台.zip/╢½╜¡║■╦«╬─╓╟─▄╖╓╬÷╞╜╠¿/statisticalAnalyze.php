<?php
header("Content-Type:text/html;charset=utf-8");
header("Cache-Control: no-cache");
session_start();
//定义个常量，用来授权调用includes里面的文件
define('IN_TG',true);
//定义个常量，用来指定本页的内容
define('SCRIPT','statisticalAnalyze');
//引入公共文件
require dirname(__FILE__).'/includes/common.inc.php';
if(!empty($_SESSION['tableName'])) {
//得到字段名，将字段名存入数组$fields[],note取的时候要用[]['attname']取
    $sql = <<<EOF
SELECT a.attname, a.attnotnull as notnull FROM pg_class as c,pg_attribute as a  where c.relname = '{$_SESSION['tableName']}' and a.attrelid = c.oid and a.attnum>1
EOF;
//echo $sql;
    $result = pg_query($sql);
    while ($row = pg_fetch_assoc($result)) {
        $fields[] = $row;
    }

//根据制约条件取出数据
    /* $sql=<<<EOF
    SELECT * FORM {$_SESSION['tableName']} WHERE precipitation<1.5;
    EOF;*/
    $authority = 0;
    foreach ($dbInDp as $key => $value) {
        if (in_array($_SESSION['tableName'], $value)) {
            //根据对应关系，查出所在部门的权限
            //$tbsSql = implode(',', $value);
            $sqlDp = <<<EOF
  SELECT {$key} FROM djhuser WHERE username='{$_COOKIE['username']}'
EOF;
            // echo $sqlDp;
            $authoritys = pg_fetch_assoc(pg_query($sqlDp));
            $authority = $authoritys[$key];
            break;
        }
    }



}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <?php require_once('includes/title.inc.php')?>
    <link rel="shortcut icon" href="dongjianghu.ico" />
    <script type="text/javascript" src="js/jquery-3.1.0.min.js"></script>
    <link rel="stylesheet" type="text/css" href="js/jQuery-jcDate-master/src/jcDate.css" media="all" />
    <script type="text/javascript" src="js/jQuery-jcDate-master/src/jQuery-jcDate.js" charset="utf-8"></script>
    <script type="text/javascript" src="js/baseManage.inc1.js"></script>
    <link rel="stylesheet" type="text/css" href="templateCss.css"/>
<script type="text/javascript">

    function centerWindow(url,name,height,width) {
        var left = (screen.width - width) / 2;
        var top = (screen.height - height) / 2;
        window.open(url,name,'height='+height+',width='+width+',top='+top+',left='+left);
    }
</script>
<style type="text/css">
    p.result{
        min-height:40px;
        color:red;
        font-size: 28px;
    }

</style>

</head>

<body bgcolor="#cfd4ff">

<?php
require_once("includes/header.inc.php");
?>
<div class="bodyContent">
<?php
require_once("includes/dbSelect.inc.php");
?>

<?php if(!empty($_GET['firstAction'])){?>
    <div id="mainDown">
        <h2> 分析结果</h2>
        <div id="display">
            <?php
            if(empty($_GET['analyzeField'])){
                _alert_back('请选择查询字段');
            }
            if(empty($_GET['analyzeFieldItem'])){
                _alert_back('请选择查询项目');
            }

            $analyzeLocalItem=array('max','min','avg');
            if(in_array($_GET['analyzeFieldItem'],$analyzeLocalItem)){
                $itemSql=<<<EOF
SELECT {$_GET['analyzeFieldItem']}({$_GET['analyzeField']}) from {$_SESSION['tableName']} where datetime between '{$_GET['firstdatetime']}' and '{$_GET['seconddatetime']}'
EOF;
                //echo $itemSql;
                //exit();
                $statisticalResults=pg_fetch_assoc(pg_query($itemSql));
                // array(1) { ["min"]=> string(1) "0" }
                //var_dump($statisticalResults);


                $itemToCh=array('max'=>'最大值','min'=>'最小值','avg'=>'平均值');
                echo '<p class="result">'.$_GET['firstdatetime'].'到'.$_GET['seconddatetime'].'之间'.winDisplay($_GET['analyzeField']).'的'.$itemToCh[$_GET["analyzeFieldItem"]].'是'.$statisticalResults[$_GET["analyzeFieldItem"]].'</p>';


            }else{


                /*echo '<p class="analyzeTitle" style="font-size: 22px;font-weight: bolder">'.$_SESSION['tableCh'].'表 '.$_GET['firstdatetime'].'--'.$_GET['seconddatetime'].'间'.winDisplay($_GET['analyzeField']).'的统计信息'.'</p>';*/

                /*$filePart='\\'.time().'binzhuangtu.jpg';
                  $filePathPart='\\'.time().'tiaoxintu.jpg';*/
                $filePart='\\'.'binzhuangtu.jpg';
                $filePathPart='\\'.'tiaoxintu.jpg';
                $file=addslashes(ROOT_PATH.$_COOKIE['username'].$filePart);
                $filePath=addslashes(ROOT_PATH.$_COOKIE['username'].$filePathPart);
                // echo $file;
                // echo '<br/>';
                // echo $filePath;
                if (!file_exists(ROOT_PATH.$_COOKIE['username'])){
                    mkdir (ROOT_PATH.$_COOKIE['username']);
                    //echo '创建文件夹test成功';
                } /*else {
                echo '需创建的文件夹test已经存在';
            }*/

                require_once("http://localhost:8080/JavaBridgeTemplate611/java/Java.inc");


                /* $analyze->Canshuchuandi31('222',$_GET['firstdatetime'],$_GET['seconddatetime'],$_GET['analyzeField'],$file,$filePath);*/


//echo '<br/>';
//echo $_SESSION['tableName'];


            $mulDimensionTable=array('metable','runofftable','fwtable');
            $condition='datetime';
                //echo $_SESSION['tableName'];
            if(in_array($_SESSION['tableName'],$mulDimensionTable) ) {
                if ($_SESSION['tableName']=='metable') {
                    if($_GET['analyzeFieldItem']=='histogram') {
                        $analyze = new Java('Erweitj');
                        // Erweitj.erwei1("123","2014","wd","ws","rh","E:\\123.jpg");
                        switch (count($_GET['analyzeField'])) {
                            case 0:
                                _alert_info('请选择至少一个字段');
                                break;
                            case 1:
                                $analyze->erwei1('123', $_GET['year'], $_GET['analyzeField'][0], $file);
                                break;
                            case 2:
                                $analyze->erwei1('123', $_GET['year'], $_GET['analyzeField'][0], $_GET['analyzeField'][1], $file);
                                break;
                            case 3:
                                $analyze->erwei1('123', $_GET['year'], $_GET['analyzeField'][0], $_GET['analyzeField'][2], $_GET['analyzeField'][3], $file);
                                break;
                            case 4:
                                $analyze->erwei1('123', $_GET['year'], $_GET['analyzeField'][0], $_GET['analyzeField'][1], $_GET['analyzeField'][2], $_GET['analyzeField'][3], $file);
                                break;
                            case 5:
                                $analyze->erwei1('123', $_GET['year'], $_GET['analyzeField'][0], $_GET['analyzeField'][1], $_GET['analyzeField'][2], $_GET['analyzeField'][3], $_GET['analyzeField'][4], $file);
                                break;
                            case 6:
                                $analyze->erwei1('123', $_GET['year'], $_GET['analyzeField'][0], $_GET['analyzeField'][1], $_GET['analyzeField'][2], $_GET['analyzeField'][3], $_GET['analyzeField'][4], $_GET['analyzeField'][5], $file);
                                break;
                            default :
                                _alert_back('最多选择六个字段');
                                break;
                        }
                    }else{
                        $analyze = new Java('Zxtpjz');
                        switch (count($_GET['analyzeField'])) {
                            case 0:
                                _alert_info('请选择至少一个字段');
                                break;
                            case 1:
                                $analyze->zhexian1('123', $_GET['year'], $_GET['analyzeField'][0], $file);
                                break;
                            case 2:
                                $analyze->zhexian1('123', $_GET['year'], $_GET['analyzeField'][0], $_GET['analyzeField'][1], $file);
                                break;
                            case 3:
                                $analyze->zhexian1('123', $_GET['year'], $_GET['analyzeField'][0], $_GET['analyzeField'][2], $_GET['analyzeField'][3], $file);
                                break;
                            case 4:
                                $analyze->zhexian1('123', $_GET['year'], $_GET['analyzeField'][0], $_GET['analyzeField'][1], $_GET['analyzeField'][2], $_GET['analyzeField'][3], $file);
                                break;
                            case 5:
                                $analyze->zhexian1('123', $_GET['year'], $_GET['analyzeField'][0], $_GET['analyzeField'][1], $_GET['analyzeField'][2], $_GET['analyzeField'][3], $_GET['analyzeField'][4], $file);
                                break;
                            case 6:
                                $analyze->zhexian1('123', $_GET['year'], $_GET['analyzeField'][0], $_GET['analyzeField'][1], $_GET['analyzeField'][2], $_GET['analyzeField'][3], $_GET['analyzeField'][4], $_GET['analyzeField'][5], $file);
                                break;
                            default :
                                _alert_back('最多选择六个字段');
                                break;
                        }
                    }

                   // $analyze->erwei1('123',2014,'wd',"ws","rh",$file);
                }elseif ($_SESSION['tableName']=='runofftable') {
                    if($_GET['analyzeFieldItem']=='histogram') {
                        $analyze = new Java('Erweitj');
                        // Erweitj.erwei1("123","2014","wd","ws","rh","E:\\123.jpg");
                        switch (count($_GET['analyzeField'])) {
                            case 0:
                                _alert_info('请选择至少一个字段');
                                break;
                            case 1:
                                $analyze->erwei2('123', $_GET['year'], $_GET['analyzeField'][0], $file);
                                break;
                            case 2:
                                $analyze->erwei2('123', $_GET['year'], $_GET['analyzeField'][0], $_GET['analyzeField'][1], $file);
                                break;
                            case 3:
                                $analyze->erwei2('123', $_GET['year'], $_GET['analyzeField'][0], $_GET['analyzeField'][2], $_GET['analyzeField'][3], $file);
                                break;
                            case 4:
                                $analyze->erwei2('123', $_GET['year'], $_GET['analyzeField'][0], $_GET['analyzeField'][1], $_GET['analyzeField'][2], $_GET['analyzeField'][3], $file);
                                break;
                            case 5:
                                $analyze->erwei2('123', $_GET['year'], $_GET['analyzeField'][0], $_GET['analyzeField'][1], $_GET['analyzeField'][2], $_GET['analyzeField'][3], $_GET['analyzeField'][4], $file);
                                break;
                            case 6:
                                $analyze->erwei2('123', $_GET['year'], $_GET['analyzeField'][0], $_GET['analyzeField'][1], $_GET['analyzeField'][2], $_GET['analyzeField'][3], $_GET['analyzeField'][4], $_GET['analyzeField'][5], $file);
                                break;
                            default :
                                _alert_back('最多选择六个字段');
                                break;
                        }
                    }else{
                        $analyze = new Java('Zxtpjz');
                        switch (count($_GET['analyzeField'])) {
                            case 0:
                                _alert_info('请选择至少一个字段');
                                break;
                            case 1:
                                $analyze->zhexian2('123', $_GET['year'], $_GET['analyzeField'][0], $file);
                                break;
                            case 2:
                                $analyze->zhexian2('123', $_GET['year'], $_GET['analyzeField'][0], $_GET['analyzeField'][1], $file);
                                break;
                            case 3:
                                $analyze->zhexian2('123', $_GET['year'], $_GET['analyzeField'][0], $_GET['analyzeField'][2], $_GET['analyzeField'][3], $file);
                                break;
                            case 4:
                                $analyze->zhexian2('123', $_GET['year'], $_GET['analyzeField'][0], $_GET['analyzeField'][1], $_GET['analyzeField'][2], $_GET['analyzeField'][3], $file);
                                break;
                            case 5:
                                $analyze->zhexian2('123', $_GET['year'], $_GET['analyzeField'][0], $_GET['analyzeField'][1], $_GET['analyzeField'][2], $_GET['analyzeField'][3], $_GET['analyzeField'][4], $file);
                                break;
                            case 6:
                                $analyze->zhexian2('123', $_GET['year'], $_GET['analyzeField'][0], $_GET['analyzeField'][1], $_GET['analyzeField'][2], $_GET['analyzeField'][3], $_GET['analyzeField'][4], $_GET['analyzeField'][5], $file);
                                break;
                            default :
                                _alert_back('最多选择六个字段');
                                break;
                        }
                    }

                    // $analyze->erwei1('123',2014,'wd',"ws","rh",$file);
                } elseif ($_SESSION['tableName']=='fwtable') {
                    if($_GET['analyzeFieldItem']=='histogram') {
                        $analyze = new Java('Erweitj');
                        // Erweitj.erwei1("123","2014","wd","ws","rh","E:\\123.jpg");
                        switch (count($_GET['analyzeField'])) {
                            case 0:
                                _alert_info('请选择至少一个字段');
                                break;
                            case 1:
                                $analyze->erwei3('123', $_GET['year'], $_GET['analyzeField'][0], $file);
                                break;
                            case 2:
                                $analyze->erwei3('123', $_GET['year'], $_GET['analyzeField'][0], $_GET['analyzeField'][1], $file);
                                break;
                            case 3:
                                $analyze->erwei3('123', $_GET['year'], $_GET['analyzeField'][0], $_GET['analyzeField'][2], $_GET['analyzeField'][3], $file);
                                break;
                            case 4:
                                $analyze->erwei3('123', $_GET['year'], $_GET['analyzeField'][0], $_GET['analyzeField'][1], $_GET['analyzeField'][2], $_GET['analyzeField'][3], $file);
                                break;
                            case 5:
                                $analyze->erwei3('123', $_GET['year'], $_GET['analyzeField'][0], $_GET['analyzeField'][1], $_GET['analyzeField'][2], $_GET['analyzeField'][3], $_GET['analyzeField'][4], $file);
                                break;
                            case 6:
                                $analyze->erwei3('123', $_GET['year'], $_GET['analyzeField'][0], $_GET['analyzeField'][1], $_GET['analyzeField'][2], $_GET['analyzeField'][3], $_GET['analyzeField'][4], $_GET['analyzeField'][5], $file);
                                break;
                            default :
                                _alert_back('最多选择六个字段');
                                break;
                        }
                    }else{
                        $analyze = new Java('Zxtpjz');
                        switch (count($_GET['analyzeField'])) {
                            case 0:
                                _alert_info('请选择至少一个字段');
                                break;
                            case 1:
                                $analyze->zhexian3('123', $_GET['year'], $_GET['analyzeField'][0], $file);
                                break;
                            case 2:
                                $analyze->zhexian3('123', $_GET['year'], $_GET['analyzeField'][0], $_GET['analyzeField'][1], $file);
                                break;
                            case 3:
                                $analyze->zhexian3('123', $_GET['year'], $_GET['analyzeField'][0], $_GET['analyzeField'][2], $_GET['analyzeField'][3], $file);
                                break;
                            case 4:
                                $analyze->zhexian3('123', $_GET['year'], $_GET['analyzeField'][0], $_GET['analyzeField'][1], $_GET['analyzeField'][2], $_GET['analyzeField'][3], $file);
                                break;
                            case 5:
                                $analyze->zhexian3('123', $_GET['year'], $_GET['analyzeField'][0], $_GET['analyzeField'][1], $_GET['analyzeField'][2], $_GET['analyzeField'][3], $_GET['analyzeField'][4], $file);
                                break;
                            case 6:
                                $analyze->zhexian3('123', $_GET['year'], $_GET['analyzeField'][0], $_GET['analyzeField'][1], $_GET['analyzeField'][2], $_GET['analyzeField'][3], $_GET['analyzeField'][4], $_GET['analyzeField'][5], $file);
                                break;
                            default :
                                _alert_back('最多选择六个字段');
                                break;
                        }
                    }
                    // $analyze->erwei1('123',2014,'wd',"ws","rh",$file);
                }
                if ($_GET['analyzeFieldItem'] == 'histogram') {

                    /*echo '<img alt="test" src="$_COOKIE["username"]'.'/binzhuangtu.jpg'.'"/>';*/
                    ?>
                    <img alt="test" src="<?php echo $_COOKIE["username"] . $filePart; ?>"/>
                    <?php


                } elseif ($_GET['analyzeFieldItem'] == 'line') {
                    /*  echo '<img alt="test" src="$_COOKIE["username"]'.'/tiaoxintu.jpg'.'"/>';*/
                    ?>
                    <img alt="test" src="<?php echo $_COOKIE["username"] . $filePathPart; ?>"/>
                    <?php

                }
            }else{
                echo '<p class="analyzeTitle" style="font-size: 22px;font-weight: bolder">'.$_SESSION['tableCh'].'表 '.$_GET['firstdatetime'].'--'.$_GET['seconddatetime'].'间'.winDisplay($_GET['analyzeField']).'的统计信息'.'</p>';
                if($_SESSION['tableName']=='attable'){
                    //echo 0;
                    // echo $_GET['analyzeField'];
                    if($_GET['analyzeField']=='aaat'){
                        //  echo 1;
                        $analyze=new Java('JavaSuccess');
                        $analyze->Canshuchuandi22('222',$_GET['firstdatetime'],$_GET['seconddatetime'],$_GET['analyzeField'],$file,$filePath);
                    }elseif ($_GET['analyzeField']=='aminat'){
                        //  echo 2;
                        $analyze=new Java('JavaSuccess');
                        $analyze->Canshuchuandi23('222',$_GET['firstdatetime'],$_GET['seconddatetime'],$_GET['analyzeField'],$file,$filePath);
                    }elseif ($_GET['analyzeField']=='amaxat'){
                        //echo 3;
                        $analyze=new Java('JavaSuccess');
                        $analyze->Canshuchuandi21('222',$_GET['firstdatetime'],$_GET['seconddatetime'],$_GET['analyzeField'],$file,$filePath);
                    }elseif ($_GET['analyzeField']=='aec'){
                        //echo 2;
                        $analyze=new Java('JavaSuccess');
                        $analyze->Canshuchuandi24('222',$_GET['firstdatetime'],$_GET['seconddatetime'],$_GET['analyzeField'],$file,$filePath);
                    }
                }elseif($_SESSION['tableName']=='wltable'){
                    //echo $_GET['analyzeField'];
                    if($_GET['analyzeField']=='wl'){
                        $analyze=new Java('JavaSuccess');
                        $analyze->Canshuchuandi2('222',$_GET['firstdatetime'],$_GET['seconddatetime'],$_GET['analyzeField'],$file,$filePath);
                    }
                }elseif($_SESSION['tableName']=='zxctable') {
                    // echo $_GET['analyzeField'];
                    if ($_GET['analyzeField'] == 'tnoh') {
                        $analyze = new Java('JavaSuccess');
                        $analyze->Canshuchuandi41('222', $_GET['firstdatetime'], $_GET['seconddatetime'], $_GET['analyzeField'], $file, $filePath);
                    } elseif ($_GET['analyzeField'] == 'bir') {
                        $analyze = new Java('JavaSuccess');
                        $analyze->Canshuchuandi42('222', $_GET['firstdatetime'], $_GET['seconddatetime'], $_GET['analyzeField'], $file, $filePath);
                    } elseif ($_GET['analyzeField'] == 'dea') {//死亡人数
                        $analyze = new Java('JavaSuccess');
                        $analyze->Canshuchuandi43('222', $_GET['firstdatetime'], $_GET['seconddatetime'], $_GET['analyzeField'], $file, $filePath);
                    } elseif ($_GET['analyzeField'] == 'ngp') {//自然增长人数
                        //echo $_GET['analyzeField'];
                        $analyze = new Java('JavaSuccess');
                        $analyze->Canshuchuandi44('222', $_GET['firstdatetime'], $_GET['seconddatetime'], $_GET['analyzeField'], $file, $filePath);
                    }
                }elseif($_SESSION['tableName']=='hydraulictable') {
                    //echo $_GET['analyzeField'];
                    if ($_GET['analyzeField'] == 'precipitation') {
                        $analyze = new Java('JavaSuccess');
                        $analyze->Canshuchuandi31('222', $_GET['firstdatetime'], $_GET['seconddatetime'], $_GET['analyzeField'], $file, $filePath);
                    } elseif ($_GET['analyzeField'] == 'avgflow') {
                        $analyze = new Java('JavaSuccess');
                        $analyze->Canshuchuandi32('222', $_GET['firstdatetime'], $_GET['seconddatetime'], $_GET['analyzeField'], $file, $filePath);
                    }
                }
                    if ($_GET['analyzeFieldItem'] == 'histogram') {

                        /*echo '<img alt="test" src="$_COOKIE["username"]'.'/binzhuangtu.jpg'.'"/>';*/
                        ?>
                        <img alt="test" src="<?php echo $_COOKIE["username"] . $filePart; ?>"/>
                        <?php


                    } elseif ($_GET['analyzeFieldItem'] == 'pie') {
                        /*  echo '<img alt="test" src="$_COOKIE["username"]'.'/tiaoxintu.jpg'.'"/>';*/
                        ?>
                        <img alt="test" src="<?php echo $_COOKIE["username"] . $filePathPart; ?>"/>
                        <?php

                    }
                }
            }
            ?>
        </div>



    </div>
<?php }?>

<?php
require_once("includes/dbFieldStatisticalOperate.php");
?>






</div>
<?php require_once('includes/footer.inc.php');?>
<script type="text/javascript" src="js/<?php echo SCRIPT?>.js"></script>

</body>
</html>
