<?php
/**
 * TestGuest Version1.0
 * ================================================
 * Copy 2010-2012 yc60
 * Web: http://www.yc60.com
 * ================================================
 * Author: Lee
 * Date: 2010-9-2
 */
header("Content-Type:text/html;charset=utf-8");
header("Cache-Control: no-cache");
session_start();
require_once("http://localhost:8080/JavaBridgeTemplate611/java/Java.inc");
/*$batchImport = new Java("ImportWQMxlsToDB");
$batchImport->exe();*/


if($_SESSION['authority']==1 ||$_SESSION['authority']==2) {
    if ($_SESSION['department'] == "水文") {
        $batchImport = new Java("ImportHDxlsToDB");
        $batchImport->exe();
        //echo "quite";
    } elseif($_SESSION['department']=='气象' ) {
        $batchImport = new Java("ImportATxlsToDB");
        $batchImport->exe();
    }elseif($_SESSION['department']=='环保') {
        $batchImport = new Java("ImportWQMxlsToDB");
        $batchImport->exe();
    } elseif($_SESSION['department']=='统计') {
        $batchImport = new Java("ImportZXCxlsToDB");
        $batchImport->exe();
    } elseif($_SESSION['department']=='农调') {
        $batchImport = new Java("ImportRPCIxlsToDB");
        $batchImport->exe();
    }

}

?>
