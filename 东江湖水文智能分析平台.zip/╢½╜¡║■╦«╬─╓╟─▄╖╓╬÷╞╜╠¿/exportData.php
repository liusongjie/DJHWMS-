<?php
/**
 * TestGuest Version1.0
 * ================================================
 * Copy 2010-2012 yc60
 * Web: http://www.yc60.com
 * ================================================
 * Author: Lee
 * Date: 2010-9-2
 */
header("Content-Type:text/html;charset=utf-8");
header("Cache-Control: no-cache");
require_once("http://localhost:8080/JavaBridgeTemplate611/java/Java.inc");

session_start();
if($_SESSION['authority']==1 ||$_SESSION['authority']==2) {
    if ($_SESSION['tableCh'] == "水文信息") {
        $export = new Java("ExportDBToHdxls");
        $export->exe();
       // echo "quite";
    } elseif($_SESSION['department'] == "气象") {
        $export = new Java("ExportDBToATxls");
        $export->exe();
    }elseif($_SESSION['department'] == "环保") {
        $export = new Java("ExportDBToWQMxls");
        $export->exe();
    }elseif($_SESSION['department'] == "统计") {
        $export = new Java("ExportDBToZXCxls");
        $export->exe();
    }elseif($_SESSION['department'] == "农调") {
        $export = new Java("ExportDBToRPCIxls");
        $export->exe();
    }

}
?>
