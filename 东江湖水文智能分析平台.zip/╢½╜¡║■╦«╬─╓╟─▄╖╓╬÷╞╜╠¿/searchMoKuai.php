<?php
/**
 * Created by PhpStorm.
 * User: hetong
 * Date: 2016/9/25
 * Time: 13:56
 */?>
<div id="mainUp">
    <h2 id="operateTitle"><strong><?php echo $_SESSION['tableCh']?>数据库查询操作</strong></h2>

    <form method="get" action="?action=search">
        <!--<div class="ziduanzhiyue" id="ziduanzhiyue">--><span class="title2">数据约束条件选择: </span>


        <ul>
            <?php
            $i=0;
            //echo $sql;
            //echo $_SESSION['tableName'];
            foreach ($fields as $field){
                /*   $strSql1=<<<EOF
         SELECT {$field['attname']} FROM {$_SESSION['tableName']} WHERE {$field['attname']}=max('{$field['attname']}')
         EOF;*/
                $strSql1=<<<EOF
SELECT {$field['attname']} FROM {$_SESSION['tableName']} WHERE {$field['attname']}=(select min({$field['attname']}) 
                from {$_SESSION['tableName']}) 
EOF;
                // echo $strSql1;
                $minResult=pg_query($strSql1);
                $mins=pg_fetch_assoc($minResult);
                $min=$mins[$field['attname']];
                //echo $min;
                $strSql2=<<<EOF
SELECT {$field['attname']} FROM {$_SESSION['tableName']} WHERE {$field['attname']}=(select max({$field['attname']}) 
                from {$_SESSION['tableName']}) 
EOF;
                // echo $strSql2;
                $maxResult=pg_query($strSql2);
                $maxs=pg_fetch_assoc($maxResult);
                $max=$maxs[$field['attname']];
                //echo $max;



                ?>
                <li><span class="searchInfo"><?php echo winDisplay($field['attname'])?>(最小:<?php echo $min;?>;最大:<?php echo $max;?>):</span>
                    <span class="searchInput"> 从<input type="text" class="searchInput" name="<?php echo 'first'.$field['attname']?>" value="<?php echo $min;?>"/>到<input class="searchInput" type="text" name="<?php echo 'second'.$field['attname']?>" value="<?php echo $max;?>"/></span>
                </li>
                <?php
                $i++;
                if($i%3==0 && $i!=0){
                    /*echo '<br/>';*/
                }
            }?>
        </ul>


        <!--<div class="xianshiziduan" id="xianshiziduan">--><span  class="title2">数据显示字段选择:</span>
        <ul id="displaySelect" class="displaySelect">
            <?php foreach ($fields as $field){?>
                <li class="displaySelect"><input class="searchSimpleInput" type="checkbox" name="displays[]" id="<?php echo $field['attname']?>" value="<?php echo winDisplay($field['attname'])?>" />
                    <label for="<?php echo $field['attname']?>"><?php echo winDisplay($field['attname'])?></label>
                    <input type="hidden" name="<?php echo $field['attname']?>" value="<?php echo winDisplay($field['attname'])?>" />
                </li>
                <!--<td><input type="checkbox" name="displays[]" id="date" value="日期" />
              <label for="date">日期</label></td>
                <td><input type="checkbox" name="displays[]" id="precipitation" value="降雨量" />
              <label for="precipitation">降雨量</label></td>
                <td><input type="checkbox" name="displays[]" id="flow" value="平局流量" />
              <label for="flow">平均流量</label></td>-->
            <?php } ?>
            <li class="displayBatch"><input class="searchSimpleInput" type="checkbox" name="displayAll" id="displayAll"  />
                <label for="displayAll">全选</label>
                <input type="checkbox" class="searchSimpleInput" name="displayReverse" id="displayReverse"  />
                <label for="displayReverse">反选</label>
            </li>

        </ul>
        <ul class="submit">
            <li>
                <input type="submit" value="开始查询">
            </li>
        </ul>

    </form>
</div>
