﻿<?php
/*error_reporting(E_ALL);
ignore_user_abort(true);
set_time_limit(0);*/
//ob_implicit_flush();
$i=1;
for (;$i<200;$i++) {
    /*if (!empty($_SERVER['REMOTE_ADDR']) && isset($_COOKIE['username'])){
        echo $_SERVER['REMOTE_ADDR'];
        file_put_contents('test.log', "在线\r\n",FILE_APPEND);
    }elseif ($_SERVER['REMOTE_ADDR']==NULL){
        echo $_SERVER['REMOTE_ADDR'];
        file_put_contents('test.log', "BU正常退出\r\n",FILE_APPEND);
    }else{
        echo '不在线';
        file_put_contents('test.log', "不在线\r\n",FILE_APPEND);
    }*/
    if (isset($_COOKIE['username'])){
        echo 11;
    }else{
        //echo $_SERVER['REMOTE_ADDR'];
        echo 22;
    }/*//11111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111
 只会是111...或222...,不可能是11..22尽管其他页面改变了$_cookie['username'];*/
    /*file_put_contents('test.log', $i++.$_COOKIE['username']."\r\n",FILE_APPEND);
    if (isset($_COOKIE['username'])){
        echo 11$_SERVER['REMOTE_ADDR'];
        file_put_contents('test.log', "在线\r\n",FILE_APPEND);
    }else{
        //echo $_SERVER['REMOTE_ADDR'];
        file_put_contents('test.log', "不在线\r\n",FILE_APPEND);

    }*/
    sleep(1);
}
/*1
不在线
91
不在线
2
不在线
92
不在线
3
不在线
93
不在线
4
不在线
94
不在线
5
不在线
95
不在线
6
不在线
96
不在线
7
不在线
97
不在线
8
不在线
98
不在线
9
不在线
99
不在线
10
不在线
100
不在线
11
不在线
101
不在线
12
不在线
102
不在线
13
不在线
103
不在线
14
不在线
104
不在线
15
不在线
105
不在线
16
不在线
106
不在线
17
不在线
107
不在线
18
不在线
108
不在线
19
不在线
109
不在线*/
//得到的结果全是不在线，isset($_COOKIE['username'])对比 connection_status() . "abort:" . connection_aborted()推测两者的机制不同，isset($_COOKIE['username'])同一个页面初次遇到$_COOKIE['username']时，就得到isset($_COOKIE['username'])的结果，其他地方如登录导致cookie变化了，但是本页面得到的结果还是为空，尽管$_COOKIE['username']是全局变量，但connection_status()根据页面是否关闭却得到了不同结果

/*//去掉ajax登录前访问一次ipInspect.php
1
不在线
2
不在线
3
不在线
4
不在线
5
不在线
6
不在线
7
不在线
8

/去掉ajax登录后访问一次ipInspect.php==》这时有两个ipInspect在工作，一个cookie仍旧是没值的，一个有值所以1.在ajax页面慎用cookie，session等全局变量2.小心无线运行的页面，其中全局变量的值似乎并没有随着时间变化，只能是重新访问，或者刷新才变化，仔细想想似乎也对,第一次访问IpInspect时，初始化了$_cookie['username'];之后一直运行的都是这个页面，没有刷新，就获取不到全局变量的变化，即要得到全局变量的变化通常都是跳转，刷新，才能得到，在同一个页面，不刷新的话，是不会有改变的，
重心：要得到全局变量的变化，只能刷新，重置，ajax等，一个页面不刷新，哪怕有循环判断，且全局变量在其他地方变化了，循环采用的也是最初获取的值
==>全局变量在一个页面如果没有显示变化，也只被初始化一次，要想得到变化值除非显示改变或者刷新页面
30strrev
在线
62
不在线
31strrev
在线
63
不在线
32strrev
在线
64
不在线
33strrev
在线
65
不在线
34strrev
在线
66
不在线
35strrev
在线
67
不在线
36strrev
在线
68
不在线
37strrev
在线
69
不在线
38strrev
在线
70
不在线
39strrev*/


?>