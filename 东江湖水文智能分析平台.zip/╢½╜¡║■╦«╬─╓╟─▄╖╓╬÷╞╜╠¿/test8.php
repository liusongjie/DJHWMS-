<!DOCTYPE html>
<html>
<head>
    <script>
        function goodbye()
        {
            alert("感谢您访问 W3School!");
        }
    </script>
</head>

<body onunload="goodbye()">

<h1>欢迎访问我的首页</h1>
<p>请关闭窗口，或按 F5 刷新页面。</p>

</body>
</html>
