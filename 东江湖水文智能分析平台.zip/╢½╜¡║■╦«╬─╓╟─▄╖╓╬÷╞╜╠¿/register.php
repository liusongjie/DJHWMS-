﻿<?php
/**
* TestGuest Version1.0
* ================================================
* Copy 2010-2012 yc60
* Web: http://www.yc60.com
* ================================================
* Author: Lee
* Date: 2010-8-11
*/

session_start();
//定义个常量，用来授权调用includes里面的文件
define('IN_TG',true);
//定义个常量，用来指定本页的内容
define('SCRIPT','register');
//引入公共文件
require dirname(__FILE__).'/includes/common.inc.php';

/*var_dump($_POST['visitable']);
exit(1);*/
//提取所有部门
/*$deSql=<<<EOF
SELECT a.attname, a.attnotnull as notnull FROM pg_class as c,pg_attribute as a  where c.relname = 'djhuser' and a.attrelid = c.oid and a.attnum>13
EOF;
$deSql=pg_query($deSql);
$departments=array();
while($drow=pg_fetch_assoc($deSql)){
	$departments[]=$drow['attname'];
	echo $drow['attname'];
}*/

//exit(1);
//登录状态
//_login_state();
global $_system;
//判断是否提交了
if ($_GET['action'] == 'register') {
	if (empty($_system['register'])) {
		exit('不要非法注册！');
	}
	//为了防止恶意注册，跨站攻击
	//_check_code($_POST['code'],$_SESSION['code']);
	//引入验证文件
	include ROOT_PATH.'includes/check.func.php';
	//创建一个空数组，用来存放提交过来的合法数据
	$_clean = array();
	//可以通过唯一标识符来防止恶意注册，伪装表单跨站攻击等。
	//这个存放入数据库的唯一标识符还有第二个用处，就是登录cookies验证
//	$_clean['uniqid'] = _check_uniqid($_POST['uniqid'],$_SESSION['uniqid']);
	//active也是一个唯一标识符，用来刚注册的用户进行激活处理，方可登录。
//	$_clean['active'] = _sha1_uniqid();
	$_clean['username'] = _check_username($_POST['username'],2,20);
	//$_clean['password'] = _check_password($_POST['password'],$_POST['notpassword'],6);
	$_clean['mobile'] =_check_mobile($_POST['mobile']);
	$_clean['department'] =$_POST['department'];
	$_clean['email'] = _check_email($_POST['email'],6,40);
	//可访问部门不能为空
	if(empty($_POST['visitable'])){
		_alert_back('请选择可读部门');
	}
	//处理图片和文件
	$_imgs = array('image/jpeg','image/pjpeg','image/png','image/x-png','image/gif');

	//判断类型是否是数组里的一种
	if (is_array($_imgs)) {
		if (!in_array($_FILES['userimg']['type'],$_imgs)) {
			_alert_back('上传图片必须是jpg,png,gif中的一种！');
		}
	}

	//判断文件错误类型
	if ($_FILES['user']['error'] > 0) {
		switch ($_FILES['userimg']['error']) {
			case 1: _alert_back('上传文件超过约定值1');
				break;
			case 2: _alert_back('上传文件超过约定值2');
				break;
			case 3: _alert_back('部分文件被上传');
				break;
			case 4: _alert_back('没有任何文件被上传！');
				break;
		}
		exit;
	}

	//判断配置大小
	if ($_FILES['userimg']['size'] > 1000000) {
		_alert_back('上传的文件不得超过1M');
	}

	//获取文件的扩展名 1.jpg
	$newImg=strrev($_FILES['userimg']['name']);
	$_n = explode('.',$newImg);
	$imgName = ROOT_PATH.'userdata'.'/'.$_clean['username'].'.'.strrev($_n[0]);


	//移动文件
	if (is_uploaded_file($_FILES['userimg']['tmp_name'])) {
		if	(!@move_uploaded_file($_FILES['userimg']['tmp_name'],$imgName)) {
			_alert_back('移动失败');
		} else {
			//_alert_close('上传成功！');
			echo "<script>alert('证明图片上传成功！');</script>";
			//exit();
		}
	} else {
		_alert_back('上传的临时文件不存在！');
	}
//上传验证文档
	//设置上传图片的类型
	/*echo 1;
	echo $_FILES['userfile']['type'];
	//判断类型是否是数组里的一种
	echo 2;*/
	//获取文件的扩展名 1.jpg
	$_n= explode('.',strrev($_FILES['userfile']['name']));
	$fileName = ROOT_PATH.'userdata1'.'/'.$_clean['username'].'.'.strrev($_n[0]);
	if (!in_array(strrev($_n[0]),$_system['fileType'])) {
		_alert_back('上传文档必须是doc格式！');
	}
	//判断文件错误类型
	if ($_FILES['userfile']['error'] > 0) {
		switch ($_FILES['userfile']['error']) {
			case 1: _alert_back('上传文件超过约定值1');
				break;
			case 2: _alert_back('上传文件超过约定值2');
				break;
			case 3: _alert_back('部分文件被上传');
				break;
			case 4: _alert_back('没有任何文件被上传！');
				break;
		}
		exit;
	}

	//判断配置大小
	if ($_FILES['userfile']['size'] > 1000000) {
		_alert_back('上传的文件不得超过1M');
	}
	//移动文件
	if (is_uploaded_file($_FILES['userfile']['tmp_name'])) {
		if	(!@move_uploaded_file($_FILES['userfile']['tmp_name'],$fileName)) {
			_alert_back('移动失败');
		} else {
			//_alert_close('上传成功！');
			echo "<script>alert('证明文档上传成功！');</script>";
			//exit();
		}
	} else {
		_alert_back('上传的临时文件不存在！');
	}


	//将用户数据写到数据库
	//在新增之前，要判断用户名是否重复
	$repeatSql=<<<EOF
SELECT username FROM djhuser WHERE username='{$_clean['username']}'  LIMIT 1;
EOF;

/*ECHO $repeatSql;
	exit();*/
	_is_repeat(
		$repeatSql,
		'对不起，此用户已被注册'
	);


	//echo $_clean['department'];
	//新增用户  //在双引号里，直接放变量是可以的，比如$_username,但如果是数组，就必须加上{} ，比如 {$_clean['username']}
	$insertSql=<<<EFO
INSERT INTO djhuser (
								username,
								password,
								mobile,
								authority,
								loginstate,
								logincount,
								lasttime,								
								lastip,
								email,
								userimg,
								userfile,
								active,
								registertime,
								usable
								)
				VALUES (
								'{$_clean['username']}',
								NULL,
								'{$_clean['mobile']}',
								0,
								false,
								0,
								now(),
								'{$_SERVER["REMOTE_ADDR"]}',
								'{$_POST['email']}',
								lo_import('{$imgName}'),
								lo_import('{$fileName}'),
								false,
								now(),
								true
								)
EFO;
/*echo $insertSql;
	exit();*/
	$insertResult=_query($insertSql);
	//echo pg_affected_rows($insertResult);
	if (pg_affected_rows($insertResult) == 1) {
		/*//获取刚刚新增的ID
		$_clean['id'] = _insert_id();*/
		//_session_destroy();



		//生成XML
		//_set_xml('new.xml',$_clean);
		//setcookie('username',$_clean['username']);
		//_location(SCRIPT.'.php');
		//更新所在部门的权限

		function updateDeAu($arr,$authority,$user){
			$part='';
			foreach ($arr as $value){
				$part.=$value.'='.$authority.',';

				}
				$newPart=substr($part,0,-1);
			$updateSql=<<<EOF
UPDATE djhuser SET {$newPart} WHERE username='{$user}'
EOF;
			pg_query($updateSql);
		}
		updateDeAu($_POST['visitable'],'1',$_clean['username']);
		updateDeAu($_POST['operatable'],'2',$_clean['username']);
		/*if($rows['authority']==1){
			$_SESSION['authority']=1;
			$_SESSION['superUser']=$_clean['username'];
		}elseif($rows['authority']==2){
			$_SESSION['authority']=2;
			$_SESSION['admin']=$_clean['username'];
		}*/
		//记录用户所属部门
		$_SESSION['department']=$_clean['department'];
		pg_close();

		_location('恭喜你，注册成功,请等待管理员激活！','index.php');
	} else {
		_close();
		//_session_destroy();
		_location('很遗憾，注册失败！请重新注册','register.php');
	}

}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title><?php echo '湖南省郴州东江湖水资源管理'?></title>
	<link rel="shortcut icon" href="dongjianghu.ico" />
	<style type="text/css">
		#register {
			width: 96%;
			height: 600px;
			z-index: 1;
			margin-top: 15px;
			margin-right: 15px;
			margin-bottom: 10px;
			margin-left: 15px;
			background-color: #FFF;
			border-radius: 8px;
			font-size: 18px;
			text-algin: center;
			padding: 10px;
			overflow: auto;
		}
		#selectDB h2 strong {
			font-weight: bold;
			color: #36C;
		}

		#register #operateTitle {
			height: 30px;
			border-bottom-width: 2px;
			border-bottom-style: none;
			border-bottom-color: #399;
			vertical-align: middle;
			text-align: center;
		}
		h2 {
			color: #39C;
			font-weight: bold;
			text-align:center;
		}
		h2 {
			color: #36C;
			font-size: 24px;
		}
		.title2 {
			font-size: 18px;
		}
		.title2 {
			font-weight: bold;
			font-size: 22px;
			color: #000;
		}
		#selectDB form table tr {
			height: 20px;
		}
		#register form ul {
			list-style-type: none;
			height:120px;
			width:1300px;
			overflow:auto;
		}
		#register form ul li{

			display:inline-block;
			width:620px;
			height:35px;
		}
		#register form ul li span.searchInfo{
			display:inline-block;
			/*border:red solid 1px;*/
			width:350px;
		}
		#register form ul li span.searchInput{
			width:180px;
		}
		#register form ul input.searchInput{
			width:80px;
		}

		#register form ul.displaySelect{

			height:auto;
			max-height:110px;
			width:1300px;
			overflow:auto;
		}
		#register form ul li.displaySelect{

			display:inline-block;
			width:180px;
			height:35px;
		}
		#register form ul li.displayBatch{

			display:block;
			text-align:center;
			width:1200px;
			height:35px;
		}
		#register form ul.submit{
			text-align:center;
			width:1300px;
			height:75px;
		}
		p .title2 {
			font-size: 20px;
		}
		#register #manageMain p {
			text-align: center;

		}
		#manageMain{
			width: 99%;
			overflow: auto;
		}
		#register {
			height:600px;
			border:2px solid #ccc;
			font-size:12px;
		}
		#register h2 {
			text-indent:0;
			text-align:center;
		}
		#register dl {
			width:630px;
			margin:0 auto;
		}
		#register dl dt {
			text-align:center;
			padding:10px 0;
			font-weight:bold;
		}
		#register dl dd {
			padding:5px 0;
		}
		#register dl dd.face {
			padding:5px 0 5px 120px;
		}
		#register dl dd.face img {
			cursor:pointer;
		}
		#register dl dd input.text {
			width:220px;
			height:19px;
			border:1px solid #333;
			background:#fff;
		}
		#register dl dd input.yzm {
			width:60px;
		}
		#register dl dd input.submit {
		/*	width:60px;
			height:19px;
			border:1px solid #333;
			background:#fff;*/
			cursor:pointer;
			margin:0 0 0 120px;
		}
		#register dl dd img#code {
			position:relative;
			top:8px;
			cursor:pointer;
		}
		#register dl dd select{
			width:170px;
		}#register dl dd select option{
			 width:170px;
		 }
		#register span.necessary{
			color:red;
		}
	</style>

	<script type="text/javascript" src="js/jquery-3.1.0.min.js"></script>

	<link rel="stylesheet" type="text/css" href="js/jQuery-jcDate-master/src/jcDate.css" media="all" />
	<script type="text/javascript" src="js/jQuery-jcDate-master/src/jQuery-jcDate.js" charset="utf-8"></script>
	<script type="text/javascript" src="js/baseManage.inc1.js"></script>
	<link rel="stylesheet" type="text/css" href="templateCss.css"/>

<script type="text/javascript" src="js/code.js"></script>
<script type="text/javascript" src="js/register.js"></script>
</head>
<body>
<?php 
	require ROOT_PATH.'includes/header.inc.php';
?>

<div id="register">
	<h2>系统用户注册</h2>
	<?php if (!empty($_system['register'])) {?>
	<form enctype="multipart/form-data" method="post" name="register" action="register.php?action=register">
		<input type="hidden" name="uniqid" value="<?php //echo $_uniqid ?>" />
		<dl>
			<dt>请认真填写每项内容</dt>
			<dd>用 户 名：<input type="text" name="username" class="text" /> <span class="necessary">(*必填，<?php echo $_system['usernameMinLength'].'--'.$_system['usernameMaxLength'].'位字符'?>)</span></dd>
			<dd>电子邮件：<input type="text" name="email" class="text" /> <span class="necessary">(*必填，激活账户)</span></dd>
			<dd>手机号码：<input type="text" name="mobile" class="text" /> (可选)</dd>
			<input type="hidden" name="MAX_FILE_SIZE" value="1000000" />
			<dd>盖章图片: <input type="file" name="userimg" /><span class="necessary">(*必填，激活账户，类型必须为<?php echo implode(',',$_system['imgType'])?>中的一种)</span></dd>
			<dd>证明文档: <input type="file" name="userfile" /><span class="necessary">(*必填，激活账户，类型必须为<?php echo implode(',',$_system['fileType'])?>)</span></dd>
			<dd>申请只读操作部门：
				<select name="visitable[]" multiple="multiple">
					<?php foreach(array_keys($dbInDp) as $department){ ?>
					<option value="<?php echo $department;?>" ><?php echo departmentCH($department)?></option>

					<?php }?>
				</select><span class="necessary">(*必选，按住ctrl+部门名实现多选)</span>
			</dd>
			<dd>申请读写操作部门：
				<select name="operatable[]" multiple="multiple">
					<?php foreach(array_keys($dbInDp) as $department){ ?>
						<option value="<?php echo $department;?>" ><?php echo departmentCH($department)?></option>

					<?php }?>
					<!--<option value="环保" >环保</option>-->
				</select><span>(可选，按住ctrl+部门名实现多选)</span>
			</dd>
			<!--<dd>验 证 码：<input type="text" name="code" class="text yzm"  /> <img src="code.php" id="code" onclick="javascript:this.src='code.php?tm='+Math.random();" /></dd>-->
			<dd><input type="submit" class="submit" value="注册" /><span>(注册之后请等待管理审核，并用邮箱中收到的密码进行登录)</span></dd>
		</dl>
	</form>
	<?php } else {
		echo '<h4 style="text-align:center;padding:20px;">本站关闭了注册功能！</h4>';
	}?>
</div>

<?php 
	require ROOT_PATH.'includes/footer.inc.php';
?>
</body>
</html>
