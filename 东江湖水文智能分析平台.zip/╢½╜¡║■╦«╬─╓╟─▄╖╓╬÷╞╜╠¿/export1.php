<?php
header("Content-Type:text/html;charset=utf-8");
session_start();
//定义个常量，用来授权调用includes里面的文件
define('IN_TG',true);
//定义个常量，用来指定本页的内容
define('SCRIPT','export1');
//引入公共文件
ob_start();
echo 1;
require dirname(__FILE__).'/dongjianghu7/includes/common.inc.php';


$sql=<<<EOF
SELECT a.attname, a.attnotnull as notnull FROM pg_class as c,pg_attribute as a  where c.relname = '{$_SESSION['tableName']}' and a.attrelid = c.oid and a.attnum>1
EOF;
//echo $sql;
$result=pg_query($sql);
while($row=pg_fetch_assoc($result)){
  $fields[]=$row;
}
if($_GET['action']=='download'){
  if (empty($_SESSION['tableName'])){
    _alert_back('请先选择数据库');
  }
  require_once("http://localhost:8080/JavaBridgeTemplate611/java/Java.inc");
  $file_name=$_COOKIE['username'].'_'.$_SESSION['tableName'].time().'.xls';

  $file_path=ROOT_PATH.'/export/'.$_COOKIE['username'].'_'.$_SESSION['tableName'].time().'.xls';
  $filePath=addslashes($file_path);
 // echo $file_path;
  //exit();
  //$file_path=$file_sub_path.$file_name;
  switch($_SESSION['tableName']){

    case 'zxctable':
      /*$batchImport = new Java("ExportDBToZXCxls");
      $value=$batchImport->exe("C:/software/httpd-2.4.23-x64/Apache/htdocs/dongjianghu7/export/hetong_zxctable1474637312.xls");
      //$value=$batchImport->exe();
      $info=java_values($value);
      echo $info;*/

      $export = new Java("ExportDBToZXCxls");
      $value=$export->exe($filePath);
      //$value=$batchImport->exe();
      $info=java_values($value);
     // echo $info;
      break;
    case 'rpcitable':
      $export = new Java("ExportDBToRPCIxls");
      $value=$export->exe($filePath);
      $info=java_values($value);
   //   echo $info;
      break;
    case 'hydraulictable':
      $export = new Java("ExportDBToHdxls");
      $value=$export->exe($filePath);
      $info=java_values($value);
      break;
    case 'attable':
      $export = new Java("ExportDBToATxls");
      $value=$export->exe($filePath);
      $info=java_values($value);
      break;
    case 'wqmtable':
      $export = new Java("ExportDBToWQMxls");
      $value=$export->exe($filePath);
      $info=java_values($value);
      break;
    case 'ftable':
      $export = new Java("ExportDBToFxls");
      $value=$export->exe($filePath);
      $info=java_values($value);
      break;
    case 'imtable':
      $export = new Java("ExportDBToIMxls");
      $value=$export->exe($filePath);
      $info=java_values($value);
      break;
    case 'lstable':
      $export = new Java("ExportDBTolSxls");
      $value=$export->exe($filePath);
      $info=java_values($value);
      break;
    default:
      break;
  }
 download($file_name,$file_path);
ob_end_flush();
  //从用户库中提取信息
  $userInfoSql=<<<EOF
SELECT lasttime,lastip FROM djhuser WHERE username='{$_COOKIE['username']}'
EOF;
  $infos=pg_fetch_assoc(pg_query($userInfoSql));
  //插入数据库
$upLogSql=<<<EOF
INSERT INTO log (username,tablename,operation,content,ip,logintime) VALUES('{$_COOKIE['username']}','{$_SESSION['tableName']}','{$scToCh[SCRIPT]}','','{$infos['lastime']}','{$infos['lasttime']}')
EOF;
pg_query($upLogSql);
//unlink($filePath);
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

  <title><?php echo '湖南省郴州东江湖水资源管理'?></title>
  <link rel="shortcut icon" href="dongjianghu.ico" />
  <script type="text/javascript" src="js/jquery-3.1.0.min.js"></script>
  <link rel="stylesheet" type="text/css" href="js/jQuery-jcDate-master/src/jcDate.css" media="all" />
  <script type="text/javascript" src="js/jQuery-jcDate-master/src/jQuery-jcDate.js" charset="utf-8"></script>
  <script type="text/javascript" src="js/baseManage.inc1.js"></script>
<link rel="stylesheet" type="text/css" href="templateCss.css"/>
<style type="text/css">

#mainUp form ul {
	list-style-type: none;
	height:120px;
	width:1300px;
	overflow:auto;
}
#mainUp form ul li{

	display:inline-block;
	width:620px;
	height:35px;
}
#mainUp form ul li span.searchInfo{
	display:inline-block;
	/*border:red solid 1px;*/
	width:350px;
}
#mainUp form ul li span.searchInput{
	width:180px;
}
#mainUp form ul input.searchInput{
	width:60px;
	}

#mainUp form ul.displaySelect{

	height:110px;
	width:1300px;
	overflow-y:auto;
	overflow-x:hidden;
}
#mainUp form ul li.displaySelect{

	display:inline-block;
	width:170px;
	height:35px;
}
#mainUp form ul li.displayBatch{

	display:block;
	text-align:center;
	width:1300px;
	height:35px;
}
#mainUp form ul.submit{
	text-align:center;
	width:1300px;
	height:35px;
}
#mainUp form ul.methodSelect{
	height:35px;
	}
#mainUp form ul li.methodSelect{

	display:inline-block;
	width:320px;
	height:35px;
}
#apDiv1 {
	position: absolute;
	left: 1074px;
	top: 381px;
	width: 157px;
	height: 42px;
	z-index: 3;
}
</style>

</head>

<body bgcolor="#cfd4ff">
<?php
require_once("includes/header.inc.php");
require_once("includes/dbSelect.inc.php");
?>

<?php if($_SESSION['mainUpFlag']==1){?>
<div id="mainUp">
  <h2 id="operateTitle"><strong><?php echo $_SESSION['tableCh']?>数据库导出操作</strong></h2>

  <form method="post" action="export1.php?action=download">
 <!-- <span class="title2">数据约束条件选择: </span>-->


<!--    <ul>
      <?php
/*      $i=0;
      //echo $sql;
      //echo $_SESSION['tableName'];
      foreach ($fields as $field){

          $strSql1=<<<EOF
SELECT {$field['attname']} FROM {$_SESSION['tableName']} WHERE {$field['attname']}=(select min({$field['attname']}) 
                from {$_SESSION['tableName']}) 
EOF;
          // echo $strSql1;
          $minResult=pg_query($strSql1);
          $mins=pg_fetch_assoc($minResult);
          $min=$mins[$field['attname']];
          //echo $min;
          $strSql2=<<<EOF
SELECT {$field['attname']} FROM {$_SESSION['tableName']} WHERE {$field['attname']}=(select max({$field['attname']}) 
                from {$_SESSION['tableName']}) 
EOF;
         // echo $strSql2;
          $maxResult=pg_query($strSql2);
          $maxs=pg_fetch_assoc($maxResult);
          $max=$maxs[$field['attname']];
          //echo $max;



          */?>
      <li><span class="searchInfo"><?php /*echo winDisplay($field['attname'])*/?>(最小:<?php /*echo $min;*/?>;最大:<?php /*echo $max;*/?>):</span>
      <span class="searchInput"> 从<input type="text" class="searchInput" name="<?php /*echo 'first'.$field['attname']*/?>" value="<?php /*echo $min;*/?>"/>到<input class="searchInput" type="text" name="<?php /*echo 'second'.$field['attname']*/?>" value="<?php /*echo $max;*/?>"/></span>
      </li>
      <?php
/*        $i++;
        if($i%3==0 && $i!=0){
        }
      }*/?>
    </ul>-->


<!--  <span  class="title2">导出字段选择:</span>
    <ul id="displaySelect" class="displaySelect">
        <?php /*foreach ($fields as $field){*/?>
          <li class="displaySelect"><input class="searchSimpleInput" type="checkbox" name="displays[]" id="<?php /*echo $field['attname']*/?>" value="<?php /*echo winDisplay($field['attname'])*/?>" />
        <label for="<?php /*echo $field['attname']*/?>"><?php /*echo winDisplay($field['attname'])*/?></label>
          <input type="hidden" name="<?php /*echo $field['attname']*/?>" value="<?php /*echo winDisplay($field['attname'])*/?>" />
          </li>
        <?php /*} */?>


    </ul>-->
<!--    <p class="displayBatch" style="text-align: center;"><input class="searchSimpleInput" type="checkbox" name="displayAll" id="displayAll" checked="checked" />
      <label for="displayAll">全选</label>
      <input type="checkbox" class="searchSimpleInput" name="displayReverse" id="displayReverse"   />
      <label for="displayReverse">反选</label>
    </p>-->
    <span  class="title2">导出方式选择:</span>
    <ul class="methodSelect">

      <li class="methodSelect"><input class="methodSelect" type="radio" name="exportMethod"  checked="checked" id="exportMethod1" value="全部导出"  />
        <label for="exportMethod1">全部导出</label></li>
      <li class="methodSelect"><input class="methodSelect" type="radio" name="exportMethod"  id="exportMethod2" value="增量导出" />
        <label for="exportMethod2">增量导出</label></li>
      <li class="methodSelect"><input class="methodSelect" type="radio" name="exportMethod3"
                                      id="exportMethod" value="修改导出"/>
        <label for="exportMethod3">修改导出</label></li>
    </ul>

    <span  class="title2">导出文件格式:</span>
    <ul class="methodSelect">
      <li class="methodSelect"><input class="methodSelect" type="radio" name="fileFormat" checked="checked" id="fileFormat1"   value="excel"  />
        <label for="fileFormat1">excel表(.xls)</label></li>
      <li class="methodSelect"><input class="methodSelect" type="radio" name="fileFormat" id="fileFormat2"   value="postgresql" />
        <label for="fileFormat2">postgresql</label></li>
      <li class="methodSelect"><input class="methodSelect" type="radio" name="fileFormat" id="fileFormat3"   value="doc"/>
        <label for="fileFormat3">doc文档</label></li>
    </ul>
    <span  class="title2">是否压缩:</span>
    <ul class="methodSelect">
      <li class="methodSelect"><input class="methodSelect" type="radio" name="press" id="press"  value="压缩"  />
        <label for="exportMethod">压缩</label></li>
      <li class="methodSelect"><input class="methodSelect" type="radio" name="press" id="press"  value="不压缩" checked="checked" />
        <label for="exportMethod">不压缩</label></li>
    </ul>
    <ul class="submit">
      <li>
        <input type="submit" value="导出">
      </li>
    </ul>

  </form>
</div>
<?php }?>
<?php require_once('includes/footer.inc.php');?>

<script type="text/javascript" src="js/<?php echo SCRIPT?>.js"></script>
</body>
</html>
