<?php
/**
 * Created by PhpStorm.
 * User: hetong
 * Date: 2016/11/8
 * Time: 20:00
 */
header("Content-Type:text/html;charset=utf-8");
session_start();
function winDisplay($parameter)
{
    //echo $parameter;
    $display = '';
    //水文表
    if ($_SESSION['tableName'] == 'hydraulictable') {
        switch ($parameter) {
            case 'id':
                //echo "序号";
                $display = "序号";
                break;
            case 'datetime':
                // echo "日期";
                $display = "日期(格式:xxxx-xx-xx)";
                break;
            //水文
            case 'precipitation':
                // echo "降雨量";
                $display = "降雨量(mm)";
                break;
            case 'avgflow':
                // echo "平均流量";
                $display = "平均流量(m3/s)";
                break;
            default:
                // echo '不存在此字段';
                $display = '不存在此字段';
                break;
        }
        //统计表

    }
    //统计表
    if ($_SESSION['tableName'] == "zxctable") {
        switch ($parameter) {
            case 'id':
                //echo "序号";
                $display = "序号";
                break;
            case 'datetime':
                // echo "日期";
                $display = "年份";
                break;

            //统计
            case 'tnoh':
                // echo "降雨量";
                $display = "总户数";
                break;
            case 'tp':
                // echo "平均流量";
                $display = "合计";
                break;
            case 'mp':
                // echo "降雨量";
                $display = "男";
                break;
            case 'fp':
                // echo "平均流量";
                $display = "女";
                break;
            case 'bir':
                // echo "降雨量";
                $display = "出生人数";
                break;
            case 'bp':
                // echo "降雨量";
                $display = "出生千分率";
                break;
            case 'dea':
                // echo "平均流量";
                $display = "死亡人数";
                break;
            case 'dp':
                // echo "平均流量";
                $display = "死亡千分率";
                break;

            case 'ngp':
                // echo "平均流量";
                $display = "自然增长人数";
                break;

            case 'ngr':
                // echo "平均流量";
                $display = "自然增长千分率";
                break;


            default:
                // echo '不存在此字段';
                $display = '不存在此字段';
                break;
        }
    }
    //环保表
    if ($_SESSION['tableName'] == "wqmtable") {
        switch ($parameter) {
            case 'id':
                //echo "序号";
                $display = "序号";
                break;
            case 'datetime':
                // echo "日期";
                $display = "日期(格式:xxxx-xx-xx)";
                break;
            case 'stname':
                // echo "降雨量";
                $display = "测站名称";
                break;
            case 'riname':
                // echo "平均流量";
                $display = "河流名称";
                break;
            case 'sename':
                // echo "降雨量";
                $display = "断面名称";
                break;
            case 'watercode':
                // echo "平均流量";
                $display = "水期代码";
                break;
            case 'selocation':
                // echo "降雨量";
                $display = "断面位置";
                break;
            case 'watertemp':
                // echo "降雨量";
                $display = "水温(℃)";
                break;
            case 'flow':
                // echo "平均流量";
                $display = "流量";
                break;
            case 'ph':
                // echo "平均流量";
                $display = "pH值";
                break;

            case 'dox':
                // echo "平均流量";
                $display = "溶解氧";
                break;

            case 'codmn':
                // echo "平均流量";
                $display = "CODMn";
                break;

            case 'cod':
                // echo "平均流量";
                $display = "化学需氧量 ";
                break;
            case 'bod':
                // echo "平均流量";
                $display = "BOD5	";
                break;
            case 'an':
                // echo "平均流量";
                $display = "氨氮";
                break;
            case 'tp':
                // echo "平均流量";
                $display = "总磷	";
                break;
            case 'tn':
                // echo "平均流量";
                $display = "总氮	";
                break;
            case 'copper':
                // echo "平均流量";
                $display = "铜";
                break;
            //
            case 'zinc':
                // echo "平均流量";
                $display = "锌";
                break;
            case 'flu':
                // echo "平均流量";
                $display = "氟化物";
                break;
            case 'arsenic':
                // echo "平均流量";
                $display = "砷";
                break;
            case 'mercury':
                // echo "平均流量";
                $display = "汞";
                break;
            case 'cd':
                // echo "平均流量";
                $display = "镉";
                break;
            case 'crvi':
                // echo "平均流量";
                $display = "六价铬	";
                break;
            case 'lead':
                // echo "平均流量";
                $display = "铅";
                break;
            case 'cyanide':
                // echo "平均流量";
                $display = "氰化物";
                break;
            case 'vp':
                // echo "平均流量";
                $display = "挥发酚";
                break;
            case 'petro':
                // echo "平均流量";
                $display = "石油类";
                break;
            case 'las':
                // echo "平均流量";
                $display = "阴离子表面活性剂";
                break;
            case 'sulfide':
                // echo "平均流量";
                $display = "硫化物";
                break;
            case 'wqc':
                // echo "平均流量";
                $display = "水质类别";
                break;
            case 'ti':
                // echo "平均流量";
                $display = "超标项目";
                break;


            default:
                // echo '不存在此字段';
                $display = '不存在此字段';
                break;
        }
    }

    //气象表
    if ($_SESSION['tableName'] == "attable") {
        switch ($parameter) {
            case 'id':
                //echo "序号";
                $display = "序号";
                break;
            case 'datetime':
                // echo "日期";
                $display = "年份";
                break;
            //统计
            case 'arsd':
                // echo "降雨量";
                $display = "年暴雨日数";
                break;
            case 'jan':
                // echo "平均流量";
                $display = "	1月气温(℃)	";
                break;
            case 'feb':
                // echo "降雨量";
                $display = "2月气温(℃)";
                break;
            case 'mar':
                // echo "平均流量";
                $display = "	3月气温(℃)	";
                break;
            case 'apr':
                // echo "降雨量";
                $display = "4月气温(℃)";
                break;
            case 'may':
                // echo "降雨量";
                $display = "	5月气温(℃)";
                break;
            case 'june':
                // echo "平均流量";
                $display = "	6月气温(℃)	";
                break;
            case 'july':
                // echo "平均流量";
                $display = "7月气温(℃)";
                break;

            case 'aug':
                // echo "平均流量";
                $display = "	8月气温(℃)	";
                break;
            case 'sept':
                // echo "平均流量";
                $display = "9月气温(℃)	";
                break;
            case 'oct':
                // echo "平均流量";
                $display = "10月气温(℃)	";
                break;
            case 'nov':
                // echo "平均流量";
                $display = "11月气温(℃)	";
                break;
            case 'dec':
                // echo "平均流量";
                $display = "12月气温(℃)";
                break;
            case 'aaat':
                // echo "平均流量";
                $display = "	年平均气温(℃)";
                break;
            case 'amaxat':
                // echo "平均流量";
                $display = "	年最高气温(℃)	";
                break;
            case 'aminat':
                // echo "平均流量";
                $display = "年最低气温(℃)	";
                break;
            case 'aec':
                // echo "平均流量";
                $display = "年蒸发量";
                break;

            default:
                // echo '不存在此字段';
                $display = '不存在此字段';
                break;
        }
    }
    //农调
    if ($_SESSION['tableName'] == "rpcitable") {
        switch ($parameter) {


            case 'id':
                //echo "序号";
                $display = "序号";
                break;
            case 'datetime':
                // echo "日期";
                $display = "年份";
                break;
            case 'vname':
                // echo "降雨量";
                $display = "乡镇名称	";
                break;
            case 'tnoh':
                // echo "平均流量";
                $display = "总户数（户）";
                break;
            case 'tp':
                // echo "降雨量";
                $display = "	总人口（人）";
                break;
            case 'yeaa':
                // echo "平均流量";
                $display = "	年末耕地面积（亩）";
                break;
            case 'grdp':
                // echo "降雨量";
                $display = "	人均可支配收入（元）";
                break;
            case 'pcdi':
                // echo "降雨量";
                $display = "	国内生产总值（万元）";
                break;
            case 'fai':
                // echo "平均流量";
                $display = "	固定资产投资（万元）";
                break;

            default:
                // echo '不存在此字段';
                $display = '不存在此字段';
                break;
        }
    }
    //畜牧表
    if ($_SESSION['tableName'] == "lstable") {
        switch ($parameter) {
            case 'id':
                //echo "序号";
                $display = "序号";
                break;
            case 'item':
                // echo "日期";
                $display = "项目";
                break;

            //统计
            case 'num':
                // echo "降雨量";
                $display = "数量";
                break;

            default:
                // echo '不存在此字段';
                $display = '不存在此字段';
                break;
        }
    }
    //水位表
    if ($_SESSION['tableName'] == "wltable") {
        switch ($parameter) {
            case 'id':
                //echo "序号";
                $display = "序号";
                break;
            case 'datetime':
                // echo "日期";
                $display = "日期(格式:xxxx-xx-xx)";
                break;

            //统计
            case 'wl':
                $display = '大东江水位(m)';
                break;

            default:
                // echo '不存在此字段';
                $display = '不存在此字段';
                break;
        }
    }
    if ($_SESSION['tableName'] == "tongji") {
        switch ($parameter) {
            case 'id':
                //echo "序号";
                $display = "序号";
                break;
            case 'datetime':
                // echo "日期";
                $display = "日期";
                break;

            //统计
            case 'high':
                $display = '大东江水位(m)';
                break;

            default:
                // echo '不存在此字段';
                $display = '不存在此字段';
                break;
        }
    }
    //移民
    if ($_SESSION['tableName'] == "imtable") {
        switch ($parameter) {
            case 'id':
                //echo "序号";
                $display = "序号";
                break;
            case 'loc':
                // echo "日期";
                $display = "村组别";
                break;

            //统计
            case 'fqp':
                // echo "降雨量";
                $display = "	一季度人口";
                break;
            case 'sqc':
                // echo "平均流量";
                $display = "	二季度变动	";
                break;
            case 'sqs':
                // echo "降雨量";
                $display = "二季度应发";
                break;
            case 'ss':
                // echo "平均流量";
                $display = "	补助金额";
                break;
            case 'res':
                // echo "降雨量";
                $display = "	变动原因";
                break;

            default:
                // echo '不存在此字段';
                $display = '不存在此字段';
                break;
        }
    }
    //财政
    if ($_SESSION['tableName'] == "ftable") {


        switch ($parameter) {
            case 'id':
                //echo "序号";
                $display = "序号";
                break;
            case 'datetime':
                // echo "日期";
                $display = "年度";
                break;

            //统计
            case 'fr':
                // echo "降雨量";
                $display = "财政总收入";
                break;
            case 'ab1':

                // echo "平均流量";
                $display = "	年度预算1";
                break;
            case 'tc1':
                // echo "降雨量";
                $display = "累计完成1	";
                break;

            case 'tcp1':
                // echo "平均流量";
                $display = "为年度预算%1	";
                break;


            case 'tlyidp1':
                // echo "降雨量";
                $display = "比上年±%1	";
                break;
            case 'ct':
                // echo "降雨量";
                $display = "其中：上划中央“两税”	";
                break;
            case 'ab2':
                // echo "平均流量";
                $display = "年度预算2	";
                break;
            case 'tc2':
                // echo "平均流量";
                $display = "累计完成2	";
                break;

            case 'tcp2':
                // echo "平均流量";
                $display = "为年度预算%2	";
                break;

            case 'tlyidp2':
                // echo "平均流量";
                $display = "比上年±%	2";
                break;
            case 'pt':
                // echo "平均流量";
                $display = "上划中省“两个所得税”	";
                break;
            case 'ab3':
                // echo "平均流量";
                $display = "年度预算3";
                break;
            case 'tc3':
                // echo "平均流量";
                $display = "累计完成3	";
                break;
            case 'tcp3':
                // echo "平均流量";
                $display = "为年度预算%3";
                break;
            case 'tlyidp3':
                // echo "平均流量";
                $display = "	比上年±%3	";
                break;
            case 'gbr':
                // echo "平均流量";
                $display = "一般预算收入";
                break;
            case 'ab4':
                // echo "平均流量";
                $display = "	年度预算4";
                break;
            case 'tc4':
                // echo "平均流量";
                $display = "	累计完成4	";
                break;
            case 'tcp4':
                // echo "平均流量";
                $display = "为年度预算%4	";
                break;
            case 'tlyidp4':
                // echo "平均流量";
                $display = "比上年±%4";
                break;

            default:
                // echo '不存在此字段';
                $display = '不存在此字段';
                break;
        }
    }
    if ($_SESSION['tableName'] == "fwtable") {
        switch ($parameter) {
            case 'id':
                //echo "序号";
                $display = "序号";
                break;
            case 'datetime':
                // echo "日期";
                $display = "日期";
                break;
            //统计
            case 'data1':
                // echo "降雨量";
                $display = "数据一";
                break;
            case 'data2':
                // echo "平均流量";
                $display = "数据二";
                break;
            default:
                // echo '不存在此字段';
                $display = '不存在此字段';
                break;
        }
    }
    if ($_SESSION['tableName'] == "runofftable") {
        switch ($parameter) {
            case 'id':
                //echo "序号";
                $display = "序号";
                break;
            case 'datetime':
                // echo "日期";
                $display = "日期(格式:月(两位)/日(两位)/年(两位) x午xx时xx分xx秒),eg:07/31/14 上午10时57分36秒";
                break;
            //统计
            case 'temp':
                // echo "降雨量";
                $display = "温度";
                break;
            case 'event':
                // echo "平均流量";
                $display = "事件(event:ml)";
                break;
            case 'coulperdetached':
                // echo "平均流量";
                $display = "耦合器分离(coulperdetached)";
                break;
            case 'coulperattached':
                // echo "平均流量";
                $display = "耦合器连接(coulperattached)";
                break;
            case 'stopped':
                // echo "平均流量";
                $display = "停止(stopped)";
                break;
            case 'eof':
                // echo "平均流量";
                $display = "结束(eof)";
                break;
            default:
                // echo '不存在此字段';
                $display = '不存在此字段';
                break;
        }
    }
    if ($_SESSION['tableName'] == "metable") {
        switch ($parameter) {
            case 'id':
                //echo "序号";
                $display = "序号";
                break;
            case 'datetime':
                // echo "日期";
                $display = "日期(格式:月(两位)/日(两位)/年(两位) x午xx时xx分xx秒),eg:07/31/14 上午10时57分36秒";
                break;

            case 'pres':
                // echo "降雨量";
                $display = "压强(:kpa)";
                break;
            case 'rain':
                // echo "平均流量";
                $display = "降雨量(:mm)";
                break;
            case 'solar':
                // echo "平均流量";
                $display = "太阳辐射(W/m)";
                break;
            case 'wd':
                // echo "平均流量";
                $display = "风向(Wind Direction?)";
                break;
            case 'ws':
                // echo "平均流量";
                $display = "普通风速(:m/s)";
                break;
            case 'gs':
                // echo "平均流量";
                $display = "狂风风速(:m/s)";
                break;
            case 'temp':
                // echo "平均流量";
                $display = "温度(:℃)";
                break;
            case 'rh':
                // echo "平均流量";
                $display = "RH%";
                break;
            case 'batt':
                // echo "平均流量";
                $display = "电压(:v)";
                break;
            default:
                // echo '不存在此字段';
                $display = '不存在此字段';
                break;
        }
    }
    return $display;
}
pg_connect("host=localhost port=5432 dbname=postgres user=postgres password=123456")
or die("数据库连接失败");
//echo $_POST['select'];

if(isset($_POST['select'])){
    $_SESSION['tableName']=$_POST['select'];
    $sql = <<<EOF
SELECT a.attname, a.attnotnull as notnull FROM pg_class as c,pg_attribute as a  where c.relname = '{$_POST['select']}' and a.attrelid = c.oid and a.attnum>2
EOF;
    $resultField=pg_query($sql);
    $fields=array();
    while($rowsField=pg_fetch_assoc($resultField)){
        $fields[]=$rowsField['attname'];
    }
    //var_dump(  $fields);
    $counSql=<<<eof
SELECT COUNT(*) AS count FROM {$_POST['select']};
eof;
// echo $sql;
    $result=pg_fetch_assoc(pg_query($counSql));
    $count=$result['count'];
}



?>


<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>报表管理系统</title>
</head>
<body>
<br>
<!--第一个div表格-->
<div align="center">

    东江湖智能系统报表查询<br>
    <form name="form1" method="post" action="?lmbs=数据库查询">
        <table  width="685" border="1" cellpadding="1" cellspacing="1" bordercolor="#FFFFFF" bgcolor="#666666">
            <tr>
                <!--第一行-->
                <td colspan="5" bgcolor="#FFFFFF">
                    东江湖智能系统报表查询
                </td>
            </tr>

            <tr >
                <td colspan="2"align="left" bgcolor="#FFFFFF">请选择您需要查询的数据库：</td>
                <td  colspan="2"align="left" width="50px" bgcolor="#FFFFFF"><select name="select" title="1" id="select">
                        <option value="hydraulictable">水文</option>
                        <option value="wqmtable">环保</option>
                        <option value="attable">气象</option>
                        <option value="zxctable">人力</option>
                        <option value="rpcitable">农业</option>
                        <option value="ftable">财政</option>
                        <option value="imtable">移民</option>
                        <option value="wltable">水位</option>
                        <option value="lstable">畜牧</option>
                        <option value="fwtable">测流堰数据</option>
                        <option value="runofftable">径数据</option>
                        <option value="metable">气象站数据</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                    </select>
                </td>
                <td colspan="1"align="center" bgcolor="#FFFFFF"><input type="submit" value="提交" ">      &nbsp;&nbsp;
                    <input type="button" value="重置" onClick="33333content.form5.reset()">
                    &nbsp;&nbsp;
                </td>
            </tr>
        </table>
    </form>
</div>
<!--第一个判断-->
<?php
/*根据选择的数据库返回数据，然后去填充表格,先不用，后面改  */
if(isset($_POST['select']) && $_POST['select']=="hydraulictable"){
   /* $query=<<<EOF
select * from hydraulictable;
EOF;
    $result=pg_query($query);
    $myrow=pg_fetch_assoc($result);
    var_dump($myrow);
    $sql=<<<eof
SELECT COUNT(*) AS count FROM {$_POST['select']};
eof;
// echo $sql;
    $result=pg_fetch_assoc(pg_query($sql));
    $count=$result['count'];
    echo $count;
    $precipitationSql=<<<eof
SELECT max("precipitation") AS precipitation FROM {$_POST['select']};
eof;*/

    ?>

<!--第二个div表格-->
<div align="center">
    <table  width="685" border="1" cellpadding="1" cellspacing="1" bordercolor="#FFFFFF" bgcolor="#666666">
        <!--第二行-->
        <tr>
            <!--不在一个表，暂时空着-->
            <td width="83" align="center" bgcolor="#FFFFFF">您的账号：</td>
            <td width="144" bgcolor="#FFFFFF"><input name="table_id" type="text" size="18" value="<?php echo $_SESSION['user']; ?>"></td>


            <td width="71" bgcolor="#FFFFFF">您的IP地址：</td>
            <td width="146" bgcolor="#FFFFFF"><input name="ip_number" type="text" size="18"  value="<?php echo $_SERVER["REMOTE_ADDR"];?>"/></td>
            <td width="213" bgcolor="#FFFFFF">查询时间：</td>
            <td><input name="search_time" type="text" size="18"  value="<?php date_default_timezone_set('Etc/GMT-8');     //这里设置了时区
                echo date("Y-m-d H:i:s");?>"/></td>
        </tr>
        <!--第三行-->

        <tr>
            <td align="center" bgcolor="#FFFFFF">查询数据库名称：</td>
            <td bgcolor="#FFFFFF"><input name="data_name" type="text" size="18" value="<?php  echo $_POST['select'];?>"/></td>
            <td align="center" bgcolor="#FFFFFF">查询数据条数：</td>
            <td bgcolor="#FFFFFF"><input name="datas_number" type="text"   value="<?php
                echo $count;  ?>"/></td>

            <?php foreach ($fields as $field){
                $query=<<<EOF
select * from {$_SESSION['tableName']}
EOF;
                $result=pg_query($query);
                $myrow=pg_fetch_assoc($result);
               // var_dump($myrow);

                //echo $count;
                $maxSql=<<<eof
SELECT {$field} FROM {$_SESSION['tableName']} where {$field}=(select max({$field}) from {$_SESSION['tableName']});
eof;
                //echo $maxSql;
                $minSql=<<<eof
SELECT {$field} FROM {$_SESSION['tableName']} where {$field}=(select min({$field}) from {$_SESSION['tableName']});
eof;
                $minResult=pg_query($minSql);
                $mins=pg_fetch_assoc($minResult);
                $min=$mins[$field];
                echo $min;
                // echo $strSql2;
                $maxResult=pg_query($maxSql);
                $maxs=pg_fetch_assoc($maxResult);
                $max=$maxs[$field];
                ?>
            <td align="center" bgcolor="#FFFFFF"><?php echo winDisplay($field)?>最小值：</td>
            <td bgcolor="#FFFFFF"><input name="data_name" type="text" size="18" value="<?php echo $max;



                ?>"/></td>
            <td align="center" bgcolor="#FFFFFF"><?php echo winDisplay($field)?>最大值：</td>
            <td bgcolor="#FFFFFF"><input name="data_name" type="text" size="18" value="<?php  echo $min;?>"/></td>
            <?php }?>

        </tr>

    </table>
</div>
    <?php
}   /* 这里有问题 */
?>
<br>
<!--打印功能-->
<!--&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
<a  href="#" onClick="parent.content.focus();window.print();"><img src="dl_034.gif" width="87" height="27" border="0"></a> &nbsp;
 &nbsp;
<a  href="#" onClick="parent.content.focus();window.print();"><img src="dl_033.gif" width="87" height="27" border="0"></a>-->
</body>
</html>
