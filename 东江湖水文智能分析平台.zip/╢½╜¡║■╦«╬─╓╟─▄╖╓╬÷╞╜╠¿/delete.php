<?php
header("Content-Type:text/html;charset=utf-8");
session_start();
//定义个常量，用来授权调用includes里面的文件
define('IN_TG',true);
//定义个常量，用来指定本页的内容
define('SCRIPT','delete');
//引入公共文件
require dirname(__FILE__).'/includes/common.inc.php';
if(!empty($_SESSION['tableName'])) {
  $iniUrlCon=$_SERVER["QUERY_STRING"];
//得到字段名，将字段名存入数组$fields[],note取的时候要用[]['attname']取
  $sql = <<<EOF
SELECT a.attname, a.attnotnull as notnull FROM pg_class as c,pg_attribute as a  where c.relname = '{$_SESSION['tableName']}' and a.attrelid = c.oid and a.attnum>1
EOF;
//echo $sql;
  $result = pg_query($sql);
  while ($row = pg_fetch_assoc($result)) {
    $fields[] = $row;
  }


//删除
  if ($_GET['action'] == 'delete') {
    if (!isset($_POST['ids'])){
      _alert_back('请先勾选需要删除的数据');
    }
    //经测试，还要截断action,否则修改完之后继续修改还会带着action=modify
    $re=array('action=delete'=>'');
    $iniUrlCon=strtr($iniUrlCon,$re);
    /*echo $iniUrlCon;
   exit();*/

    $shouldDelete = pg_escape_string(implode(",", $_POST["ids"]));
    $str = implode(',', $_POST['ids']);
    $sqlDelete = <<<EOF
    DELETE FROM {$_SESSION['tableName']} WHERE id in ({$str})
EOF;
    //echo $sqlDelete;
    if(pg_query($sqlDelete)){
        //从用户库中提取信息
        $userInfoSql = <<<EOF
SELECT lasttime,lastip FROM djhuser WHERE username='{$_COOKIE['username']}'
EOF;
        $infos = pg_fetch_assoc(pg_query($userInfoSql));
//插入数据库
        //$content = count($_POST['ids']) . '条数据';
        $content = $sqlDelete;
        $upLogSql = <<<EOF
INSERT INTO log (username,tablename,operation,operatetime,content,ip,logintime) VALUES('{$_COOKIE['username']}','{$_SESSION['tableName']}','{$scToCh[SCRIPT]}',NOW(),'{$content}','{$infos['lastip']}','{$infos['lasttime']}')
EOF;
        pg_query($upLogSql);

      _location("删除成功",'?'.$iniUrlCon);
    };
  }




//查询
  if ($_GET['firstAction'] == 'search') {
    $partSql = '';
    foreach ($fields as $field) {
      //ok
      //echo $_GET['first'.$field['attname']];
      //枚举类型处理
      $enumFields = array('loc', 'item', 'vname', 'stname', 'riname', 'sename', 'watercode', 'selocation');
      if (in_array($field['attname'], $enumFields) || ($field['attname']=='datetime' && $_SESSION['tableName']=='ftable')) {
        if ($_GET[$field['attname']] == 'all') {
          continue;
        }
        $acArray[] = '(' . $field['attname'] . '=' . '\'' . $_GET[$field['attname']] . '\'' . ')';
        continue;
      }


      $acmin = pg_escape_string($_GET['first' . $field['attname']]);
      $acmax = pg_escape_string($_GET['second' . $field['attname']]);
        if($_SESSION['tableName']=='runofftable' || $_SESSION['tableName']=='metable'){
            if($field['attname']=='datetime'){
                $acArray[]='(substr(datetime,7,2)||\'/\'||substring(datetime,1,6)||substr(datetime,9) BETWEEN substr(' . '\'' . $acmin . '\'' . ',7,2)||\'/\'||substring(' . '\'' . $acmin . '\'' . ',1,6)||substr(' . '\'' . $acmin . '\'' . ',9) and substr(' . '\'' . $acmax . '\'' . ',7,2)||\'/\'||substring(' . '\'' . $acmax . '\'' . ',1,6)||substr(' . '\'' . $acmax . '\'' . ',9)
                 )';
                continue;
            }
        }
      // $partSql.=$field['attname'].' between '.$acmin.' and '.$acmax.' ';
      //$acArray[]='('.$field['attname'].' between '.$acmin.' and '.$acmax.' '.')';
      $acArray[] = '(' . $field['attname'] . ' between ' . '\'' . $acmin . '\'' . ' and ' . '\'' . $acmax . '\'' . ' ' . ')';
      //$acArray[]='('.$field['attname'].' between '.'{'.$acmin.'}'.' and '.'{'.$acmax.'}'.' '.')';
      //echo $acArray;
    }
    $sqlPart = implode(' and ', $acArray);
    //echo $sqlPart;
    /*echo $sqlPart;
      echo $partSql;
      echo '<br/>';*/
    $acSql = <<<EOF
SELECT * FROM {$_SESSION['tableName']} WHERE {$sqlPart}
EOF;
    $resSearch = pg_query($acSql);
    $rowsSearch=array();
    while($rowsSearchIni=pg_fetch_assoc($resSearch)){
      $rowsSearch[]=$rowsSearchIni;
    }

    /*分页模块
  $_pagenum:从第几条开始提取
  $_pagesize:每页大小,
  */
    global $_pagenum,$_pagesize,$urlCon;
//接action=modify和page用不同变量的好处;page=xxx,action=xxx是在不同的链接上添加的，如果用同一个变量好像顺序正确的话也不会出问题

    $pos=strpos($iniUrlCon,'page');
    if(!!$pos){
      $urlCon=substr($iniUrlCon,0,$pos);
    }else{
      $urlCon=$iniUrlCon.'&';
    }
//echo sizeof($data);
//sizeof($data):数据总条数,15:每页大小
    if(!empty($_GET['pageSize'])){
      $_SESSION['pageSize']=$_GET['pageSize'];
    }
    $pageSize=15;
    if(!empty($_SESSION['pageSize'])){
      $pageSize=$_SESSION['pageSize'];
    }
    _page(sizeof($rowsSearch),$pageSize);
  }
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

    <?php require_once('includes/title.inc.php')?>
  <script type="text/javascript" src="js/jquery-3.1.0.min.js"></script>
  <link rel="stylesheet" type="text/css" href="js/jQuery-jcDate-master/src/jcDate.css" media="all" />
  <script type="text/javascript" src="js/jQuery-jcDate-master/src/jQuery-jcDate.js" charset="utf-8"></script>
  <script type="text/javascript" src="js/baseManage.inc1.js"></script>
<link rel="stylesheet" type="text/css" href="templateCss.css"/>


</head>

<body bgcolor="#cfd4ff">

<?php

require_once("includes/header.inc.php");
?>
<div class="bodyContent">
    <?php
require_once("includes/dbSelect.inc.php");
require_once("includes/dbFieldOperate.php");
?>


<?php if(!empty($_GET['firstAction'])){?>
<div id="mainDown">
<h2> 查询结果</h2>
  <?php
  _paging(2);
  ?>
  每页条数：
  <a  href="?<?php echo $urlCon."pageSize=15"; ?>">15</a>&nbsp&nbsp
  <a  href="?<?php echo $urlCon."pageSize=50"; ?>">50</a>&nbsp&nbsp
  <a  href="?<?php echo $urlCon."pageSize=100";  ?>">100</a>&nbsp&nbsp
  <div id="fieldDisplay" class="title2">
    <table width="100%" border="1">
      <tr>
        <td><div class="displayMain">序号</div></td>
        <?php foreach ($_GET['displays'] as $value){?>
          <td><div class="displayMain"><?php echo winDisplay($value); ?></div></td>
        <?php }?>
        <?php if($authority >=2){?>

          <td><div class="displayMain">是否选择</div></td>
        <?php }?>
      </tr>
    </table>
  </div>
<div id="display">
  <form id="formSelect" method="post" action="?action=delete&<?php echo $iniUrlCon;?>">
    <table width="100%" border="1">
  <!--<tr>
    <td><div class="displayMain">序号</div></td>
      <?php /*foreach ($_GET['displays'] as $value){*/?>
      <td><div class="displayMain"><?php /*echo winDisplay($value); */?></div></td>
      <?php /*}*/?>
      <td><div class="displayMain">是否选择</div></td>

  </tr>-->
      <!--有多少条-->
      <?php for($i=0;$i<$pageSize;$i++){?>
  <tr>
    <td>
      <div class="displayMain"><?php echo $rowsSearch[$_pagenum+$i]['id']?></div>
    </td>
    <?php
    //错误理解：外层foreach用的临时变量$value遍历和里层foreach用的临时变量会冲突，解决方法:1去不同名字2将外层变量付给新的变量
    //实际上是函数没写正确，没用返回值;注意没用返回值光输出时$rowsSearch[iniField($value)],没取出结果
    foreach ($_GET['displays'] as $displayValue){?>
      <td>
        <div class="displayMain">
          <?php /*$key=iniField($displayValue);echo $rowsSearch[$key];*/
          echo $rowsSearch[$_pagenum+$i][$displayValue];
           ?>
        </div>
        <?php
        ?>
      </td>
    <?php }?>
    <td><div class="displayMainSelect"><input class="selectSimpleInput" type="checkbox" name="ids[]" value="<?php echo $rowsSearch[$_pagenum+$i]['id']?>" /></div></td>
  </tr>
      <?php }?>
      <td colspan="<?php echo sizeof($fields)+2;?>">
        </td>
</table>
</div>
    <p><input class="selectSimpleInput" type="checkbox" name="selectAll" id="selectAll"  />
    <label for="selectAll">全选</label>
    <input type="checkbox" class="selectSimpleInput" name="selectReverse" id="selectReverse"  />
    <label for="selectReverse">反选</label></p>
    <input id="delete" type="submit" value="删除"/>
  </form>



</div>
<?php }?>
</div>
<?php require_once("includes/footer.inc.php")?>
<script type="text/javascript" src="js/<?php echo SCRIPT?>.js"></script>

</body>
</html>
