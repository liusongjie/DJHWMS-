<?php
header("Content-Type:text/html;charset=utf-8");
session_start();
//定义个常量，用来授权调用includes里面的文件
define('IN_TG',true);
//定义个常量，用来指定本页的内容
define('SCRIPT','print');
//引入公共文件
require dirname(__FILE__).'/includes/common.inc.php';



include("word.php"); 
$word=new word;

$word->start(); 
echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;开始报表打印";
?>


根据选择的表的不同显示不同预览，然后进行保存打印<br>

<!--1降雨量表-->
<?php
	if(!empty($_SESSION['tableName'])){
        $sql = <<<EOF
SELECT a.attname, a.attnotnull as notnull FROM pg_class as c,pg_attribute as a  where c.relname = '{$_SESSION['tableName']}' and a.attrelid = c.oid and a.attnum>1
EOF;
//echo $sql;
        $fields=array();
        $result = pg_query($sql);
        while ($row = pg_fetch_assoc($result)) {
            $fields[] = $row;
        }
?>

<table  width="700" border="1" cellpadding="1" cellspacing="1" bordercolor="#FFFFFF" bgcolor="#666666">
 <!--第二行-->
  <tr>
    <td  align="center" bgcolor="#FFFFFF">您的账号：</td>
    <td bgcolor="#FFFFFF"><?php echo $_COOKIE['username']?></td>
    <td  bgcolor="#FFFFFF">您的IP地址：</td>
    <td bgcolor="#FFFFFF"><?php echo $_SERVER["REMOTE_ADDR"];?></td>
    <td  bgcolor="#FFFFFF">查询时间：</td>
    <td bgcolor="#FFFFFF"><?php date_default_timezone_set('Etc/GMT-8');     //这里设置了时区
          echo date("Y年m月d日 H时i分s秒");?></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFFFF">查询数据库名称：</td>
    <td bgcolor="#FFFFFF"><?php echo $_SESSION['tableCh']?></td>
<td align="center" bgcolor="#FFFFFF">查询数据条数：</td>
    <td bgcolor="#FFFFFF">
        <?php
        $sql=<<<EOF
SELECT COUNT(*) AS count FROM {$_SESSION['tableName']};
EOF;

        $result=pg_fetch_assoc(pg_query($sql));
        $count=$result['count'];
        echo $count;
        ?>
    </td>
  </tr>

    <?php $i=0;
        foreach ($fields as $key=>$field){
    // echo $field['attname'];
    $enumFields=array('loc','item','vname','stname','riname','sename','watercode','selocation','wqc','ti','res','fr','ct','pt','gbr','coulperdetached','coulperattached','stopped','eof');
    if(in_array($field['attname'],$enumFields) || ($field['attname']=='datetime' && $_SESSION['tableName']=='ftable')){
        $sqlEnum=<<<EOF
SELECT {$field['attname']} FROM {$_SESSION['tableName']} GROUP BY {$field['attname']}
EOF;
        //echo  $sqlEnum;
        $resEnum=pg_query($sqlEnum);

        ?>
        <tr>
            <td align="center" bgcolor="#FFFFFF">
                <?php echo winDisplay($field['attname'])?>
            </td>
            <td align="left" bgcolor="#FFFFFF" colspan="5">
                                <?php while($rowEnum=pg_fetch_assoc($resEnum)){?>


                                        <?php echo $rowEnum[$field['attname']]?>
                                    &nbsp;
                                    &nbsp;
                                    <?php
                                }
                                ?>
            </td>
        </tr>
        <?php
        //注意continue 的位置
        continue;
    }
    //也可以用代码顺序来控制逻辑，即将下面部分代码放到第一次取出min，max后，用条件重写min,max,不过怕以后不记得，所以，直接用麻烦的方法
            if($_SESSION['tableName']=='runofftable' || $_SESSION['tableName']=='metable'){
                if($field['attname']=='datetime'){
                    $strSql1=<<<EOF
select datetime from {$_SESSION['tableName']} where substr(datetime,7,2)||'/'||substring(datetime,1,6)||substr(datetime,9)=(select min(substr(datetime,7,2)||'/'||substring(datetime,1,6)||substr(datetime,9)) from {$_SESSION['tableName']})
EOF;
                    //echo $strSql1;
                    $minResult=pg_query($strSql1);
                    $mins=pg_fetch_assoc($minResult);
                    $min=$mins[$field['attname']];
                    //echo $min;
                    $strSql2=<<<EOF
select datetime from {$_SESSION['tableName']} where substr(datetime,7,2)||'/'||substring(datetime,1,6)||substr(datetime,9)=(select MAX(substr(datetime,7,2)||'/'||substring(datetime,1,6)||substr(datetime,9)) from {$_SESSION['tableName']})
EOF;
                    // echo $strSql2;
                    $maxResult=pg_query($strSql2);
                    $maxs=pg_fetch_assoc($maxResult);
                    $max=$maxs[$field['attname']];
                    ?>
                    <tr>
                    <td align="center" bgcolor="#FFFFFF"><?php echo winDisplay($field['attname'])?>最大值：</td>
                    <td bgcolor="#FFFFFF"><?php  echo $max;?></td>
                    <td align="center" bgcolor="#FFFFFF"><?php echo winDisplay($field['attname'])?>最小值：</td>
                    <td bgcolor="#FFFFFF"><?php  echo $min;?></td>
                    </tr>
                    <?php
                    continue;
                }

            }
            $strSql1=<<<EOF
SELECT {$field['attname']} FROM {$_SESSION['tableName']} WHERE {$field['attname']}=(select min({$field['attname']}) 
                from {$_SESSION['tableName']}) 
EOF;
            // echo $strSql1;
            $minResult=pg_query($strSql1);
            $mins=pg_fetch_assoc($minResult);
            $min=$mins[$field['attname']];
            //echo $min;
            $strSql2=<<<EOF
SELECT {$field['attname']} FROM {$_SESSION['tableName']} WHERE {$field['attname']}=(select max({$field['attname']}) 
                from {$_SESSION['tableName']}) 
EOF;
            // echo $strSql2;
            $maxResult=pg_query($strSql2);
            $maxs=pg_fetch_assoc($maxResult);
            $max=$maxs[$field['attname']];


                ?>
                <tr>
                    <td align="center" bgcolor="#FFFFFF"><?php echo winDisplay($field['attname'])?>最大值：</td>
                    <td bgcolor="#FFFFFF"><?php  echo $max;?></td>
                    <td align="center" bgcolor="#FFFFFF"><?php echo winDisplay($field['attname'])?>最小值：</td>
                    <td bgcolor="#FFFFFF"><?php  echo $min;?></td>
                    <?php
                    /*echo  1;
                    exit();*/
                        if($field['attname']=='datetime'){
                            continue;
                        }
                    $strSql3=<<<EOF
SELECT avg({$field['attname']}) as avg FROM {$_SESSION['tableName']} 
EOF;
                    $avgResult=pg_query($strSql3);
                    $avgs=pg_fetch_assoc($avgResult);
                    $avg=$avgs['avg'];
                    ?>
                    <td align="center" bgcolor="#FFFFFF"><?php echo winDisplay($field['attname'])?>平均值：</td>
                    <td bgcolor="#FFFFFF"><?php  echo $avg;?></td>
    </tr>
                    <?php
        }
    ?>

</table>
        <?php
        $word->save($_SESSION['tableName'].".doc");//保存农业word并且结束.
        ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <?php require_once('includes/title.inc.php')?>
    <script type="text/javascript" src="js/jquery-3.1.0.min.js"></script>
    <link rel="stylesheet" type="text/css" href="js/jQuery-jcDate-master/src/jcDate.css" media="all" />
    <script type="text/javascript" src="js/jQuery-jcDate-master/src/jQuery-jcDate.js" charset="utf-8"></script>
    <script type="text/javascript" src="js/baseManage.inc1.js"></script>
    <link rel="stylesheet" type="text/css" href="templateCss.css"/>
<body>
        <table  width="700" border="1" cellpadding="1" cellspacing="1" bordercolor="#FFFFFF" bgcolor="#666666">
            <!--第二行-->
            <tr>
                <td  align="center" bgcolor="#FFFFFF">您的账号：</td>
                <td bgcolor="#FFFFFF"><?php echo $_COOKIE['username']?></td>
                <td  bgcolor="#FFFFFF">您的IP地址：</td>
                <td bgcolor="#FFFFFF"><?php echo $_SERVER["REMOTE_ADDR"];?></td>
                <td  bgcolor="#FFFFFF">查询时间：</td>
                <td bgcolor="#FFFFFF"><?php date_default_timezone_set('Etc/GMT-8');     //这里设置了时区
                    echo date("Y年m月d日 H时i分s秒");?></td>
            </tr>
            <tr>
                <td align="center" bgcolor="#FFFFFF">查询数据库名称：</td>
                <td bgcolor="#FFFFFF"><?php echo $_SESSION['tableCh']?></td>
                <td align="center" bgcolor="#FFFFFF">查询数据条数：</td>
                <td bgcolor="#FFFFFF">
                    <?php
                    $sql=<<<EOF
SELECT COUNT(*) AS count FROM {$_SESSION['tableName']};
EOF;

                    $result=pg_fetch_assoc(pg_query($sql));
                    $count=$result['count'];
                    echo $count;
                    ?>
                </td>
            </tr>

            <?php $i=0;
            foreach ($fields as $key=>$field){
                // echo $field['attname'];
                $enumFields=array('loc','item','vname','stname','riname','sename','watercode','selocation','wqc','ti','res','fr','ct','pt','gbr','coulperdetached','coulperattached','stopped','eof');
                if(in_array($field['attname'],$enumFields) || ($field['attname']=='datetime' && $_SESSION['tableName']=='ftable')){
                    $sqlEnum=<<<EOF
SELECT {$field['attname']} FROM {$_SESSION['tableName']} GROUP BY {$field['attname']}
EOF;
                    //echo  $sqlEnum;
                    $resEnum=pg_query($sqlEnum);

                    ?>
                    <tr>
                        <td align="center" bgcolor="#FFFFFF">
                            <?php echo winDisplay($field['attname'])?>
                        </td>
                        <td align="left" bgcolor="#FFFFFF" colspan="5">
                            <?php while($rowEnum=pg_fetch_assoc($resEnum)){?>


                                <?php echo $rowEnum[$field['attname']]?>
                                &nbsp;
                                &nbsp;
                                <?php
                            }
                            ?>
                        </td>
                    </tr>
                    <?php
                    //注意continue 的位置
                    continue;
                }
                //也可以用代码顺序来控制逻辑，即将下面部分代码放到第一次取出min，max后，用条件重写min,max,不过怕以后不记得，所以，直接用麻烦的方法
                if($_SESSION['tableName']=='runofftable' || $_SESSION['tableName']=='metable'){
                    if($field['attname']=='datetime'){
                        $strSql1=<<<EOF
select datetime from {$_SESSION['tableName']} where substr(datetime,7,2)||'/'||substring(datetime,1,6)||substr(datetime,9)=(select min(substr(datetime,7,2)||'/'||substring(datetime,1,6)||substr(datetime,9)) from {$_SESSION['tableName']})
EOF;
                        //echo $strSql1;
                        $minResult=pg_query($strSql1);
                        $mins=pg_fetch_assoc($minResult);
                        $min=$mins[$field['attname']];
                        //echo $min;
                        $strSql2=<<<EOF
select datetime from {$_SESSION['tableName']} where substr(datetime,7,2)||'/'||substring(datetime,1,6)||substr(datetime,9)=(select MAX(substr(datetime,7,2)||'/'||substring(datetime,1,6)||substr(datetime,9)) from {$_SESSION['tableName']})
EOF;
                        // echo $strSql2;
                        $maxResult=pg_query($strSql2);
                        $maxs=pg_fetch_assoc($maxResult);
                        $max=$maxs[$field['attname']];
                        ?>
                        <tr>
                            <td align="center" bgcolor="#FFFFFF"><?php echo winDisplay($field['attname'])?>最大值：</td>
                            <td bgcolor="#FFFFFF"><?php  echo $max;?></td>
                            <td align="center" bgcolor="#FFFFFF"><?php echo winDisplay($field['attname'])?>最小值：</td>
                            <td bgcolor="#FFFFFF"><?php  echo $min;?></td>
                        </tr>
                        <?php
                        continue;
                    }

                }
                $strSql1=<<<EOF
SELECT {$field['attname']} FROM {$_SESSION['tableName']} WHERE {$field['attname']}=(select min({$field['attname']}) 
                from {$_SESSION['tableName']}) 
EOF;
                // echo $strSql1;
                $minResult=pg_query($strSql1);
                $mins=pg_fetch_assoc($minResult);
                $min=$mins[$field['attname']];
                //echo $min;
                $strSql2=<<<EOF
SELECT {$field['attname']} FROM {$_SESSION['tableName']} WHERE {$field['attname']}=(select max({$field['attname']}) 
                from {$_SESSION['tableName']}) 
EOF;
                // echo $strSql2;
                $maxResult=pg_query($strSql2);
                $maxs=pg_fetch_assoc($maxResult);
                $max=$maxs[$field['attname']];


                ?>
                <tr>
                    <td align="center" bgcolor="#FFFFFF"><?php echo winDisplay($field['attname'])?>最大值：</td>
                    <td bgcolor="#FFFFFF"><?php  echo $max;?></td>
                    <td align="center" bgcolor="#FFFFFF"><?php echo winDisplay($field['attname'])?>最小值：</td>
                    <td bgcolor="#FFFFFF"><?php  echo $min;?></td>
                    <?php
                    if($field['attname']=='datetime'){
                        continue;
                    }
                    $strSql3=<<<EOF
SELECT avg({$field['attname']}) as avg FROM {$_SESSION['tableName']} 
EOF;
                    $avgResult=pg_query($strSql3);
                    $avgs=pg_fetch_assoc($avgResult);
                    $avg=$avgs['avg'];
                    ?>
                    <td align="center" bgcolor="#FFFFFF"><?php echo winDisplay($field['attname'])?>平均值：</td>
                    <td bgcolor="#FFFFFF"><?php  echo $avg;?></td>
                </tr>
                <?php
            }
            ?>

        </table>
<?php
}
?>
<?php
echo ' <h1>这是报表预览页面，已经为您创建word文档</h1> 
<br> <p> 
<a href="'.$_SESSION['tableName'].'.doc" target=_blank>点击这里下载</a>';
?>
<a onclick="isOk()"><img src="images/报表打印.jpg" width="87" height="27" border="0"></a>
<script>
function isOk(){
	if(confirm('是否开始打印?')){
		window.print();
	}else{
		return false;
	}
}
</script>

<br>
</body>
</html>


