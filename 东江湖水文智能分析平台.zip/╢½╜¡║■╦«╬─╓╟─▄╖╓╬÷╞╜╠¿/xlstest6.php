<?php
/**
 * Created by PhpStorm.
 * User: hetong
 * Date: 2016/10/1
 * Time: 13:49
 */require_once 'PHPExcel_1.8.0_doc/Classes/PHPExcel.php';

//避免中文文件名，进行转码
$filePath=iconv('utf-8','gb2312',$filePath);

$PHPReader = new PHPExcel_Reader_Excel2007();
/* echo $filePath;
 exit(122);*/
if(!$PHPReader->canRead($filePath)){
    $PHPReader = new PHPExcel_Reader_Excel5();

    if(!$PHPReader->canRead($filePath)){

        _alert_back('no Excel');
    }
}
$PHPExcel = $PHPReader->load($filePath);
//读取excel文件中的第一个工作表
$currentSheet = $PHPExcel->getSheet(0);
//取得最大的列号
$allColumn = $currentSheet->getHighestColumn();
$highestColumnNum = PHPExcel_Cell::columnIndexFromString($allColumn);
//从数据库中取出有多少字段
$colFieldSQL=<<<EOF
select count(*) as colnum from information_schema.COLUMNS where table_name='{$_SESSION['tableName']}';
EOF;
$colFromSqls=pg_fetch_assoc(pg_query($colFieldSQL));
$colFromSql=intval($colFromSqls['colnum']);
/* var_dump($colFromSqls);
 echo $highestColumnNum;
 echo $colFromSql;
 echo '<br/>';
 $encode = mb_detect_encoding($highestColumnNum, array("ASCII",'UTF-8','GB2312',"GBK"));
echo $encode;*/
if($highestColumnNum!=$colFromSql){

    _alert_back('上传文件内容不符合要求,请重新选择文件');
};

//取得一共有多少行
$allRow = $currentSheet->getHighestRow();
//从第二行开始输出，因为excel表中第一行为列名
$chField=array();
echo  $highestColumnNum;
for($currentRow = 1;$currentRow <=1;$currentRow++,$i++){
    //从第A列开始输出

    for($i=0;$i<$highestColumnNum;$i++){
        $val = $currentSheet->getCellByColumnAndRow($i,$currentRow)->getValue();

        //$val = $currentSheet->getCellByColumnAndRow(ord($currentColumn) - 65,$currentRow)->getValue();
        //ord()将字符转为十进制数


//echo $val;
        //如果输出汉字有乱码，则需将输出内容用iconv函数进行编码转换，如下将gb2312编码转为utf-8编码输出
        //echo $val."\t";
        $val=iconv('gbk','utf-8', $val);
        $chField[$i]=$val;
    }
    echo "</br>";
}
//echo $chField[3];
var_dump($chField);
foreach($fields as $field){
    // echo winDisplay($field['attname']);
    if(!in_array(winDisplay($field['attname']),$chField)){

        exit();
        _alert_back('上传文件内容不符合要求,请重新选择文件');
    }
}
?>