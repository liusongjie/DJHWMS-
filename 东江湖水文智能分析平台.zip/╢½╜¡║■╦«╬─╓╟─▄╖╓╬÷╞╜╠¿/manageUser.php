
<?php

//使用pdo连接数据库获取数据
/*$dbms='pgsql';
$host='localhost';
$dbName='postgres';
$user='postgres';
$pass='123456';
$dsn="$dbms:host=$host; dbname=$dbName";
$pdo=new PDO($dsn, $user, $pass);
if ($pdo){
	echo 'success';
}
$sql=<<<EOF
			SELECT username,department,userimg,userfile,email,mobile From djhuser WHERE active=:active;
EOF;
$stmt=$pdo->prepare($query);
$stmt->execute(array(':active'=>false));
$stmt->bindColumn(3, $lobImg, PDO::PARAM_LOB);
$stmt->bindColumn(4, $lobFile, PDO::PARAM_LOB);
$stmt->fetch(PDO::FETCH_BOUND);
//var_dump($rows);
header("Content-Type:image/jpeg");
fpassthru($lobImg);

//var_dump($rows);
header("Content-Type:text/html;charset=utf-8");
fpassthru($lobFile);*/

header("Content-Type:text/html;charset=utf-8");
header("Cache-Control: no-cache");
session_start();
//定义个常量，用来授权调用includes里面的文件
define('IN_TG',true);
//定义个常量，用来指定本页的内容
define('SCRIPT','manageUser');
//引入公共文件
require dirname(__FILE__).'/includes/common.inc.php';
//必须是管理员才能登录
_manage_login();
global $_conn;

/*pg_query ($_conn, "begin");

// "assume" for this example that the large object resource number of the zipped file is "17899"

$lo_oid = 25037;

$handle_lo = pg_lo_open($_conn,$lo_oid,"rw") or die("<h1>Error.. can't get handle</h1>");

//headers to send to the browser before beginning the binary download
header('Accept-Ranges: bytes');
header('Content-Length: 35552029974'); //this is the size of the zipped file
header('Keep-Alive: timeout=15, max=100');
header('Content-type: Application/x-zip');
header('Content-Disposition: attachment; filename="superjob.zip"');

pg_lo_read_all($handle_lo) or
die("<h1>Error, can't read large object.</h1>");

// committing the data transaction
pg_query ($_conn, "commit");*/

//启用禁用模块
if(!empty($_GET['usable'])){
	echo $_GET['usable'];
	$upSql1=<<<EOF
			UPDATE djhuser SET usable='{$_GET['usable']}' WHERE username='{$_GET['username']}';
EOF;
	echo $upSql1;
	//echo $upSql1;
	$upResult1=pg_query($upSql1);
	if (pg_affected_rows($upResult1) != 1) {
		_alert_back('操作失败');
	}

}

//激活模块
if ($_GET['action']=='active'){
	$pass=rand(100000,999999);
	$upSql1=<<<EOF
			UPDATE djhuser SET password='{$pass}' WHERE username='{$_GET['username']}';
EOF;
	$upResult1=pg_query($upSql1);
	if (pg_affected_rows($upResult1) != 1) {
		_alert_back('激活失败');
	}

	$upSql=<<<EOF
			UPDATE djhuser SET active=true WHERE username='{$_GET['username']}';
EOF;
	$upResult=pg_query($upSql);
	if (pg_affected_rows($upResult) == 1) {
		//收件人邮箱
		$sql=<<<EOF
		SELECT email FROM djhuser where username='{$_GET['username']}';
EOF;
		$res=pg_query($sql);
		$acData=pg_fetch_assoc($res);
		//var_dump($acData);
		require_once "smtp.php";
//使用163邮箱服务器
		$smtpserver = "smtp.163.com";
//163邮箱服务器端口
		$smtpserverport = 25;
//你的163服务器邮箱账号
		$smtpusermail = "13699441014@163.com";
//收件人邮箱

		$smtpemailto = $acData['email'];
//你的邮箱账号(去掉@163.com)
		$smtpuser = "13699441014";//SMTP服务器的用户帐号
//你的邮箱密码
		$smtppass = "428851HE"; //SMTP服务器的用户密码
//邮件主题
		$mailsubject = "激活邮件";
//邮件内容
	/*	$pass=radom(1000,9999);
		$upSql1=<<<EOF
			UPDATE djhuser SET password='{$radom}' username='{$_GET['username']}';
EOF;
		$upResult1=pg_query($upSql1);
		if (pg_affected_rows($upResult1) != 1) {
			_alert_back('激活失败');
		}*/
		$mailbody = "您的账号已被激活，初始密码是".$pass;
//邮件格式（HTML/TXT）,TXT为文本邮件
		$mailtype = "TXT";
//这里面的一个true是表示使用身份验证,否则不使用身份验证.
		$smtp = new smtp($smtpserver,$smtpserverport,true,$smtpuser,$smtppass);
//是否显示发送的调试信息
		$smtp->debug = FALSE;
//发送邮件
		$smtp->sendmail($smtpemailto, $smtpusermail, $mailsubject, $mailbody, $mailtype);
	}
}


/*$sql=<<<EOF
			SELECT username,department,email,mobile,registertime From djhuser WHERE active=false ORDER BY registertime;
EOF;*/
if($_GET['type']=='audited'){
	$sql=<<<EOF
			SELECT * From djhuser WHERE active=true ORDER BY lasttime;
EOF;
	$result=pg_query($sql);
}else{
	$sql=<<<EOF
			SELECT * From djhuser WHERE active=false ORDER BY registertime;
EOF;

	$result=pg_query($sql);
}



?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

	<title><?php echo '湖南省郴州东江湖水资源管理'?></title>
	<link rel="shortcut icon" href="dongjianghu.ico" />
	<script type="text/javascript" src="js/jquery-3.1.0.min.js"></script>
	<style type="text/css">
		#manageUser {
			width: 96%;
			/*height: 90%;*/
			z-index: 1;
			margin-top: 15px;
			margin-right: 15px;
			margin-bottom: 10px;
			margin-left: 15px;
			background-color: #FFF;
			border-radius: 8px;
			font-size: 18px;
			text-algin: center;
			padding: 10px;
			overflow-x: auto;
		}
		#selectDB h2 strong {
			font-weight: bold;
			color: #36C;
		}

		#manageUser #operateTitle {
			height: 30px;
			border-bottom-width: 2px;
			border-bottom-style: none;
			border-bottom-color: #399;
			vertical-align: middle;
			text-align: center;
		}
		h2 {
			color: #39C;
			font-weight: bold;
			text-align:center;
		}
		h2 {
			color: #36C;
			font-size: 24px;
		}
		.title2 {
			font-size: 18px;
		}
		.title2 {
			font-weight: bold;
			font-size: 22px;
			color: #000;
		}
		#selectDB form table tr {
			height: 20px;
		}
		#manageUser form ul {
			list-style-type: none;
			height:120px;
			width:95%;
			overflow:auto;
		}
		#manageUser form ul li{

			display:inline-block;
			width:620px;
			height:35px;
		}
		#manageUser form ul li span.searchInfo{
			display:inline-block;
			/*border:red solid 1px;*/
			width:350px;
		}
		#manageUser form ul li span.searchInput{
			width:180px;
		}
		#manageUser form ul input.searchInput{
			width:80px;
		}

		#manageUser form ul.displaySelect{

			height:auto;
			max-height:110px;
			width:95%;
			overflow:auto;
		}
		#manageUser form ul li.displaySelect{

			display:inline-block;
			width:180px;
			height:35px;
		}
		#manageUser form ul li.displayBatch{

			display:block;
			text-align:center;
			width:90%;
			height:35px;
		}
		#manageUser form ul.submit{
			text-align:center;
			width:90%;
			height:75px;
		}
		p .title2 {
			font-size: 20px;
		}
		#manageUser #manageMain p {
			text-align: center;

		}
		#manageMain{
			width: 99%;
			/*min-height:600px;
			height:90%;*/
			overflow-x: auto;
		}
		#manageMain span.tdAudit{
			display:inline-block;
			width:150px;
			text-align:center;
		}
		#manageMain span#email{
			display:inline-block;
			width:200px;
		}
		#manageMain span.tdBottom {
			text-align:center;
			display:inline-block;
			width:100px;
		}
		#userList{
			min-height:100%;
			overflow: auto;
		}
	</style>

	<link rel="stylesheet" type="text/css" href="js/jQuery-jcDate-master/src/jcDate.css" media="all" />
	<script type="text/javascript" src="js/jQuery-jcDate-master/src/jQuery-jcDate.js" charset="utf-8"></script>
	<script type="text/javascript" src="js/baseManage.inc1.js"></script>
	<link rel="stylesheet" type="text/css" href="templateCss.css" />


</head>
<body>

<?php
	require ROOT_PATH.'includes/header.inc.php';
?>
<div class="bodyContent">

<div id="manageUser">


	<div id="manageMain" >
		<h2>会员管理</h2>
		<p><span class="title2">用户类别选择：(当前:<?php
				if($_GET['type']=='audited'){
					echo '已审核用户';
				}else{
					echo '未审核用户';
				}
				?>)</span>
			<br/>
			<a href="?type=pendingAudit">未审核用户</a>  <a href="?type=audited" target="_self">已审核用户 </a></p>
		<div id="userList">
		<?php if($_GET['type']=='audited'){?>
			<table border="1" cellspacing="1" >
				<tr><th>用户名</th>


					<th>最后一次登录时间</th>
					<th>登录状态</th>
                    <th>登录地点</th>
					<th>登录次数</th>
					<th>启用/禁用</th>
					<th>用户类别</th>
                    <th>注册时间</th>
					<!--<th>权限设置</th>-->
					<th>邮箱</th><th>手机号</th><th>验证图片</th><th>验证文件</th>
					<?php foreach(array_keys($dbInDp) as $de){
						echo '<th>'.departmentCH($de).'局权限'.'</th>';
					}?>

					<th></th>
					<th></th>

				</tr>
				<?php while(!!$data=pg_fetch_assoc($result)){

					?>
					<tr>
						<?php /*foreach ($data as $value){
					echo '<td>'.$value.'</td>';
					$url='userdata/'.$data['username'].'.jpg';
					//echo $url;

				} */?>
						<td><span class="tdAudit"><?php echo $data['username'] ?></span></td>



						<td><span class="tdAudit"><?php echo substr($data['lasttime'],0,19); ?></span></td>
						<td><span class="tdAudit">

								<?php
								if($data['loginstate']==ture){
									echo '已登录';
								}else{
									echo '未登录';
								}
								?>
							</span>
						</td>
						<td><span class="tdAudit"><?php echo $data['logincount']; ?></span></td>

						<form method="get"	id="allowRegister" action="?action=active&username=<?php echo $data['username']?>">
							<td>
								<span class="tdBottom">
									<?php
									if ($data['authority']<=1) {
										if ($data['usable'] == 't') {
											echo '<input type="hidden" name="usable" value="false" />';

											echo '<input type="submit"  value="禁用" />';
										} else {

											echo '<input type="hidden" name="usable" value="true" />';

											echo '<input type="submit"  value="启用" />';
										}
									}?>
								</span>

							</td>
							<input type="hidden" name="type" value="<?php echo $_GET['type']?>" />
							<input type="hidden" name="username" value="<?php echo $data['username']?>" />
						</form>
						<td>
							<span class="tdBottom">
									<?php if($data['authority']==2){
										echo '管理员';
									}else{
										echo '普通用户';
									}?>
								</span>

						</td>
						<!--<form method="get" action="">
							<td>
							<span class="tdBottom">
									<?php /*if($data['authority']==2){
										echo '<input type="submit" name="setAuthority" value="设为普通用户"/>';
									}else{
										echo '<input type="submit" name="setAuthority" value="设为管理员" />';
									}*/?>
								</span>

							</td>
							<input type="hidden" name="type" value="<?php /*echo $_GET['type']*/?>" />
							<input type="hidden" name="username" value="<?php /*echo $data['username']*/?>"
						</form>-->
                        <td><span class="tdAudit"><?php echo substr($data['registertime'],0,19); ?></span></td>
						<td><span class="tdAudit" id="email"><?php echo $data['email'] ?></span></td>
						<td><span class="tdAudit"><?php echo $data['mobile'] ?></span></td>


						<!--验证文件-->
						<td><span class="tdAudit"><a href='<?php echo 'userdata/'.$data['username'].'.jpg';?>'>查看</a></span></td>
						<td><span class="tdAudit"><a href='<?php echo 'userdata1/'.$data['username'].'.doc';?>'>查看</a></span></td>

						<?php
						foreach(array_keys($dbInDp) as $de){
							echo '<th><span class="tdAudit">'.$dbAuthority[$data[$de]].'</span></th>';
						}?>


						<td><span ></span></td>
						<td><span ></span></td>

					</tr>

					<?php
				}
				?>
			</table>
		<?php }else{?>
		<table border="1" cellspacing="1">
			<tr><th>用户名</th><th>邮箱</th><th>手机号</th><th>验证图片</th><th>验证文件</th>

				<th>注册时间</th>
				<th>激活</th>

				<?php foreach(array_keys($dbInDp) as $de){
					echo '<th>'.departmentCH($de).'局权限'.'</th>';
				}?>

				<th></th>
				<th></th>
		  </tr>
		<?php while(!!$data=pg_fetch_assoc($result)){

		?>
		<tr>
				<?php /*foreach ($data as $value){
					echo '<td>'.$value.'</td>';
					$url='userdata/'.$data['username'].'.jpg';
					//echo $url;
				} */?>
			<td><span class="tdAudit"><?php echo $data['username'] ?></span></td>
			<td><span class="tdAudit" id="email"><?php echo $data['email'] ?></span></td>
			<td><span class="tdAudit"><?php echo $data['mobile'] ?></span></td>
			<!--验证文件-->
			<td><span class="tdAudit"><a href='<?php echo 'userdata/'.$data['username'].'.jpg';?>'>查看</a></span></td>
			<td><span class="tdAudit"><a href='<?php echo 'userdata1/'.$data['username'].'.doc';?>'>查看</a></span></td>
			<td><span class="tdAudit"><?php echo substr($data['registertime'],0,19); ?></span></td>
			<form method="get"	id="allowRegister" action="?active=active&username=<?php echo $data['username']?>">
				<td>
					<span class="tdBottom" >
						<input type="hidden" name="active" value="true" />
						<input type="submit" value="激活" />
					</span>
				</td>
				<input type="hidden" name="type" value="<?php echo $_GET['type']?>" />
				<input type="hidden" name="action" value="active" />
				<input type="hidden" name="username" value="<?php echo $data['username']?>" />
			</form>
			<?php
			foreach(array_keys($dbInDp) as $de){
				echo '<th><span class="tdAudit">'.$dbAuthority[$data[$de]].'</span></th>';
			}?>

			<td><span></span></td>
			<td><span></span></td>

		</tr>

		<?php
			}
		?>
	  </table>
		<?php }?>
		</div>
</div>

</div>
</div>
<?php 
	require ROOT_PATH.'includes/footer.inc.php';
?>
<script type="text/javascript" src="js/<?PHP echo SCRIPT?>.js"  ></script>

</body>
</html>
