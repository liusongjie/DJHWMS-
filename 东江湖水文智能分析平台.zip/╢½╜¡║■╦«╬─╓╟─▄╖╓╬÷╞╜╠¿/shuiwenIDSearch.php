<?php
/**
 * TestGuest Version1.0
 * ================================================
 * Copy 2010-2012 yc60
 * Web: http://www.yc60.com
 * ================================================
 * Author: Lee
 * Date: 2010-9-2
 */
header("Content-Type:text/html;charset=utf-8");
header("Cache-Control: no-cache");
session_start();
//定义个常量，用来授权调用includes里面的文件
define('IN_TG',true);
//定义个常量，用来指定本页的内容
define('SCRIPT','shuiwenIDSearch');
//引入公共文件
require dirname(__FILE__).'/includes/common.inc.php';
/*if(!empty($_GET['area'])){
	header('Location: manage_project.php?area='.$_GET['area']);
}*/
require_once("http://localhost:8080/JavaBridgeTemplate611/java/Java.inc");

/*$search=new Java("ConvertList");
$result=new Java("SearchByID");

$result1=java_values($search->convertList($result->fileSearch()));

var_dump($result1);
$endResult=$result1[0];*/
if($_SESSION['department']=="水力" ||$_SESSION['authority']==2){
    echo $_POST['id'];
    $id=intval($_POST['id']);
    //echo  $id;
    $search=new Java("HYSearch");
    $convert=new Java("ConvertList");
    //$inidata=java_values($convert->convertList($search->IDSearch($_POST['id'])));
    $inidata=java_values($convert->convertList($search->IDSearch($_POST['id'])));
    $data=$inidata[0];
}



/*$data=java_values($convert->convertList($search->IDSearch()));*/
//var_dump($data);
//echo $endResult["datetime"];
//必须是管理员才能登录
//_manage_login();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <?php
    //echo ROOT_PATH.'includes/title.inc.php';
    require ROOT_PATH.'includes/title.inc.php';
    ?>
    <!--  <script type="text/javascript" src="js/baseManage.header.js"></script>-->
</head>
<body>
<?php
require ROOT_PATH.'includes/header.inc.php';
?>

<div id="baseManage">
    <?php
    require ROOT_PATH.'includes/baseManage.inc.php';
    ?>
    <div id="baseManageMain">
        <h2><?php echo $_GET['baseType'].'数据查询结果'?></h2>
        <table cellspacing="1">
            <tr>
                <th>id</th>
                <th>逐日降雨量(mm)</th>
                <th>逐日平均流量(m3/s)</th>
                <th>日期</th>
            </tr>
            <tr>
                <td><?php echo $data["id"]?></td>
                <td><?php echo $data["percipitation"]?></td>
                <td><?php echo $data["avgflow"]?></td>
                <td><?php echo $data["datetime"]?></td>
            </tr>
        </table>
    </div>
</div>


<?php
require ROOT_PATH.'includes/footer.inc.php';
?>
<!--<script type="text/javascript" src="js/baseManage.inc.js"></script>-->
</body>
</html>
