<?php
/**
 * Created by PhpStorm.
 * User: hetong
 * Date: 2016/8/14
 * Time: 12:00
 */
header("Content-Type:text/html;charset=utf-8");
session_start();
//定义个常量，用来授权调用includes里面的文件
define('IN_TG',true);
//定义个常量，用来指定本页的内容
define('SCRIPT','qixiangWholeSearch');
//引入公共文件
require dirname(__FILE__).'/includes/common.inc.php';



//提取数据
require_once("http://localhost:8080/JavaBridgeTemplate611/java/Java.inc");

//删除数据
if($_GET["action"]=="delete" && isset($_POST["ids"])){
    $shouldDelete=pg_escape_string(implode(",",$_POST["ids"]));
    $str=implode(',',$_POST['ids']);
    $batchDel=new Java("HYDelete");
    $batchDel->MultipleIDDelete($str);
    echo "<script type='text/javascript'>history.back();</script>";
}

$ATSearch=new Java("ATSearch");
$convert=new Java("ConvertList");
$result=$ATSearch->SearchAll();
$inidata=$convert->convertList($result);
$data=java_values($inidata);
//var_dump($data);

/*分页模块
$_pagenum:从第几条开始提取
$_pagesize:每页大小,
*/
global $_pagenum,$_pagesize,$urlCon;


if(!empty($_GET['pageSize'])){
    $_SESSION['ATWholePageSize']=$_GET['pageSize'];
}
$pageSize=15;
if(!empty($_SESSION['ATWholePageSize'])){
    $pageSize=$_SESSION['ATWholePageSize'];
}
//echo sizeof($data);
//sizeof($data):数据总条数,15:每页大小
_page(sizeof($data),$pageSize);

$urlCon='baseType='.$_GET['baseType'].'&';

?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <?php
    //echo ROOT_PATH.'includes/title.inc.php';
    require ROOT_PATH.'includes/title.inc.php';
    ?>
    <!--  <script type="text/javascript" src="js/baseManage.header.js"></script>-->
    <script type="text/javascript" src="js/baseManage.inc1.js"></script>

</head>
<body>
<?php
require ROOT_PATH.'includes/header.inc.php';
?>

<div id="baseManage">
    <?php
    require ROOT_PATH.'includes/baseManage.inc.php';
    ?>
    <div id="baseManageMain">
        <h2><?php echo $_GET['baseType'].'数据查询结果'?></h2>
        <form method="post" action="?action=delete">
        <table cellspacing="1">
            <tr>
                <th>id</th>
                <th>年份</th>
                <th>年暴雨日</th>
                <th>1月气温</th>
                <th>2月气温</th>
                <th>3月气温</th>
                <th>4月气温</th>
                <th>5月气温</th>
                <th>6月气温</th>
                <th>7月气温</th>
                <th>8月气温</th>
                <th>9月气温</th>
                <th>10月气温</th>
                <th>11月气温</th>
                <th>12月气温</th>
                <th>年平均气温</th>
                <th>年最低气温</th>
                <th>年最高气温</th>
                <th>年蒸发量</th>
               <?php if ($_SESSION['authority']==1 || $_SESSION['authority']==2){?> <th>删除</th><?php };?>
            </tr>
            <?php
            global $_pagenum,$_num,$_page,$_pageabsolute,$_pagesize;
            /*echo $_pagenum,$_num,$_page.'<br/>';
            echo $_pageabsolute,$_pagesize;*/
            if($_page!=$_pageabsolute){
                $newPageSize=$_pagesize;
            }else{
                //$_pagenum以0为最最原始的开始
                $newPageSize=$_num-$_pagenum;
            }
            //echo $newPageSize;
                for($i=0;$i<$newPageSize;$i++){
                    ?>
                    <tr>
                        <?php

                           /* foreach($data[$_pagenum+$i] as $key=>$value){

                                 echo '<td>'.$key.'...'.$value.'</td>';

                            }*/


                        ?>
                        <td><?php echo $data[$_pagenum+$i]["id"]?></td>
                        <td><?php echo $data[$_pagenum+$i]["datetime"]?></td>
                        <td><?php echo $data[$_pagenum+$i]["arsd"]?></td>
                        <td><?php echo $data[$_pagenum+$i]["jan"]?></td>
                        <td><?php echo $data[$_pagenum+$i]["feb"]?></td>
                        <td><?php echo $data[$_pagenum+$i]["mar"]?></td>
                        <td><?php echo $data[$_pagenum+$i]["apr"]?></td>
                        <td><?php echo $data[$_pagenum+$i]["may"]?></td>
                        <td><?php echo $data[$_pagenum+$i]["june"]?></td>
                        <td><?php echo $data[$_pagenum+$i]["july"]?></td>
                        <td><?php echo $data[$_pagenum+$i]["aug"]?></td>
                        <td><?php echo $data[$_pagenum+$i]["sept"]?></td>
                        <td><?php echo $data[$_pagenum+$i]["oct"]?></td>
                        <td><?php echo $data[$_pagenum+$i]["nov"]?></td>
                        <td><?php echo $data[$_pagenum+$i]["dec"]?></td>
                        <td><?php echo $data[$_pagenum+$i]["aaat"]?></td>
                        <td><?php echo $data[$_pagenum+$i]["aminat"]?></td>
                        <td><?php echo $data[$_pagenum+$i]["amaxat"]?></td>
                        <td><?php echo $data[$_pagenum+$i]["aec"]?></td>




                        <?php if ($_SESSION['authority']==1 || $_SESSION['authority']==2){?><td><input type="checkbox" name="ids[]" value="<?php echo $data[$_pagenum+$i]["id"];?>"  /></td><?php };?>

                    </tr>
            <?php

                }

            ?>
            <?php if ($_SESSION['authority']==1 || $_SESSION['authority']==2){?><tr><td colspan="20" class="selectAll"><label for="all" >全选 <input type="checkbox" name="chkall" id="all" /></label>&nbsp&nbsp<label for="reverse" >反选 <input type="checkbox" name="reverse" id="reverse" /></label> &nbsp&nbsp<input type="submit" value="批删除" /></td></tr><?php };?>
            <tr>
                <td colspan="20">
                    每页条数：
                    <a  href="?<?php echo $urlCon."pageSize=15"; ?>">15</a>&nbsp&nbsp
                    <a  href="?<?php echo $urlCon."pageSize=50"; ?>">50</a>&nbsp&nbsp
                    <a  href="?<?php echo $urlCon."pageSize=100";  ?>">100</a>&nbsp&nbsp
                    <a  href="?<?php echo $urlCon."pageSize=1000";  ?>">1000</a>&nbsp&nbsp

                </td>
            </tr>
        </table>
        </form>
       <?php _paging(2);?>
    </div>
</div>


<?php
require ROOT_PATH.'includes/footer.inc.php';
?>
<!--<script type="text/javascript" src="js/wholeSearch.js"></script>-->

</body>
</html>


