﻿<?php
/**
* TestGuest Version1.0
* ================================================
* Copy 2010-2012 yc60
* Web: http://www.yc60.com
* ================================================
* Author: Lee
* Date: 2010-8-10
*/
header("Content-Type:text/html;charset=utf-8");

//echo dirname(__FILE__);
//转换硬路径常量
ob_start();
session_start();
define('IN_TG',true);
//定义个常量，用来指定本页的内容
define('SCRIPT','index');
require_once('includes/common.inc.php');
global $_system;
//echo 2;
$_SESSION['tableName']=NULL;
$_SESSION['tableCh']=NULL;
/*if(!empty($_COOKIE['username'])){
    if($rows['loginstate']=='t'){
        _alert_back('你的账号已经在其他地方登陆');
    }
}*/
//开始处理登录状态
if ($_GET['action'] == 'login') {
	/*if (!empty($_system['code'])) {
		//为了防止恶意注册，跨站攻击
		_check_code($_POST['code'], $_SESSION['code']);
	}*/
//引入验证文件
	include ROOT_PATH . 'includes/login.func.php';
//接受数据
	$_clean = array();
	$_clean['username'] = _check_username($_POST['username'], $_system['usernameMinLength'],  $_system['usernameMaxLength']);
	$_clean['password'] = _check_password($_POST['password'], $_system['passwordMinLength']);
	//echo $_clean['username'];
//$_clean['time'] = _check_time($_POST['time']);
//到数据库去验证,php的变量写到sql语句中时，如果不是数字，则需要加上引号,sql语句中引用变量必须要加花括号
	global $_conn;
	$sql = <<<EOF
			SELECT username,authority,loginstate,active From djhuser WHERE username='{$_clean['username']}' AND password='{$_clean['password']}';
EOF;
//echo $sql;
	$result = pg_query($sql);
//$rows=pg_fetch_array($result,PGSQL_ASSOC);
	$rows = pg_fetch_assoc($result);

	if (!!$rows) {
		//echo $rows['username'];
		//不允许用户异地登录

		if ($rows['active'] == 'f') {
			_alert_back('你的账号未激活');
		}
		//根据登录ip查找登录地址:note:::1查不到结果，127.0.0.1也查不到，所以特殊处理
        /*echo $_SERVER['REMOTE_ADDR'];
        echo getIPLoc_sina($_SERVER['REMOTE_ADDR']);*/
       // echo getIPLoc_QQ($_SERVER['REMOTE_ADDR']);
// || preg_match('/^172\.[16-31]\..*/',$_SERVER['REMOTE_ADDR']) || preg_match('/^192\.168\.[0-25]\..*/',$_SERVER['REMOTE_ADDR'])
        //获取第二段，第三段间的数组
        $ipArray=explode('.',$_SERVER['REMOTE_ADDR']);

        if ($_SERVER['REMOTE_ADDR']=="::1" || $_SERVER['REMOTE_ADDR']=='127.0.0.1'){
            $location='本机/湖南长沙';
        }elseif(preg_match('/^10.*/',$_SERVER['REMOTE_ADDR']) ){
            $location='当前局域网内/湖南长沙';
        }elseif( $ipArray[0]=='172' && intval($ipArray[1])>=16 && intval($ipArray[1])<=31){
            $location='当前局域网内/湖南长沙';
        }elseif( $ipArray[0]=='192' && intval($ipArray[1])==168 && intval($ipArray[2])<=25 && intval($ipArray[2])>=0){
            $location='当前局域网内/湖南长沙';
        }
        else{
            $location=getIPLoc_sina($_SERVER['REMOTE_ADDR']);
        }
       /* echo $_SERVER['REMOTE_ADDR'];
        echo $location;
        exit();*/
       //broswer,os
        $broswer=get_broswer();
        $os=get_os();
        /*echo $location;
        echo $os;
        echo $broswer;
        exit();*/
        //登陆成功后，更改登录信息
		$updateSql = <<<EOF
				UPDATE djhuser SET 
									loginstate=true,
									lasttime=NOW(),
									lastip='{$_SERVER['REMOTE_ADDR']}',
									logincount=logincount+1,
									location='{$location}',
									broswer='{$broswer}',
									os='{$os}'
							  WHERE
									username='{$rows['username']}';
EOF;
		/*echo 11;
        echo $updateSql;
        exit();*/

		pg_query($updateSql);
		//_setcookies($_clean['username']);
		/*echo $_clean['username'];
		exit()*/;
		setcookie('username',$_clean['username']);
		setcookie('loginTime', time());
		ob_end_flush();
		//setcookie('loginIp',$_SERVER['REMOTE_ADDR']);
		//慢半拍要刷新

		//echo $_COOKIE['username'];
		/*if ($rows['authority'] == 1) {
			$_SESSION['authority'] = 1;
			$_SESSION['superUser'] = $_clean['username'];
		} elseif ($rows['authority'] == 2) {
			$_SESSION['authority'] = 2;
			$_SESSION['admin'] = $_clean['username'];
		}*/
		//
		if($rows['authority']>=1){
			$_SESSION['admin'] = $_clean['username'];
		}
		//记录用户所属部门
		//echo $_SESSION['admin'];
		//pg_close();
		//pg_errormessage($_conn);
		//设置了cookie，重新刷新，解决cookie 慢半拍的问题
		_location(null, 'index.php?login=true');
	} else {
		_close();
		//echo "failed";
		_session_destroy();
		_location('用户名密码不正确或者该账户未被激活！', 'index.php?fres=new');
	}
}
/*echo $_SESSION['admin'];
echo $_COOKIE['username'];*/
//maiup访问权限
$_SESSION['mainUpFlag']=0;
require_once ('includes/resolutionRatio.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title><?php echo '湖南省郴州东江湖水资源管理'?></title>
	<link rel="shortcut icon" href="dongjianghu.ico" />
	<script type="text/javascript" src="js/jquery-3.1.0.min.js"></script>
	<link rel="stylesheet" type="text/css" href="js/jQuery-jcDate-master/src/jcDate.css" media="all" />
	<script type="text/javascript" src="js/jQuery-jcDate-master/src/jQuery-jcDate.js" charset="utf-8"></script>
	<script type="text/javascript" src="js/baseManage.inc1.js"></script>
<script type="text/javascript" src="popUp.js"></script>

<style type="text/css">
	* {
		padding:0;
		margin:0;
	}
    body {
        font-size:1.0em;
    }
    @media (min-width: 1152px) {
        body {

            font-size: 1.1em;

        }
    }
    @media (min-width: 1280px) {
        body {

            font-size: 1.2em;

        }
    }
    @media (min-width: 1360px) {
        body {

            font-size: 1.2em;

        }
    }


	a:link {
		text-decoration: none;
	}
	a:visited {
		text-decoration: none;
	}
	a:hover {
		text-decoration: underline;
		color: #0F0;
	}
	a:active {
		text-decoration: none;
	}

	body {

		width:100%;
		margin:0 auto;
		background-color: #cfd4ff;
		position:relative;
	}
	#header {
		width:100%;
		background:url(images/top.png);
		height:85px;
	}
	#header p.title{
		height: 80px;
		width:38%;
		font-size: 1.25em;
		margin: 0px 0px;
		text-decoration: none;
		text-indent: 0px;
		line-height: 80px;
		font-family: 黑体,"Reenie Beanie",arial,sans-serif,微软雅黑;
		font-weight: 300;
		color: white;
		background-image: url(images/title_log3.png);
		background-repeat: no-repeat;
		background-position: left;
		padding-left: 50px;

		float:left;
	}
	#header ul {
		width:56%;
		text-align: right;
		vertical-align: middle;
		line-height: 80px;
		font-size: 0.8em;
		font-family: 黑体;
		margin-right: 10px;
		color: white;
		float:right;
	}

	#header ul li {
		display:inline;
		height:40px;
		line-height: 40px;
	}
	#header ul li a{
		color:white;
	}
	#header ul li a:hover{
		color:yellow;
	}
	#header ul #configure{
		background:url(images/configure.png) no-repeat left;
        height: 110px;
		background-size:contain;
		padding-left:2.5%;
position: relative;
	}
	#header ul li.headerUser{
		color:yellow;
	}
	#header ul #conflog{
		margin-left: -5px;
		background:url(images/donwarrow.png) no-repeat left;
		background-size:contain;
		width: 2%;
		height: 100px;
		padding-left:2%;

	}
	#header ul #configure #conf {
		position: absolute;
		border: 2px solid #669;
		left:0px;
		top:90%;
		text-align:center;
		margin-left: 0;
		padding-left: 0;
		width: 120%;
		height: 170px;
		z-index: 2;
		font-size: 1em;
		background-color: #36C;
		display: none;
	}
	#header ul #configure #conf table{
		margin:0px auto ;
	}
	#header ul #help{
		margin-left:1%;
		background:url(images/help.png) no-repeat left;
		background-size:contain;
		width: 20px;
		height: 20px;
		padding-left:3%;
	}
	#header ul li.logout{
		background:url(images/logout.png) no-repeat left ;
		background-size:contain;
		width: 20px;
		height: 20px;
		padding-left:3%;
	}
	#header ul form{
		display:inline;
	}
	#header ul form input{
		width:9%;
		font-size:0.9em;
	}
	#header ul form input.password{
		width:9%;
	}
	#header ul form input.login{
		width:8%;
		/*background: url("../../images/login.gif");*/
	}
	#header ul form input.register{
		/*-webkit-appearance: none; -moz-appearance: none; -o-appearance: none; appearance: none;
        background: url("../../images/register.gif");*/
		width:8%;
	}

	#header ul #configure #conf table {
		text-align: center;
	}

	#img{
		margin:0 auto;
		margin-top: -2px;
		width:100%;
	}
	#img p.welcom{
		text-align: left;
	}
	#dianti{
		width:100%;
	}
	#userInfo{
		margin:15px;
		width:15%;
		height:200px;
		background:white;
		text-align: center;
		line-height: 30px;
		padding-bottom: 1px;
		border: 1px solid #CBC9C9;
		background: #fff;
		border-radius: 5px;
		color: #8791ff;
	}
	#userInfo p.userInfoTitle{
		height:50px;
		line-height: 50px;

	}
	#userInfo p.userInfoTitle span{
		font-weight: bolder;
		color: #000000;
	}
	div.module{
		margin:15px;
		width:37%;
		height:auto;
		text-align: center;
		/*font-size:40px;*/
		line-height: 150px;

		padding-bottom: 1px;
		border: 1px solid #CBC9C9;
		background: #fff;
		border-radius: 5px;
		float: left;
	}
	div.module dt{
		font-size:1.2em;
		font-family: 黑体;
		border-bottom:1px solid;
	}
	#dataManage{
	/*position:absolute;
        top:280px;
        left:200px;*/
		/*border:1px solid #ccc;*/
	padding-bottom: 5px;
	border: 1px solid #CBC9C9;
	border-radius: 5px;
	/*height:140px;*/
	height: auto;
	text-align: center;
	line-height: 30px;
	font-size: 0.8em;
	background-color: #fff;
	padding-top: 5px;
	padding-right: 5px;
	padding-left: 5px;
	}
	#dataManage table th{
		font-size: 0.9em;
		width:25%;
	}
	#dataManage p.shuiwen{
	height: 60px;
	line-height: 60px;
	padding-left: 55px;
	background-image: url('images/department4/shuiwen.jpg');
	background-repeat: no-repeat;
	background-position: left;
		 }
	#dataManage p.xumu{
		background: url(images/department4/xumu.jpg) no-repeat left;
		height: 60px;
		line-height: 70px;
		padding-left: 55px;
	}
	#dataManage p.huanbao{
		 background: url(images/department4/huanbao.jpg) no-repeat left;
		 height: 60px;
		 line-height: 70px;
		 padding-left: 55px;
	 }
	#dataManage p.qixiang{
		  background: url(images/department4/qixiang.jpg) no-repeat left;
		  height: 60px;
		  line-height: 70px;
		  padding-left: 55px;
	  }
	#dataManage p.shuiwei{
		   background: url(images/department4/shuiwei.jpg) no-repeat left;
		   height: 60px;
		   line-height: 70px;
		   padding-left: 55px;
	   }
	#dataManage p.nongye{
			background: url(images/department4/nongye.jpg) no-repeat left;
			height: 60px;
			line-height: 70px;
			padding-left: 55px;
		}
	#dataManage p.caizheng{
		background: url(images/department4/caizheng.jpg) no-repeat left;
		height: 60px;
		line-height: 70px;
		padding-left: 55px;
	}
	#dataManage p.yiming{
		background: url(images/department4/yiming.jpg) no-repeat left;
		height: 60px;
		line-height: 70px;
		padding-left: 55px;
	}
	#dataManage p.renli{
		 background: url(images/department4/renli.jpg) no-repeat left;
		 height: 60px;
		 line-height: 70px;
		 padding-left: 50px;
	 }
	#dataManage p.keji{
		background: url(images/department4/keji.jpg) no-repeat left;
		height: 60px;
		line-height: 70px;
		padding-left: 50px;
	}

	#dataManage table p.dataTitle{
		width:100%;
	}

	#dataAnalyze{
	padding-bottom: 1px;
	border: 1px solid #CBC9C9;
	background: #fff;
	border-radius: 5px;
	/*position:absolute;
        top:450px;
        left:200px;*/

	height: auto;
	text-align: center;
	line-height: 28px;
	padding: 5px;
	font-size: 0.8em;		/*display:none;*/
	}
.index #analyze #dataAnalyze dd table tr td {
	text-align: left;
	font-style: normal;
}
.index #manage #dataManage dt {
	color: #66F;
}
.index #analyze #dataAnalyze dt {
	color: #64F;
}


	#footer {
	margin-top: auto;
	clear: both;
	width: 100%;
	height: 60px;
	text-align: center;
	padding: 10px 0 0 0;
	border-top: solid 2px blueviolet;
	background-image: url(images/top.png);
	background-repeat: repeat;
	background-position: center;
	background-color: #60C;
	}
	#footer p {
		font-size:0.8em;
		letter-spacing:1px;
		padding:5px 0 0 0;
	}
	#footer p span {
		color:#06f;
	}
</style>
<!--<script src="SpryAssets/SpryEffects.js" type="text/javascript"></script>-->
	<script type="text/javascript">
		function MM_preloadImages() { //v3.0
			var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
				var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
					if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
		}

		function MM_swapImgRestore() { //v3.0
			var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
		}

		function MM_findObj(n, d) { //v4.01
			var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
				d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
			if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
			for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
			if(!x && d.getElementById) x=d.getElementById(n); return x;
		}

		function MM_swapImage() { //v3.0
			var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
				if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
		}
	</script>
</head>
<body class="index" onload="MM_preloadImages('images/chaxun.jpg','images/delete.jpg','images/modify.jpg','images/add.jpg','images/import.jpg','images/export.jpg','images/analyse.jpg','images/zhineng.jpg')">
<?php require_once ('includes/header.inc.php')?>

<div id="img">
	<img id="dianti" src="images/dianti.jpg"  alt="东江湖" /> </div>
<div id="left">
<div class="module" id="userInfo">
	<?php
		if(isset($_COOKIE['username'])){
			echo '<p class="userInfoTitle">您好，<span>'.$_COOKIE['username'].'</span>!</p>';
			echo '开始登录时间:';
			echo '<br/>';
			echo '<p class="welcom">'.''.date("Y年m月d日",$_COOKIE['loginTime']);
			echo '<br/>';
			$XQ = array('日', '一', '二', '三', '四', '五', '六');
			echo '星期'.$XQ[date("w",$_COOKIE['loginTime'])].date(" H:i:s",$_COOKIE['loginTime']);
			echo '<br/>';
			echo '已经登录:';
			echo '<br/>';
			/*
			echo time();
			echo '<br/>';
			echo $_COOKIE['loginTime'];
			echo '<br/>';
			$data= time()-$_COOKIE['loginTime'];
			echo date("H:i:s",$data);*/
			?>
			<span id="pastTime">0:0:0</span>
	<?php
			echo '</p>';
		}else{
			echo '你好，欢迎使用东江湖流域数据综合管理与智能分析系统';
		}

	?>
</div>
<!--试试看-->

<!--试试看-->
	<div id="science">
		<table>

		</table>
	</div>

</div>
<div class="module" id="manage" >
	<!--<p>综合数据管理</p>-->
	<dl id="dataManage">
		<dt>数据资源类别</dt>
		<dd>&nbsp;</dd>
		<dd>
		  <table  height="900" border="0">
			  <tr>
				  <th height="70" scope="row"><p class="keji">科技</p></th>
				  <td width=35%><p><img src="images/database1.jpg" width=30% height="30" alt="数据库" /></p>
					  <p class="dataTitle"> 气象站数据</p></td>
				  <td width=20%><p><img src="images/database1.jpg" width=45% height="30" alt="数据库" /></p>
					  <p class="dataTitle"> 测流堰数据</p></td>
				  <td  width=20%><p><img src="images/database1.jpg" width=45% height="30" alt="数据库" /></p>
					  <p class="dataTitle"> 径数据</p></td>
			  </tr>
		    <tr>
		      <th height="63" valign="middle" scope="row"><p class="shuiwen"> 水文</p></th>
		      <td width="176"><p><img src="images/database1.jpg" width=30% height="30" alt="数据库" /></p>
	          <p>降雨量与流量统计信息</p></td>
		      <td width="95"><!--<p><img src="images/database1.jpg" width=30% height="30" alt="数据库" /></p>
              <p>待定</p>--></td>
		      <td width="50"><!--<p><img src="images/database1.jpg" width=30% height="30" alt="数据库" /></p>
              <p>待定</p>--></td>
	        </tr>
		    <tr>
		      <th height="50" scope="row"><p class="huanbao"> 环保</p></th>
		      <td><p><img src="images/database1.jpg" width=30% height="30" alt="数据库" /></p>
		        <p>水资源数据检测信息</p></td>
		      <td>&nbsp;</td>
		      <td>&nbsp;</td>
	        </tr>
		    <tr>
		      <th height="50" scope="row"><p class="shuiwei"> 水位</p></th>
		      <td><p><img src="images/database1.jpg" width=30% height="30" alt="数据库" /></p>
		        <p> 东江湖水位信息</p></td>
		      <td>&nbsp;</td>
		      <td>&nbsp;</td>
	        </tr>
		    <tr>
		      <th height="69" scope="row"><p class="qixiang">气象</p></th>
		      <td><p><img src="images/database1.jpg" width=30% height="30" alt="数据库" /></p>
		        <p> 81-13年月温度信息</p></td>
		      <td>&nbsp;</td>
		      <td>&nbsp;</td>
	        </tr>
		    <tr>
		      <th height="47" scope="row"><p class="xumu"> 畜牧</p></th>
		      <td><p><img src="images/database1.jpg" width=30% height="30" alt="数据库" /></p>
		        <p> 牲畜养殖信息</p></td>
		      <td>&nbsp;</td>
		      <td>&nbsp;</td>
	        </tr>
		    <tr>
		      <th height="48" scope="row"><p class="nongye"> 农业</p></th>
		      <td><p><img src="images/database1.jpg" width=30% height="30" alt="数据库" /></p>
		        <p>人口资产统计信息</p></td>
		      <td>&nbsp;</td>
		      <td>&nbsp;</td>
	        </tr>
		    <tr>
		      <th height="70" scope="row"><p class="renli"> 人力</p></th>
		      <td><p><img src="images/database1.jpg" width=30% height="30" alt="数据库" /></p>
		        <p> 人口出生死亡统计信息</p></td>
		      <td>&nbsp;</td>
		      <td width="50">&nbsp;</td>
	        </tr>
		    <tr>
		      <th height="70" scope="row"><p class="yiming"> 移民</p></th>
		      <td><p><img src="images/database1.jpg" width=30% height="30" alt="数据库" /></p>
		        <p> 人口变动信息</p></td>
		      <td>&nbsp;</td>
		      <td>&nbsp;</td>
	        </tr>
		    <tr>
		      <th height="70" scope="row"><p class="caizheng">财政</p></th>
		      <td><p><img src="images/database1.jpg" width=30% height="30" alt="数据库" /></p>
              <p> 财政统计信息</p></td>
		      <td><p>&nbsp;</p></td>
		      <td>&nbsp;</td>
	        </tr>

		    <tr>
		      <th height="21" scope="row">&nbsp;</th>
		      <td colspan="3">&nbsp;</td>
	        </tr>
	      </table>
	  </dd>
		<!--<<dd><a href="baseManage.php?baseType=水文">水文数据库</a></dd>
		<dd><a href="baseManage.php?baseType=环保">环保数据库</a></dd>
		<dd><a href="baseManage.php?baseType=气象">气象数据库</a></dd>
		<dd><a href="baseManage.php?baseType=统计">人口统计数据库</a></dd>
		<dd><a href="baseManage.php?baseType=农调">人均收入数据库</a></dd>
		<dd><a href="baseManage.php?baseType=农调">人均收入数据库</a></dd>
		<dd><a href="baseManage.php?baseType=农调">人均收入数据库</a></dd>
		<dd><a href="baseManage.php?baseType=农调">人均收入数据库</a></dd>
		<dd><a href="baseManage.php?baseType=农调">人均收入数据库</a></dd>
		<dd><a href="baseManage.php?baseType=农调">更多>></a></dd>-->

	</dl>

</div>
<div class="module" id="analyze">
	<!--<p>综合数据分析</p>-->
	<dl class="operator" id="dataAnalyze">
		<dt>数据操作分析</dt>
		<dd>&nbsp;</dd>
		<dd>
		  <table  height="900">
		    <tr>
		      <th width="124" class="operate" scope="row"><p><a href="search.php"><img src="images/search.png" alt="查询" width="40" height="40" id="Image1" onmouseover="MM_swapImage('Image1','','images/search2.png',1)" onmouseout="MM_swapImgRestore()" /></a></p>
	          <p><a href="search.php">查询</a></p></th>
		      <td width="440" style="font-style: normal">查询符合条件的相关数据并做后续修改。</td>
	        </tr>
		    <tr>
		      <th  class="operate" scope="row" onmouseover="MM_effectHighlight(this, 1000, '#ffffff', '#ff0000', '#ffffff', false)"><p><a href="delete.php"><img src="images/delete.png" alt="查询" width="29" height="32" id="Image2" onmouseover="MM_swapImage('Image2','','images/delete2.png',1)" onmouseout="MM_swapImgRestore()" /></a></p>
              <p><a href="delete.php">删除</a></p></th>
		      <td style="font-style: normal">在数据库中删除符合条件的记录。</td>
	        </tr>
		    <tr>
		      <th class="operate" scope="row"><p><a href="modify.php"><img src="images/modify.png" alt="查询" width="40" height="40" id="Image3" onmouseover="MM_swapImage('Image3','','images/modify2.png',1)" onmouseout="MM_swapImgRestore()" /></a></p>
              <p><a href="modify.php">修改</a></p></th>
		      <td style="font-style: normal">修改数据库中记录的字段值。</td>
	        </tr>
		    <tr>
		      <th class="operate" scope="row"><p><a href="write.php"><img src="images/write.png" alt="查询" width="40" height="40" id="Image4" onmouseover="MM_swapImage('Image4','','images/write2.png',1)" onmouseout="MM_swapImgRestore()" /></a></p>
              <p><a href="write.php">录入</a></p></th>
		      <td style="font-style: normal">手工逐条地向数据库中录入记录。</td>
	        </tr>
		    <tr>
		      <th class="operate" scope="row"><p><a href="import.php"><img src="images/import.png" alt="查询" width="40" height="40" id="Image5" onmouseover="MM_swapImage('Image5','','images/import2.png',1)" onmouseout="MM_swapImgRestore()" /></a></p>
              <p><a href="import.php">导入</a></p></th>
		      <td style="font-style: normal">自动批量地向数据库灌入记录。</td>
	        </tr>
		    <tr>
		      <th class="operate" scope="row"><p><a href="export.php"><img src="images/export.png" alt="查询" width="40" height="40" id="Image6" onmouseover="MM_swapImage('Image6','','images/export2.png',1)" onmouseout="MM_swapImgRestore()" /></a></p>
              <p><a href="export.php">导出</a></p></th>
		      <td style="font-style: normal">自动批量地从数据库导出数据。</td>
	        </tr>
		    <tr>
		      <th class="operate" scope="row"><p><a href="statisticalAnalyze.php"><img src="images/tongjifenxi.jpg" alt="统计分析" name="Image7" width="40" height="47" id="Image7" onmouseover="MM_swapImage('Image7','','images/tongjifenxi2.jpg',1)" onmouseout="MM_swapImgRestore()" /><a href="statisticalAnalyze.php"></p>
              <p><a href="statisticalAnalyze.php">统计分析</a></p></th>
		      <td>对数据集进行简单统计分析。</td>
	        </tr>
		    <tr>
				 <th height="105" class="operate" scope="row" onmouseover="MM_effectHighlight(this, 1000, '#ffffff', '#0033FF', '#0033FF', true)" onmouseout="MM_effectHighlight(this, 1000, '#0033FF', '#FFFFFF', '#ffffff', true)"><p><a href="intelAnalyze.php"><img src="images/zhinengfenxi.png" alt="查询" width="40" height="40" id="Image8" onmouseover="MM_swapImage('Image8','','images/zhinengfenxi2.png',1)" onmouseout="MM_swapImgRestore()" /></a></p>
              <p><a href="intelAnalyze.php">智能分析</a></p></th>
		      <td style="font-style: normal">用智能信息处理技术深度分析数据集。</td>
	        </tr>
			  <tr>
				  <th height="105" class="operate" scope="row" onmouseover="MM_effectHighlight(this, 1000, '#ffffff', '#0033FF', '#0033FF', true)" onmouseout="MM_effectHighlight(this, 1000, '#0033FF', '#FFFFFF', '#ffffff', true)"><p><a href="backup.php"><img src="images/backup.png" alt="查询" width="40" height="40" id="Image9" onmouseover="MM_swapImage('Image9','','images/backup2.png',1)" onmouseout="MM_swapImgRestore()" /></a></p>
					  <p><a href="backup.php">数据库保护</a></p></th>
				  <td style="font-style: normal">对数据库进行备份、迁移或还原操作。</td>
			  </tr>
			  <tr>
				  <th height="105" class="operate" scope="row" onmouseover="MM_effectHighlight(this, 1000, '#ffffff', '#0033FF', '#0033FF', true)" onmouseout="MM_effectHighlight(this, 1000, '#0033FF', '#FFFFFF', '#ffffff', true)"><p><a href="reportSelect.php"><img src="images/report.png" alt="查询" width="40" height="40" id="Image10" onmouseover="MM_swapImage('Image10','','images/report2.png',1)" onmouseout="MM_swapImgRestore()" /></a></p>
					  <p><a href="reportSelect.php">报表</a></p></th>
				  <td style="font-style: normal">将数据库信息做成报表。</td>
			  </tr>
		    <tr>
		      <th height="59" class="operate" scope="row"><p>&nbsp;</p></th>
		      <td>&nbsp;</td>
	        </tr>
	      </table>
	  </dd>
	</dl>
</div>
<!--11111-->
<div   id="divStayTopleft" style="POSITION: left" >
<table>
<tr>
<a target="_blank" href="tencent://message/?uin=670623858&Site=qq&Menu=yes"><img border="0" src="http://wpa.qq.com/pa?p=1:670623858:16"></a>
</tr>
<table>
</div> 
<!--11111-->
<!--22222-->
<div   style="POSITION: right" >
<table>
<tr>
<a target="_top" href="/testemail/sendemailtest.php"><img width="60px" src="/images/email.png"></a>
</tr>
<table>
</div> 
<!--222222-->


<?php require_once("includes/footer.inc.php")?>
<script src="js/index.js" type="text/javascript"></script>
</body>
</html>
