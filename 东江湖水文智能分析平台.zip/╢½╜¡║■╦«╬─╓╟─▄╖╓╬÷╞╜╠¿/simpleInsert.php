<?php
/**
 * TestGuest Version1.0
 * ================================================
 * Copy 2010-2012 yc60
 * Web: http://www.yc60.com
 * ================================================
 * Author: Lee
 * Date: 2010-9-2
 */
header("Content-Type:text/html;charset=utf-8");
require_once("http://localhost:8080/JavaBridgeTemplate611/java/Java.inc");
header("Cache-Control: no-cache");
session_start();
//$method=$_GET['baseType'];
//$simpleInsert=new Java("FileInsert");
if($_SESSION['authority']==1 ||$_SESSION['authority']==2) {
    if ($_SESSION['department'] == "水文") {
        $insert = new Java("HYInsert");
        $insert->exe();
        // $simpleInsert->FileInsert();
        // $simpleInsert->HYInsert();
        //$simpleInsert->__construct();
        echo "quite";
    } elseif($_SESSION['department']=="气象"){
        $insert = new Java("ATInsert");
        $insert->exe();
    } elseif($_SESSION['department']=="环保"){
        $insert = new Java("WQMInsert");
        $insert->exe();
    }elseif($_SESSION['department']=="统计"){
        $insert = new Java("ZXCInsert");
        $insert->exe();
    }elseif($_SESSION['department']=="农调"){
        $insert = new Java("RPCInsert");
        $insert->exe();
    }
}
?>
