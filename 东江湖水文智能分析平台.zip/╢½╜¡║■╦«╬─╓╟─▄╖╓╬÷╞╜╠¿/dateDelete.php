<?php
/**
 * TestGuest Version1.0
 * ================================================
 * Copy 2010-2012 yc60
 * Web: http://www.yc60.com
 * ================================================
 * Author: Lee
 * Date: 2010-9-2
 */
header("Content-Type:text/html;charset=utf-8");
header("Cache-Control: no-cache");
session_start();
require_once("http://localhost:8080/JavaBridgeTemplate611/java/Java.inc");
/*$baseType=$_GET['baseType'];*/
if($_SESSION['authority']==1 ||$_SESSION['authority']==2) {
    if ($_SESSION['department']=="水文") {
        $simpleDelete = new Java("HYDelete");
        $simpleDelete->DateDelete($_POST['date']);
        //echo "quite";
    } elseif($_SESSION['department']=="气象"){
        $simpleDelete = new Java("ATDelete");
        $simpleDelete->DateDelete($_POST['date']);
    }elseif($_SESSION['department']=="环保"){
        $simpleDelete = new Java("WQMDelete");
        $simpleDelete->DateDelete($_POST['date']);
    }elseif($_SESSION['department']=="统计"){
        $simpleDelete = new Java("ZXCDelete");
        $simpleDelete->DateDelete($_POST['date']);
    }elseif($_SESSION['department']=="农调"){
        $simpleDelete = new Java("RPCIDelete");
        $simpleDelete->DateDelete($_POST['date']);
    }


}

?>
