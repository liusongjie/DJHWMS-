<?php
/**
 * Created by PhpStorm.
 * User: hetong
 * Date: 2016/9/3
 * Time: 20:03
 */
header("Content-Type:text/html;charset=utf-8");
header("Cache-Control: no-cache");

$minus= time()-$_COOKIE['loginTime'];
$data=date("H:i:s",$minus);

//echo $data;
echo json_encode($data);

?>