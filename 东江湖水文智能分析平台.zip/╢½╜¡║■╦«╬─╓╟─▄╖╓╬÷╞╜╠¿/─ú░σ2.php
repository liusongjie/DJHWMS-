<?php
header("Content-Type:text/html;charset=utf-8");
session_start();
//定义个常量，用来授权调用includes里面的文件
define('IN_TG',true);
//定义个常量，用来指定本页的内容
define('SCRIPT','search');
//引入公共文件
require dirname(__FILE__).'/includes/common.inc.php';

if($_GET['tableCh']=='水文信息'){
  // 得到所有字段名
  /*$sql=<<<EOF
      SHOW FULL COLUMNS FROM HYDRAULICTABLE;
      EOF;*/
  //setcookie('tableName','hydraulictable');
  $_SESSION['tableCh']="水文信息";
  $_SESSION['tableName']='hydraulictable';


  /*$ziduanDis=pg_fetch_assoc($result);
  print_r($ziduanDis);*/
 //$_GET['tableCH']=='气象信息':要区分大小写
}elseif($_GET['tableCh']=='气象信息'){
  $_SESSION['tableCh']="气象信息";
  $_SESSION['tableName']='attable';
}elseif($_GET['tableCh']=='统计信息'){
  $_SESSION['tableCh']="统计信息";
    $_SESSION['tableName']='zxctable';
}elseif($_GET['tableCh']=='农调信息'){
  $_SESSION['tableCh']="农调信息";
  $_SESSION['tableName']='wqmtable';
} elseif($_GET['tableCh']=='环保信息'){
  $_SESSION['tableCh']="环保信息";
  $_SESSION['tableName']='wqmtable';
}
$sql=<<<EOF
SELECT a.attname, a.attnotnull as notnull FROM pg_class as c,pg_attribute as a  where c.relname = '{$_SESSION['tableName']}' and a.attrelid = c.oid and a.attnum>1
EOF;
//echo $sql;
$result=pg_query($sql);
while($row=pg_fetch_assoc($result)){
  $fields[]=$row;
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

  <title><?php echo '湖南省郴州东江湖水资源管理'?></title>
  <link rel="shortcut icon" href="dongjianghu.ico" />
  <script type="text/javascript" src="js/jquery-3.1.0.min.js"></script>
  <link rel="stylesheet" type="text/css" href="js/jQuery-jcDate-master/src/jcDate.css" media="all" />
  <script type="text/javascript" src="js/jQuery-jcDate-master/src/jQuery-jcDate.js" charset="utf-8"></script>
  <script type="text/javascript" src="js/baseManage.inc1.js"></script>

<style type="text/css">
/*#header {
	height: 80px;
	z-index: 1;
	background-image: url(images/top1.png);
	background-repeat: repeat;
	line-height: 80px;
	vertical-align: middle;
	visibility: visible;
}*/
body {
  width:1420px;
  margin:0 auto;
  background-color: #cfd4ff;
  font-size:20px;
}
#header {
  width:100%;
  background:url(images/top.png);
  height:72px;
}
img.titile{
    display:inline;
}
#header p.title{
	height: 80px;
	font-size: 32px;
	margin: 0px 0px;
	text-decoration: none;
	text-indent: 0px;
	line-height: 80px;
	font-family: 黑体,"Reenie Beanie",arial,sans-serif,微软雅黑;
	font-weight: 300;
	color: white;
	background-image: url(images/djh-logo.png);
	background-repeat: no-repeat;
	background-position: left;
	padding-left: 50px;
	
	float:left;
}
#header ul {
	text-align: right;
	vertical-align: middle;
	line-height: 80px;
	font-size: 16px;
	font-family: 黑体;
	margin-right: 30px;
	color: white;
	float:right;
}

#header ul li {
	display:inline;
    height:40px;
	line-height: 40px;
}
#header ul li a{
	color:white;
	}
	#header ul li a:hover{
	color:yellow;
	}
#header ul #configure{
    background:url(images/configure.png) no-repeat left;
    width: 20px;
    height: 110px;
    padding-left:20px;
}
#header ul li.headerUser{
    color:yellow;
}
#header ul #conflog{
    margin-left: -5px;
    background:url(images/donwarrow.png) no-repeat left;
    width: 20px;
    height: 100px;
    padding-left:20px;
}
#header ul #help{
    background:url(images/help.png) no-repeat left;
    width: 20px;
    height: 20px;
    padding-left:20px;
}
#header ul li.logout{
    background:url(images/logout.png) no-repeat left;
    width: 20px;
    height: 20px;
    padding-left:20px;
}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
	background-image: url(images/database1.jpg);
	background-position: top;
	padding-top: 60px;
}
a:hover {
	text-decoration: underline;
	color: #0F0;
	padding-top: 40px;
}
a:active {
	text-decoration: none;
}
#conf {
	position: absolute;
	border: 2px solid #669;
	left: 1135px;
	top: 62px;
	width: 121px;
	height: 152px;
	z-index: 2;
	font-size: 16px;
	background-color: #36C;
	display:none;
}
#header ul #configure #conf table {
	text-align: center;
}
#selectDB {
	width: 98%;
	height: auto;
	z-index: 2;
	font-size: 18px;
	background-color: #FFFFFF;
	border-radius: 8px;
	margin-top: 5px;
	margin-right: 10px;
	margin-bottom: 5px;
	margin-left: 15px;
	vertical-align: center;
	padding: 0px;
}
#selectDB h2{
	margin:auto;
	text-align: center;
}
#selectDB p{
	background-image: url(images/database1.jpg);
	background-repeat: no-repeat;
	background-position: top;
	padding-top: 29px;
	text-align: center;
	font-size:16px;
}
#selectDB form .department {
	font-weight: bold;
	margin-left: 20px;
	line-height: 30px;
	padding-top: 0px;
	padding-right: 0px;
	padding-bottom: 10px;
	padding-left: 10px;
}

#mainUp {
	width: 98%;
	height: auto;
	z-index: 1;
	margin-top: -15px;
	margin-right: 10px;
	margin-bottom: 10px;
	margin-left: 15px;
	background-color: #FFF;
	border-radius: 8px;
	font-size: 18px;
}
#selectDB h2 strong {
	font-weight: bold;
	color: #36C;
}
#mainUp #operateTitle {
	height: 30px;
	border-bottom-width: 2px;
	border-bottom-style: none;
	border-bottom-color: #399;
	vertical-align: middle;
	text-align: center;
}
h2 {
	color: #39C;
	font-weight: bold;
}
h2 {
	color: #36C;
}
.title2 {
	font-size: 18px;
}
.title2 {
	font-weight: bold;
}
#selectDB form table tr {
	height: 20px;
}
#mainUp form ul {
	list-style-type: none;
	height:120px; 
	width:1300px;
	overflow:auto;
}
#mainUp form ul li{

	display:inline-block;
	width:620px;
	height:35px;
}
#mainUp form ul li span.searchInfo{
	display:inline-block;
	/*border:red solid 1px;*/
	width:350px;
}
#mainUp form ul li span.searchInput{
	width:180px;
}
#mainUp form ul input.searchInput{
	width:80px;
	}
	
#mainUp form ul.displaySelect{

	height:auto;
	max-height:110px; 
	width:1300px;
	overflow:auto;
}
#mainUp form ul li.displaySelect{

	display:inline-block;
	width:180px;
	height:35px;
}
#mainUp form ul li.displayBatch{

	display:block;
	text-align:center;
	width:1200px;
	height:35px;
}
#mainUp form ul.submit{
	text-align:center;
	width:1300px;
	height:35px;
}
#mainDown{
    width: 98%;
    height: auto;
    margin-top: -15px;
    margin-right: 10px;
    margin-bottom: 10px;
    margin-left: 15px;
    background-color: #FFF;
    border-radius: 8px;
    font-size: 18px;
    overflow: auto;
    text-align: center;
}
#display {
	width: 98%;
	height: auto;
	max-height: 600px;
	z-index: 1;
	/*margin-top: -15px;
	margin-right: 10px;
	margin-bottom: 10px;
	margin-left: 15px;*/
	background-color: #FFF;
	border-radius: 8px;
	font-size: 18px;
	overflow: auto;
	text-align: center;
}
#display table td div.displayMain{
	width:100px;
	}
	#display table td div.displayMainSelect{
	width:100px;
	}
</style>

</head>

<body bgcolor="#cfd4ff">
<div id="header" >
  <p class="title">东江湖流域数据管理与综合分析智能中心</p>
  <ul>
		
		<li><a href="index.php">首页</a></li>
	<li>你好!</li>
        <li class="headerUser">用户名</li>
	<li><a href="index.php">个人设置</a></li>
		<li  id="configure"><a href="manage.php">系统管理</a>
        <div id="conf">
          <table width="119" height="208" border="0">
            <tr>
              <td><a href="#" target="_self">用户管理</a></td>
            </tr>
            <tr>
              <td>日志管理</td>
            </tr>
            <tr>
              <td><a href="#" target="_self">数据库管理</a></td>
            </tr>
            <tr>
              <td><a href="javascritp:window.print() " target="_self">打印机管理</a></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
            </tr>

          </table>
        </div>
</li>
		<li id="conflog"></li>
		<li  id="help" ><a href="help.php">帮助</a></li>

	<li class="logout"><a href="logout.php">退出登录</a></li>
		
  </ul>
</div>

<div id="selectDB">
  <h2><strong>请选择数据库</strong>
  </h2>
  <form method="get" action="">
    <table width="100%" height="180" border="0">
      <tr>
        <td width="8%" height="55"><span class="department">水文：</span></td>
        <td width="12%"><p><a href="?tableCh=水文信息">水文信息</a></p></td>
        <td width="11%"><p><a href="?baseType=nongdiaoxinxi">待定</a></p></td>
        <td width="10%"><p><a href="?baseType=nongdiaoxinxi">待定</a></p></td>
        <td width="9%">
        <span class="department">农业：</span>
       </td>
        <td width="12%"><p><a href="?tableCh=农调信息">农调信息</a> </p>
        </td>
        <td width="8%"><span class="department">气象：</span></td>
        <td width="12%"><p><a href="?tableCh=气象信息">气象信息</a></p></td>
        <td width="8%"><span class="department">人力：</span></td>
        <td width="10%"><p><a href="?tableCh=统计信息">统计信息</a></p></td>
      </tr>
      <tr>
        <td height="64"><span class="department">环保：</span></td>
        <td><p><a href="?tableCh=环保信息">环保信息:</a></p></td>
        <td><p><a href="?baseType=nongdiaoxinxi">待定</a></p></td>
        <td><p><a href="?baseType=nongdiaoxinxi">待定</a></p></td>
        <td><span class="department">农业：</span></td>
        <td><p><a href="?baseType=nongdiaoxinxi">农调信息</a></p></td>
        <td><span class="department">气象：</span></td>
        <td><p><a href="?baseType=nongdiaoxinxi">农调信息</a></p></td>
        <td><span class="department">人力：</span></td>
        <td><p><a href="?baseType=nongdiaoxinxi">农调信息</a></p></td>
      </tr>
      <tr>
        <td height="53"><span class="department">人力：</span></td>
        <td><p><a href="?tableCh=统计信息">统计信息</a></p></td>
        <td><p><a href="?baseType=nongdiaoxinxi">待定</a></p></td>
        <td><p><a href="?baseType=nongdiaoxinxi">待定</a></p></td>
        <td><span class="department">农业：</span></td>
        <td><p><a href="?baseType=nongdiaoxinxi">待定</a></p></td>
        <td><span class="department">气象：</span></td>
        <td><p><a href="?baseType=nongdiaoxinxi">待定</a></p></td>
        <td><span class="department">人力：</span></td>
        <td><p><a href="?baseType=nongdiaoxinxi">待定</a></p></td>
      </tr>
    </table>
  </form>
</div>

<div id="mainUp">
  <h2 id="operateTitle"><strong><?php echo $_SESSION['tableCh']?>数据库查询操作</strong></h2>

  <form method="post" action="?action=search">
  <!--<div class="ziduanzhiyue" id="ziduanzhiyue">--><span class="title2">数据约束条件选择: </span>


    <ul>
      <?php
      $i=0;
      //echo $sql;
      //echo $_SESSION['tableName'];
      foreach ($fields as $field){
       /*   $strSql1=<<<EOF
SELECT {$field['attname']} FROM {$_SESSION['tableName']} WHERE {$field['attname']}=max('{$field['attname']}')
EOF;*/
          $strSql1=<<<EOF
SELECT {$field['attname']} FROM {$_SESSION['tableName']} WHERE {$field['attname']}=(select min({$field['attname']}) 
                from {$_SESSION['tableName']}) 
EOF;
          // echo $strSql1;
          $minResult=pg_query($strSql1);
          $mins=pg_fetch_assoc($minResult);
          $min=$mins[$field['attname']];
          //echo $min;
          $strSql2=<<<EOF
SELECT {$field['attname']} FROM {$_SESSION['tableName']} WHERE {$field['attname']}=(select max({$field['attname']}) 
                from {$_SESSION['tableName']}) 
EOF;
         // echo $strSql2;
          $maxResult=pg_query($strSql2);
          $maxs=pg_fetch_assoc($maxResult);
          $max=$maxs[$field['attname']];
          //echo $max;



          ?>
      <li><span class="searchInfo"><?php echo winDisplay($field['attname'])?>(最小:<?php echo $min;?>;最大:<?php echo $max;?>):</span>
      <span class="searchInput"> 从<input type="text" class="searchInput" name="<?php echo 'first'.$field['attname']?>" value="<?php echo $min;?>"/>到<input class="searchInput" type="text" name="<?php echo 'second'.$field['attname']?>" value="<?php echo $max;?>"/></span>
      </li>
      <?php
        $i++;
        if($i%3==0 && $i!=0){
          /*echo '<br/>';*/
        }
      }?>
    </ul>


  <!--<div class="xianshiziduan" id="xianshiziduan">--><span  class="title2">数据显示字段选择:</span>
    <ul id="displaySelect" class="displaySelect">
        <?php foreach ($fields as $field){?>
          <li class="displaySelect"><input class="searchSimpleInput" type="checkbox" name="displays[]" id="<?php echo $field['attname']?>" value="<?php echo winDisplay($field['attname'])?>" />
        <label for="<?php echo $field['attname']?>"><?php echo winDisplay($field['attname'])?></label>
          <input type="hidden" name="<?php echo $field['attname']?>" value="<?php echo winDisplay($field['attname'])?>" />
          </li>
          <!--<td><input type="checkbox" name="displays[]" id="date" value="日期" />
        <label for="date">日期</label></td>
          <td><input type="checkbox" name="displays[]" id="precipitation" value="降雨量" />
        <label for="precipitation">降雨量</label></td>
          <td><input type="checkbox" name="displays[]" id="flow" value="平局流量" />
        <label for="flow">平均流量</label></td>-->
        <?php } ?>
      <li class="displayBatch"><input class="searchSimpleInput" type="checkbox" name="displayAll" id="displayAll"  />
        <label for="displayAll">全选</label>
        <input type="checkbox" class="searchSimpleInput" name="displayReverse" id="displayReverse"  />
        <label for="displayReverse">反选</label>
      </li>

    </ul>
    <ul class="submit">
      <li>
        <input type="submit" value="开始查询">
      </li>
    </ul>

  </form>
</div>


  <?php 
    //根据制约条件取出数据
   /* $sql=<<<EOF
  SELECT * FORM {$_SESSION['tableName']} WHERE precipitation<1.5;
EOF;*/
   //删除
    if($_GET['action']='delete' && isset($_POST['ids'])){
      $shouldDelete=pg_escape_string(implode(",",$_POST["ids"]));
      $str=implode(',',$_POST['ids']);
    }
    $sqlDelete=<<<EOF
    DELETE FROM {$_SESSION['tableName']} WHERE id in ({$str})
EOF;
  //echo $sqlDelete;
  pg_query($sqlDelete);

  //查询
  if($_GET['action']='search'){
    $partSql='';
    foreach ($fields as $field){
      //ok
      //echo $_POST['first'.$field['attname']];
      $acmin=pg_escape_string($_POST['first'.$field['attname']]);
      $acmax=pg_escape_string($_POST['second'.$field['attname']]);
      $partSql.=$field['attname'].' between '.$acmin.' and '.$acmax.' ';
      //$acArray[]='('.$field['attname'].' between '.$acmin.' and '.$acmax.' '.')';
        $acArray[]='('.$field['attname'].' between '.'\''.$acmin.'\''.' and '.'\''.$acmax.'\''.' '.')';
        //$acArray[]='('.$field['attname'].' between '.'{'.$acmin.'}'.' and '.'{'.$acmax.'}'.' '.')';
      //echo $acArray;
    }
    $sqlPart=implode(' and ',$acArray);
    /*echo $sqlPart;
      echo $partSql;
      echo '<br/>';*/
      $acSql=<<<EOF
SELECT * FROM {$_SESSION['tableName']} WHERE {$sqlPart}
EOF;
      $resSearch=pg_query($acSql);
  }


 /*   $sqlSearch=<<<EOF
  SELECT * FROM {$_SESSION['tableName']} WHERE ;
EOF;
  $resSearch=pg_query($sqlSearch);*/
    //$rows=pg_fetch_assoc($res);
    //echo $_SESSION['tableName'];
    //print_r($rows);
    ?>
<div id="mainDown">
<h2> 查询结果</h2>
<div id="display">
  <form id="formSelect" method="post" action="?action=delete">
    <table width="100%" border="1">
  <tr>
    <td><div class="displayMain">序号</div></td>
      <?php foreach ($_POST['displays'] as $value){?>
      <td><div class="displayMain"><?php echo $value; ?></div></td>
      <?php }?>
      <td><div class="displayMain">是否选择</div></td>

  </tr>
      <!--有多少条-->
      <?php while($rowsSearch=pg_fetch_assoc($resSearch)){?>
  <tr>
    <td>
      <div class="displayMain"><?php echo $rowsSearch['id']?></div>
    </td>
    <?php
    //错误理解：外层foreach用的临时变量$value遍历和里层foreach用的临时变量会冲突，解决方法:1去不同名字2将外层变量付给新的变量
    //实际上是函数没写正确，没用返回值;注意没用返回值光输出时$rowsSearch[iniField($value)],没取出结果
    foreach ($_POST['displays'] as $displayValue){?>
      <td>
        <div class="displayMain"><?php $key=iniField($displayValue);
          echo $rowsSearch[$key]; ?></div>
        <?php
        //print_r($rowsSearch);
        //echo $_SESSION['tableName'];
        //小心函数用echo内部输出和返回值的区别
        /*$key=iniField($value);
        echo $key;*/
        /*//foreach 外部$key变量名作为键值取不出数据
        echo $rowsSearch[$key];*/
        //foreach 时$key变量名作为键值取出了数据
         /*foreach ($rowsSearch as $key=>$value){
          echo $rowsSearch[$key];
        }*/
        /*$key=iniField($displayValue);
        echo $rowsSearch[$key];*/
        /*foreach ($rowsSearch as $key=>$fieValue){
          if($key==iniField($disValue)){
            echo $rowsSearch[$key];
          }
        }*/
        ?>
      </td>
    <?php }?>
    <td><div class="displayMainSelect"><input class="selectSimpleInput" type="checkbox" name="ids[]" value="<?php echo $rowsSearch['id']?>" /></div></td>
  </tr>
      <?php }?>
      <td colspan="<?php echo sizeof($fields)+2;?>">
        </td>
</table>
</div>
    <p><input class="selectSimpleInput" type="checkbox" name="selectAll" id="selectAll"  />
    <label for="selectAll">全选</label>
    <input type="checkbox" class="selectSimpleInput" name="selectReverse" id="selectReverse"  />
    <label for="selectReverse">反选</label></p>
    <input id="delete" type="submit" value="删除"/>
  </form>



</div>
<script type="text/javascript" src="js/<?php echo SCRIPT?>.js"></script>
</body>
</html>
