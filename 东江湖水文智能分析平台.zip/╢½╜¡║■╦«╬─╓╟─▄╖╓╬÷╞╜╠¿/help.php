﻿<?php
/**
* TestGuest Version1.0
* ================================================
* Copy 2010-2012 yc60
* Web: http://www.yc60.com
* ================================================
* Author: Lee
* Date: 2010-8-10
*/
header("Content-Type:text/html;charset=utf-8");
session_start();
//定义个常量，用来授权调用includes里面的文件
define('IN_TG',true);
//定义个常量，用来指定本页的内容
define('SCRIPT','help');
//引入公共文件
require dirname(__FILE__).'/includes/common.inc.php'; //转换成硬路径，速度更快

//读取djhhelp中的字段
//字段映射
$helpEnToCh=array('summary'=>'一、概述','login'=>'二、如何登陆东江湖流域数据管理与综合分析智能中心','register'=>'三、账号注册流程','hot'=>'四、热门问题解答','soft'=>'五、软件说明','connect'=>'六、联系管理员');

if ($_GET['action']=='deleteColumn'){
    //不用删除数组里面的key
    $deleteColumnSql=<<<eof
alter table djhhelp drop column name {$_POST['deleteColumn']}
eof;
    $deleteColumn=pg_query($deleteColumnSql);
    if (pg_affected_rows($deleteColumn!=NULL)){
        _alert_info('删除成功');
    }

}
if ($_GET['action']=='addColumn'){
    //不用删除数组里面的key
    $addColumnSql=<<<eof
alter table djhhelp add {$_POST['addColumnEn']} text
eof;
    $addColumn=pg_query($addColumnSql);

    if (pg_affected_rows($addColumn!=NULL)){
        _alert_info('添加成功');
    }
    $helpEnToCh[$_POST['addColumnEn']]=$_POST['addColumnCh'];

}
if($_GET['action']=='deleteContent'){
    //因为表的设计，此处不是删除，而是置为空
   // $deleteContent=trim($_GET['deleteContent']);
    $deleteContentSql=<<<eof
UPDATE djhhelp SET {$_GET['column']}=NULL where id='{$_GET['deleteContentId']}'
eof;
    /*echo $deleteContentSql;
    exit();*/
    $deleteContent=pg_query($deleteContentSql);

    if (pg_affected_rows($deleteContent!=NULL)){
        _alert_info('删除成功');
    }

}
if ($_GET['action']=='addContent'){

    $addContentSql=<<<eof
INSERT INTO djhhelp ({$_POST['column']}) VALUES ('{$_POST['addContent']}')
eof;
   /* echo $addContentSql;
    exit();*/
    $addContent=pg_query($addContentSql);

    if (pg_affected_rows($addContent!=NULL)){
        _alert_info('添加成功');
    }
    $helpEnToCh[$_POST['addContentEn']]=$_POST['addContentCh'];
}
$sql = <<<EOF
SELECT a.attname, a.attnotnull as notnull FROM pg_class as c,pg_attribute as a  where c.relname = 'djhhelp' and a.attrelid = c.oid and a.attnum>1
EOF;
$result = pg_query($sql);
while ($row = pg_fetch_assoc($result)) {
	$fields[] = $row;
}
//content 根据标题显示内容
if(empty($_GET['searchField'])){
	$contentTitle='summary';
}else{
	$contentTitle=$_GET['searchField'];
}

if($_GET['action']=='search'){
	$flag=0;
	//echo $_POST['keyWord'];
	foreach ($helpEnToCh as $key=>$value){
		/*echo $value;
		echo mb_strpos($value,$_POST['keyWord']);*/
		if(mb_strpos($value,$_GET['keyWord'])!==false){
			$contentTitle= $key;
			//echo $contentTitle;
			$flag=1;
			break;
		}
		$flag=0;
	}
	if($flag==0){
		_alert_back('未找到此关键词，请重新搜索');
	}
}

$substanceSql=<<<EOF
SELECT id,{$contentTitle} FROM djhhelp
EOF;
//echo $substanceSql;
$substanceResult=pg_query($substanceSql);
$contentSubstance=array();
while($helpRows=pg_fetch_assoc($substanceResult)){
	$contentSubstance[]=$helpRows;
}
//var_dump($contentSubstance);
//$contentSubstance=pg_fetch_assoc($substanceResutl);

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<?php
	require 'includes/title.inc.php';
	?>
	<script type="text/javascript" src="js/jquery-3.1.0.min.js"></script>
	<link rel="stylesheet" type="text/css" href="js/jQuery-jcDate-master/src/jcDate.css" media="all" />
	<script type="text/javascript" src="js/jQuery-jcDate-master/src/jQuery-jcDate.js" charset="utf-8"></script>
	<link rel="stylesheet" type="text/css" href="templateCss.css" />
<style type="text/css">

	#whole{
		margin:20px auto;
		width:96%;
		min-height:620px;
		border-radius: 8px;
	}
	#search{
		width:96%;
		margin:10px auto;
		text-align: right;
		float:right;
	}
	#column{
		margin-top:8px;
		border-radius: 8px;
		width:20%;
		min-height: 300px;
		font-size:1.1em;
		background: white;
		padding: 10px;
		float:left;
	}
	#column p{
		margin:10px;
	}
    #column p.addColumn{
        color: #0000FF;
    }
    #column input.addColumn{
        width: 98%;
    }
    #column p.addSubmit{
        text-align: center;
    }

	#column textarea.columnText{
		font-size: 1.0em;
		width:98%;
        height: auto;
	}

	#content{
		border-radius: 8px;
		width:70%;
		min-height: 600px;
		font-size:1.0em;
		background: white;
		padding: 10px;
		float:right;
	}
	#content h2{
		text-align: center;
	}



</style>
</head>
<body>

<?php 
	require ROOT_PATH.'includes/header.inc.php';
?>
<div class="bodyContent">
<?php if(isset($_SESSION['admin'])){?>
<div id="whole">

	<div class="search" id="search">
		<form method="get" action="?action=search">
			<input type="hidden" name="action" value="search"/>
			关键字: <input type="text" name="keyWord"/>
			<input type="submit"  value="查询"/>
		</form>
	</div>
	<div class="column" id="column">
		<?php foreach ($fields as $field){?>
            <form method="post" action="?action=deleteColumn" onsubmit="if(confirm('你确定要删除此栏位吗')){return true;}else{
                return false;
            }">
			<p class="title"><a href="?searchField=<?php echo $field['attname'];?>">
                    <?php echo $helpEnToCh[$field['attname']];?>
					<!--<input type="textarea" class="columnText" name="<?php /*echo $field['attname'];*/?>" value="<?php /*echo $helpEnToCh[$field['attname']];*/?>"/>-->
                    <!--<textarea class="columnText" name="<?php /*echo $field['attname'];*/?>"   style="overflow-y:hidden;height:80px;"onpropertychange="this.style.height=this.scrollHeight+'px';" oninput="this.style.height=this.scrollHeight+'px';">
						<?php /*echo $helpEnToCh[$field['attname']];*/?>
					</textarea>-->
					</a>
<br/>
                <input type="submit" value="删除" />
                <input type="hidden" name="deleteColumn" value="<?php echo $field['attname'];?>"/>
                <!--<input type="button" value="修改"/>-->
                <!--<a onclick="" >删除</a><a>修改</a>--> </p>
            </form>
		<?php
		}
		?>
        <form method="post" action="?action=addColumn" onsubmit="if(confirm('你确定要添加此栏位吗')){return true;}else{
                return false;
            }">
       <!--     <input type="hidden" name="action" value="modifyColumn"/>-->
            <p class="addColumn">新栏目英文名：</p><input class="addColumn" type="text" name="addColumnEn"/>
            <p class="addColumn">新栏目中文名：</p><input class="addColumn" type="text" name="addColumnCh"/>
            <br/>
            <p class="addSubmit"><input type="submit" value="添加新栏目"/></p>
        </form>

	</div>
	<div class="content" id="content">
		<h2><?php echo $helpEnToCh[$contentTitle];?></h2>
		<div class="contentSubstance">
			<?php foreach ($contentSubstance as $key=>$value){
			    if($value[$contentTitle]!=NULL){
                    echo '<p>'.$value[$contentTitle].'<a href="?action=deleteContent&column='.$contentTitle.'&deleteContentId='.$value['id'].'">删除</a></p>';
                }

			}?>
            <form method="post" action="?action=addContent" onsubmit="if(confirm('你确定要添加此此条目吗')){return true;}else{
                return false;
            }">
                <p class="addContent">新条目：</p><!--<input class="addcontent" type="text" name="addcontentCh"/>-->
                <input type="hidden" name="column" value="<?php echo $contentTitle?>"/>
                <!--<textarea rows="" cols="" name="addContent" style="overflow-y:hidden;width:90%;height:80px;"onpropertychange="this.style.height=this.scrollHeight+'px';" oninput="this.style.height=this.scrollHeight+'px';">

                </textarea>-->
                <input type="text" name="addContent" style="width:90%;height:80px;overflow: auto"/>
                <br/>
                <p class="addSubmit" style="text-align: center"><input type="submit" value="添加新条目"/></p>
            </form>
		</div>
	</div>
</div>
<?php }else{?>
<div id="whole">

	<div class="search" id="search">
		<form method="get" action="?action=search">
			<input type="hidden" name="action" value="search"/>
			关键字: <input type="text" name="keyWord"/>
			<input type="submit"  value="查询"/>
		</form>
	</div>
	<div class="column" id="column">
		<?php foreach ($fields as $field){?>
			<p class="title"><a href="?searchField=<?php echo $field['attname'];?>"><?php echo $helpEnToCh[$field['attname']];?></a></p>
		<?php }?>
	</div>
	<div class="content" id="content">
		<h2><?php echo $helpEnToCh[$contentTitle];?></h2>
		<div class="contentSubstance">
			<?php foreach ($contentSubstance as $key=>$value){
				echo '<p>'.$value[$contentTitle].'</p>';
			}?>
		</div>
	</div>
</div>
<?php }?>
</div>
<?php 
	require ROOT_PATH.'includes/footer.inc.php';
?>
<script type="text/javascript" src="js/help.js"></script>
</body>
</html>
