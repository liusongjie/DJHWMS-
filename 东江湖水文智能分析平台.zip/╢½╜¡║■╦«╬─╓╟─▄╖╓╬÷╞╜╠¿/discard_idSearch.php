
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>按id号查询</title>

<!--<script type="text/javascript" src="js/baseManage.header.js"></script>-->
</head>
<body>
    <div>
        <form method="get" action="?action=search">
            请输入id:<input type="text" id="id" /><br/>
            <input type="hidden" id="baseType" value="<?php echo $_GET['baseType'];?>">
            <input type="submit"  value="查询" name="submit"/>
        </form>
    </div>
    <script type="text/javascript" src="js/idSearch.js"></script>
</body>