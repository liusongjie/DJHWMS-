<?php
/**
* TestGuest Version1.0
* ================================================
* Copy 2010-2012 yc60
* Web: http://www.yc60.com
* ================================================
* Author: Lee
* Date: 2010-8-13
*/
header("Content-Type:text/html;charset=utf-8");
header("Cache-Control: no-cache");
session_start();
header("Content-Type:text/html;charset=utf-8");
header("Cache-Control: no-cache");
if(!empty($_COOKIE['username'])){
   // setcookie('username',$_COOKIE['username'], 30 + time());
}

/*if(empty($_COOKIE['username'])){
    $sqlLoginState=<<<EOF
UPDATE djhuser SET 
EOF;
}*/

/*$minus= time()-$_COOKIE['loginTime'];
$data=date("H:i:s",$minus);
$json_arr = array("pastTime"=>$data);
$json_obj = json_encode($json_arr);
echo $json_obj;*/
//echo $data;
//echo json_encode($data);
//echo 1;
?>