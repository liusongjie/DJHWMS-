<?php

header("Content-Type:text/html;charset=utf-8");
session_start();
//定义个常量，用来授权调用includes里面的文件
define('IN_TG',true);
//定义个常量，用来指定本页的内容
define('SCRIPT','import');
//引入公共文件
require dirname(__FILE__).'/includes/common.inc.php';
require_once("http://localhost:8080/JavaBridgeTemplate611/java/Java.inc");

$file=addslashes(ROOT_PATH.$_COOKIE['username'].'\binzhuangtu'.time().'.jpg');
$filePath=addslashes(ROOT_PATH.$_COOKIE['username'].'\tiaoxintu'.time().'.jpg');
/*echo $file;
echo $filePath;*/
if (!file_exists(ROOT_PATH.$_COOKIE['username'])){
    mkdir (ROOT_PATH.$_COOKIE['username']);
    //echo '创建文件夹test成功';
} /*else {
                echo '需创建的文件夹test已经存在';
            }*/

require_once("http://localhost:8080/JavaBridgeTemplate611/java/Java.inc");

$analyze=new Java('JavaSuccess');
//$analyze->Canshuchuandi2('222','2011-01-02','2012-12-02','wl',$file,$filePath);
$analyze->Canshuchuandi21('222','1990','2012','amaxat',$file,$filePath);
?>
